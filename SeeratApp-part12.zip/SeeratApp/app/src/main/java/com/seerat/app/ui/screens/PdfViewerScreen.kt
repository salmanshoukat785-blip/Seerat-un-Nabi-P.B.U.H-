package com.seerat.app.ui.screens

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.seerat.app.R
import com.seerat.app.ui.components.SeeratScaffold
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** An open PDF; PdfRenderer allows one page at a time, so rendering is guarded by a lock. */
private class PdfDoc(val file: File, val descriptor: ParcelFileDescriptor, val renderer: PdfRenderer) {
    val lock = Mutex()
    val pageCount: Int get() = renderer.pageCount

    fun close() {
        try {
            renderer.close()
            descriptor.close()
        } catch (e: Exception) {
            // already closed
        }
    }
}

/** Shows the whole book as PDF pages, with Share and Download buttons. */
@Composable
fun PdfViewerScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val labels = bookLabels()
    val texts = PdfTexts(
        docTitle = stringResource(R.string.pdf_doc_title),
        noteLabel = stringResource(R.string.note_label),
        verifyLabel = stringResource(R.string.data_note_label)
    )
    val savedMsg = stringResource(R.string.pdf_saved)
    val failedMsg = stringResource(R.string.pdf_failed)
    val shareTitle = stringResource(R.string.pdf_share_title)
    val noAppMsg = stringResource(R.string.feedback_none)

    // null while the PDF is being made (or if making it failed)
    val doc by produceState<PdfDoc?>(initialValue = null) {
        value = withContext(Dispatchers.IO) {
            try {
                val file = createPdfFile(context, labels, texts)
                val descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                PdfDoc(file, descriptor, PdfRenderer(descriptor))
            } catch (e: Exception) {
                null
            }
        }
    }
    val current = doc
    DisposableEffect(current) { onDispose { current?.close() } }

    val saveLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri: Uri? ->
        val pdf = doc
        if (uri != null && pdf != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    runCatching {
                        val out = requireNotNull(context.contentResolver.openOutputStream(uri))
                        out.use { o -> pdf.file.inputStream().use { it.copyTo(o) } }
                    }.isSuccess
                }
                Toast.makeText(context, if (ok) savedMsg else failedMsg, Toast.LENGTH_LONG).show()
            }
        }
    }

    SeeratScaffold(
        title = stringResource(R.string.pdf_view_title),
        onBack = onBack,
        actions = {
            TextButton(
                enabled = current != null,
                onClick = {
                    val pdf = current ?: return@TextButton
                    val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", pdf.file)
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "application/pdf"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, texts.docTitle)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    try {
                        context.startActivity(
                            Intent.createChooser(send, shareTitle).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        )
                    } catch (e: ActivityNotFoundException) {
                        Toast.makeText(context, noAppMsg, Toast.LENGTH_LONG).show()
                    }
                }
            ) { Text(stringResource(R.string.pdf_share), color = MaterialTheme.colorScheme.secondary) }
            TextButton(
                enabled = current != null,
                onClick = { saveLauncher.launch("Seerat-un-Nabi.pdf") }
            ) { Text(stringResource(R.string.pdf_download), color = MaterialTheme.colorScheme.secondary) }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (current == null) {
                Column(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(12.dp))
                    Text(stringResource(R.string.pdf_preparing))
                }
            } else {
                val widthDp = LocalConfiguration.current.screenWidthDp
                val widthPx = with(LocalDensity.current) { widthDp.dp.roundToPx() }.coerceIn(400, 1200)
                LazyColumn(
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Text(
                            text = stringResource(R.string.pdf_pages, current.pageCount),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    items(count = current.pageCount, key = { it }) { index ->
                        PdfPage(doc = current, index = index, widthPx = widthPx)
                    }
                }
            }
        }
    }
}

@Composable
private fun PdfPage(doc: PdfDoc, index: Int, widthPx: Int) {
    val bitmap by produceState<Bitmap?>(initialValue = null, doc, index, widthPx) {
        value = withContext(Dispatchers.IO) {
            try {
                doc.lock.withLock {
                    doc.renderer.openPage(index).use { page ->
                        val height = (widthPx * page.height / page.width.toFloat()).toInt()
                        val bmp = Bitmap.createBitmap(widthPx, height, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(AndroidColor.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        bmp
                    }
                }
            } catch (e: Exception) {
                null
            }
        }
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
    ) {
        val bmp = bitmap
        if (bmp != null) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = stringResource(R.string.pdf_page_cd, index + 1),
                modifier = Modifier.fillMaxWidth(),
                contentScale = ContentScale.FillWidth
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(595f / 842f),
                contentAlignment = Alignment.Center
            ) { CircularProgressIndicator() }
        }
    }
}
