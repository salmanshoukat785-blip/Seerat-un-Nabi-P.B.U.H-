package com.seerat.app.ui.screens

import android.content.Context
import com.seerat.app.SeeratApplication
import com.seerat.app.book.BookLabels
import com.seerat.app.book.PdfBlock
import com.seerat.app.book.PdfExporter
import com.seerat.app.book.bookEntries
import java.io.File
import kotlinx.coroutines.flow.first

/** Words used inside the PDF. */
class PdfTexts(val docTitle: String, val noteLabel: String, val verifyLabel: String)

/**
 * Builds the whole book (with the user's notes) as a PDF in the cache folder and returns the file.
 * Call from a background thread.
 */
suspend fun createPdfFile(context: Context, labels: BookLabels, texts: PdfTexts): File {
    val app = context.applicationContext as SeeratApplication
    val entries = app.repository.bookEntries(labels)
    val notes = app.personalRepository.notes.first()
    val blocks = entries.map { e ->
        val note = notes[e.id]
        val extra = buildList {
            if (e.verify.isNotEmpty()) add("[${texts.verifyLabel}] " + e.verify.joinToString(" "))
            if (!note.isNullOrBlank()) add("${texts.noteLabel}: $note")
        }
        PdfBlock(
            chapter = e.group?.title ?: context.getString(e.chapter.chapterRes()),
            heading = plainTitle(context, e),
            sub = e.subtitle,
            body = (listOf(e.body) + extra).filter { it.isNotBlank() }.joinToString("\n")
        )
    }
    val dir = File(context.cacheDir, "pdf").apply { mkdirs() }
    val file = File(dir, "Seerat-un-Nabi.pdf")
    file.outputStream().use { PdfExporter.write(it, texts.docTitle, blocks) }
    return file
}
