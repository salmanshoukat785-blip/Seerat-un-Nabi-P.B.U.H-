package com.seerat.app.ui.screens

import androidx.annotation.StringRes
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.seerat.app.R
import com.seerat.app.book.BookBuilder
import com.seerat.app.book.BookChapter
import com.seerat.app.book.BookEntry
import com.seerat.app.data.model.Detail
import com.seerat.app.ui.components.ContentCard
import com.seerat.app.ui.components.HubBanner
import com.seerat.app.ui.components.HubCard
import com.seerat.app.ui.components.LoadedContent
import com.seerat.app.ui.components.SeeratScaffold
import com.seerat.app.ui.components.StatsStrip

fun BookChapter.emoji(): String = when (this) {
    BookChapter.NABUWAT -> "🌙"
    BookChapter.HIJRAT -> "🐪"
    BookChapter.GHAZWAT -> "⚔️"
    BookChapter.FAMILY -> ""
    BookChapter.UMMAHAT -> "🌸"
    BookChapter.AULAD -> ""
    BookChapter.AWWALEEN -> "🥇"
}

private class ChapterData(val entries: List<BookEntry>, val details: Map<String, Detail>)

/** One-line text for a list card: from details.json, else the first line of the entry. */
private fun summaryOf(entry: BookEntry, details: Map<String, Detail>): String =
    details[entry.id]?.summary
        ?: entry.body.lineSequence().firstOrNull().orEmpty().removePrefix("• ").take(120)

/**
 * A section as a list of numbered cards (title, summary, year, "view details" button).
 * Used for the timeline, ghazwat, family, ummahat, aulad and awwaleen sections.
 */
@Composable
fun ChapterScreen(
    chapters: List<BookChapter>,
    @StringRes titleRes: Int,
    @StringRes subtitleRes: Int,
    emoji: String,
    onBack: () -> Unit,
    onOpen: (String) -> Unit,
    onFavourites: () -> Unit
) {
    val labels = bookLabels()
    val personal = rememberPersonal()
    // 0 = everything; otherwise a chapter number (several chapters) or a Hijrat year (ghazwat)
    var filter by rememberSaveable { mutableStateOf(0) }
    val ghazwatOnly = chapters.singleOrNull() == BookChapter.GHAZWAT

    SeeratScaffold(
        title = stringResource(titleRes),
        onBack = onBack,
        actions = {
            TextButton(onClick = onFavourites) {
                Text(
                    text = "⭐ " + stringResource(R.string.qa_favs),
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }
    ) { padding ->
        LoadedContent(
            modifier = Modifier.padding(padding),
            loader = { repo ->
                ChapterData(
                    entries = BookBuilder.build(repo.quizData(), labels).filter { it.chapter in chapters },
                    details = repo.details()
                )
            }
        ) { data ->
            val entries = data.entries
            val shown = when {
                filter == 0 -> entries
                chapters.size > 1 -> entries.filter { it.chapter == chapters.getOrNull(filter - 1) }
                ghazwatOnly -> entries.filter { it.number == filter }
                else -> entries
            }
            val years = entries.map { it.number }.distinct().sorted()

            LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
                item {
                    HubBanner(
                        title = stringResource(titleRes),
                        subtitle = stringResource(subtitleRes),
                        emoji = emoji
                    )
                }
                item {
                    StatsStrip(
                        stats = listOf(
                            stringResource(R.string.hub_stat_total) to entries.size.toString(),
                            stringResource(R.string.hub_stat_favs) to
                                entries.count { it.id in personal.bookmarks }.toString(),
                            stringResource(R.string.hub_stat_notes) to
                                entries.count { personal.notes.containsKey(it.id) }.toString()
                        ),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                    )
                }
                if (chapters.size > 1 || ghazwatOnly) {
                    item {
                        Row(
                            modifier = Modifier
                                .horizontalScroll(rememberScrollState())
                                .padding(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = filter == 0,
                                onClick = { filter = 0 },
                                label = { Text(stringResource(R.string.filter_all)) }
                            )
                            if (ghazwatOnly) {
                                years.forEach { year ->
                                    FilterChip(
                                        selected = filter == year,
                                        onClick = { filter = year },
                                        label = { Text(stringResource(R.string.era_hijri, year)) }
                                    )
                                }
                            } else {
                                chapters.forEachIndexed { index, chapter ->
                                    FilterChip(
                                        selected = filter == index + 1,
                                        onClick = { filter = index + 1 },
                                        label = { Text(stringResource(chapter.chapterRes())) }
                                    )
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
                itemsIndexed(shown, key = { _, e -> e.id }) { index, entry ->
                    HubCard(
                        number = index + 1,
                        title = entryTitle(entry),
                        summary = summaryOf(entry, data.details),
                        chip = entry.subtitle.ifBlank {
                            if (entry.ceYear > 0) "${entry.ceYear} ${labels.ce}" else ""
                        }.ifBlank { null },
                        buttonText = stringResource(R.string.hub_details),
                        onClick = { onOpen(entry.id) },
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}

private class DetailData(val entry: BookEntry?, val detail: Detail?)

/** The "view details" page: summary, more details, lesson and the key facts. */
@Composable
fun DetailScreen(id: String?, onBack: () -> Unit) {
    val labels = bookLabels()
    val personal = rememberPersonal()

    SeeratScaffold(title = stringResource(R.string.detail_title), onBack = onBack) { padding ->
        LoadedContent(
            modifier = Modifier.padding(padding),
            loader = { repo ->
                DetailData(
                    entry = BookBuilder.build(repo.quizData(), labels).firstOrNull { it.id == id },
                    detail = id?.let { repo.details()[it] }
                )
            }
        ) { data ->
            val entry = data.entry
            if (entry == null) {
                Text(
                    text = stringResource(R.string.load_error),
                    modifier = Modifier.padding(24.dp)
                )
            } else {
                val detail = data.detail
                LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
                    item {
                        HubBanner(
                            title = entryTitle(entry),
                            subtitle = entry.subtitle,
                            emoji = entry.chapter.emoji()
                        )
                    }
                    if (detail != null) {
                        item {
                            ContentCard(modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp)) {
                                Text(
                                    text = stringResource(R.string.detail_summary),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = detail.summary,
                                    style = MaterialTheme.typography.bodyLarge,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }
                        if (detail.details.isNotEmpty()) {
                            item {
                                ContentCard(modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp)) {
                                    Text(
                                        text = stringResource(R.string.detail_more),
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    detail.details.forEach {
                                        Text(
                                            text = "•  $it",
                                            style = MaterialTheme.typography.bodyLarge,
                                            modifier = Modifier.padding(top = 6.dp)
                                        )
                                    }
                                }
                            }
                        }
                        if (detail.lesson.isNotBlank()) {
                            item {
                                ContentCard(modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp)) {
                                    Text(
                                        text = "💡 " + stringResource(R.string.detail_lesson),
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = detail.lesson,
                                        style = MaterialTheme.typography.bodyLarge,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                    item {
                        Text(
                            text = stringResource(R.string.detail_facts),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 6.dp)
                        )
                        EntryItem(
                            entry = entry,
                            personal = personal,
                            showChapter = false,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                }
            }
        }
    }
}
