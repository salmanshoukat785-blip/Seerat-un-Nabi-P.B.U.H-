# Seerat un-Nabi ﷺ (Android, Kotlin)

Offline Seerah learning app with Urdu (RTL) and English (LTR) UI.

## Status

**Part 3 of 8: splash and welcome polish** (Parts 1 and 2 are included)

- Kotlin + Jetpack Compose + Material 3
- Green and gold theme (light and dark), system/light/dark switch
- Urdu / English language switch (per-app locale, layout direction follows)
- Splash screen, welcome screen with note, home screen, settings
- Navigation with placeholder screens for the content sections
- Settings saved with DataStore
- Seerat data as JSON in `app/src/main/assets/data/` (timeline, ghazwat, family, ummahat, aulad, awwaleen), read offline
- New logo (crescent and open book), used as app icon, splash and welcome
- Splash: fade in with zoom, fade out, no white flash at start
- "Today's event" on the home screen comes from the timeline data

## Roadmap

1. Foundation (done)
2. Data: JSON from the Seerah document, offline storage (done)
3. Splash / welcome polish (done)
4. Content screens: timeline, ghazwat, family tree, ummahat, aulad, awwaleen
5. Quiz
6. Self test, hifz, match, order events, statistics
7. Book view, bookmarks, notes, search
8. PDF download, font size, feedback, release

## Build

Open the folder in Android Studio (Koala or newer, JDK 17) and let Gradle sync.
Android Studio creates the Gradle wrapper files on first sync, or run `gradle wrapper`.

Requirements: minSdk 24, compileSdk 34.

## Project layout

```
app/src/main/java/com/seerat/app/
  MainActivity.kt        entry point, theme, navigation
  MainViewModel.kt       settings state
  data/                  SettingsRepository (DataStore), LanguageManager,
                         SeeratRepository + DataParser, model/Models.kt
  navigation/            Routes, Section list, AppNav
  ui/theme/              Color, Type, Theme
  ui/screens/            Splash, Welcome, Home, Settings, Placeholder
app/src/main/res/
  values/strings.xml     English
  values-ur/strings.xml  Urdu
```

## Notes

- Add a Nastaliq font in `res/font` and set it in `ui/theme/Type.kt` (planned for Part 8).
- Content conflicts found in the source document are listed in `docs/data-notes.md`.
- `python3 tools/validate_data.py` checks the JSON files; `DataIntegrityTest` does the same on the JVM.
