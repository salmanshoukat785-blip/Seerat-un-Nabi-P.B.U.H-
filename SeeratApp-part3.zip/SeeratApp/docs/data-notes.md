# Data notes

Source: the user's document "Seerat N-Update.docx". The JSON files in
`app/src/main/assets/data/` follow the document. Facts were **not changed**.
Where the document disagrees with itself or with common accounts, the entry has a
`dataNotes` field (shown in the app later as a "check" hint). These need a decision.

## Open questions (need a decision)

| # | Where | What the document says | Issue |
|---|-------|------------------------|-------|
| 1 | Aulad: Ibrahim | birth 640 CE | Timeline puts his birth in 8 AH (630 CE). |
| 2 | Aulad: Zaynab | death 8 AH | Timeline puts her death in 7 AH. |
| 3 | Ummahat: Hafsa | nikah Sha'ban 2 AH | Timeline puts the nikah in 4 AH. |
| 4 | Timeline 10 AH | death of the Prophet under 10 AH (632 CE) | Usually given as 11 AH (12 Rabi ul Awwal). |
| 5 | Timeline 3 AH | no Ghazwa-e-Uhad | Uhad (3 AH) is missing from the list. |
| 6 | Rajee / Bir Maona | year 3 AH; 8 and 80 companions | Some books give 4 AH; Bir Maona is usually about 70 companions. |
| 7 | Ummahat: Aisha | 2210 hadith, 07 agreed-upon (mutafaq alayh) | The agreed-upon count looks too low. |
| 8 | Aulad: Abdullah | birth year empty | Left empty. |
| 9 | Timeline 2 AH | Hasan called "fifth khalifa" | Opinion; add a reference. |
| 10 | Ummahat: Sawda | death 22 AH | Sources differ. |

## Spelling fixes made while converting (facts unchanged)

- معصب → مصعب (Mus'ab bin Umair)
- حلیمہ بنت بی زؤیب → حلیمہ بنت ابی ذؤیب
- ابرہیم → ابراہیم
- بیت عقبہ → بیعت عقبہ
- سبل اور سبیل → سہل اور سہیل (the two orphans, land of Masjid-e-Nabawi)
- "ا حمراء الاسد" → "احمراء الاسد"
- Reading choices: the foster-sibling names next to Thuwayba and Halima were
  labelled "رضاعی بھائی / بہن بھائی".

## Year numbering

The document uses 1 AH = 623 CE ... 10 AH = 632 CE. The app keeps this numbering
everywhere so the quiz and timeline agree with the document.

## Counts

Timeline: 13 years of Nabuwat + 10 years of Hijrat. 28 entries in `ghazwat.json`
(25 ghazwat + Rajee, Bir Maona, Fath Makkah as "waqia"). 12 Ummahat, 7 children.
Run `python3 tools/validate_data.py` to check the files.
