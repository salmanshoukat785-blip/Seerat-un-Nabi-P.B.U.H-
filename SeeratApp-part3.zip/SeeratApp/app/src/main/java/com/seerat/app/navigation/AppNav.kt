package com.seerat.app.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.seerat.app.MainViewModel
import com.seerat.app.ui.screens.HomeScreen
import com.seerat.app.ui.screens.PlaceholderScreen
import com.seerat.app.ui.screens.SettingsScreen
import com.seerat.app.ui.screens.SplashScreen
import com.seerat.app.ui.screens.WelcomeScreen

@Composable
fun AppNav(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()

    NavHost(navController = navController, startDestination = Routes.SPLASH) {

        composable(Routes.SPLASH) {
            SplashScreen(
                welcomeSeen = viewModel.welcomeSeen,
                onFinished = { seen ->
                    val next = if (seen) Routes.HOME else Routes.WELCOME
                    navController.navigate(next) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.WELCOME) {
            WelcomeScreen(
                onStart = { dontShowAgain ->
                    viewModel.setWelcomeSeen(dontShowAgain)
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.WELCOME) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.HOME) {
            HomeScreen(
                onOpenSection = { navController.navigate(Routes.section(it.id)) },
                onOpenSettings = { navController.navigate(Routes.SETTINGS) }
            )
        }

        composable(
            route = Routes.SECTION,
            arguments = listOf(navArgument("id") { type = NavType.StringType })
        ) { entry ->
            val section = Section.fromId(entry.arguments?.getString("id"))
            PlaceholderScreen(
                titleRes = section?.titleRes,
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(
                themeMode = themeMode,
                onThemeChange = viewModel::setThemeMode,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
