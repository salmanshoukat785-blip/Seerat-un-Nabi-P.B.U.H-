package com.seerat.app

import android.app.Application
import com.seerat.app.data.SeeratRepository

class SeeratApplication : Application() {
    val repository: SeeratRepository by lazy { SeeratRepository(this) }
}
