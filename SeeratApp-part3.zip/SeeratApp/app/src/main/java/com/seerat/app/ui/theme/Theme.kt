package com.seerat.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.seerat.app.data.ThemeMode

private val LightColors = lightColorScheme(
    primary = GreenDeep,
    onPrimary = Color.White,
    secondary = GoldSoft,
    onSecondary = InkText,
    tertiary = OliveAccent,
    onTertiary = Color.White,
    background = CreamBg,
    onBackground = InkText,
    surface = Color.White,
    onSurface = InkText,
    surfaceVariant = Color(0xFFF1EBD6),
    onSurfaceVariant = Color(0xFF4A4A3F),
    error = WrongRed
)

private val DarkColors = darkColorScheme(
    primary = GreenBright,
    onPrimary = Color.White,
    secondary = GoldBright,
    onSecondary = InkText,
    tertiary = MintAccent,
    onTertiary = InkText,
    background = CharcoalBg,
    onBackground = SoftWhite,
    surface = Color(0xFF1B2622),
    onSurface = SoftWhite,
    surfaceVariant = Color(0xFF26332E),
    onSurfaceVariant = Color(0xFFC8D3CD),
    error = Color(0xFFE57373)
)

@Composable
fun SeeratTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = AppTypography,
        content = content
    )
}
