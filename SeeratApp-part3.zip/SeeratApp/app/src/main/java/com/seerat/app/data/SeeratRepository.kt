package com.seerat.app.data

import android.content.Context
import com.seerat.app.data.model.AuladFile
import com.seerat.app.data.model.AwwaleenFile
import com.seerat.app.data.model.Family
import com.seerat.app.data.model.GhazwatFile
import com.seerat.app.data.model.Timeline
import com.seerat.app.data.model.UmmahatFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

enum class Period { NABUWAT, HIJRAT }

data class TodayEvent(
    val period: Period,
    val yearIndex: Int,
    val ceYear: Int,
    val text: String
)

/**
 * Reads the Seerat data from the app's assets (works fully offline).
 * Each file is read once and kept in memory.
 */
class SeeratRepository(private val context: Context) {

    private val lock = Mutex()
    private var timeline: Timeline? = null
    private var ghazwat: GhazwatFile? = null
    private var family: Family? = null
    private var ummahat: UmmahatFile? = null
    private var aulad: AuladFile? = null
    private var awwaleen: AwwaleenFile? = null

    private suspend fun read(path: String): String = withContext(Dispatchers.IO) {
        context.assets.open(path).bufferedReader(Charsets.UTF_8).use { it.readText() }
    }

    suspend fun timeline(): Timeline = lock.withLock {
        timeline ?: DataParser.timeline(read("data/timeline.json")).also { timeline = it }
    }

    suspend fun ghazwat(): List<com.seerat.app.data.model.Ghazwa> = lock.withLock {
        (ghazwat ?: DataParser.ghazwat(read("data/ghazwat.json")).also { ghazwat = it }).items
    }

    suspend fun family(): Family = lock.withLock {
        family ?: DataParser.family(read("data/family.json")).also { family = it }
    }

    suspend fun ummahat(): List<com.seerat.app.data.model.UmmulMomineen> = lock.withLock {
        (ummahat ?: DataParser.ummahat(read("data/ummahat.json")).also { ummahat = it }).items
    }

    suspend fun aulad(): List<com.seerat.app.data.model.Child> = lock.withLock {
        (aulad ?: DataParser.aulad(read("data/aulad.json")).also { aulad = it }).items
    }

    suspend fun awwaleen(): List<com.seerat.app.data.model.AwwaleenGroup> = lock.withLock {
        (awwaleen ?: DataParser.awwaleen(read("data/awwaleen.json")).also { awwaleen = it }).groups
    }

    /** One timeline event per day; the same event repeats only after the whole list is used. */
    suspend fun todayEvent(dayOfYear: Int): TodayEvent? {
        val t = timeline()
        val all = buildList {
            t.nabuwat.forEach { y -> y.events.forEach { add(TodayEvent(Period.NABUWAT, y.index, y.ceYear, it)) } }
            t.hijrat.forEach { y -> y.events.forEach { add(TodayEvent(Period.HIJRAT, y.index, y.ceYear, it)) } }
        }.distinctBy { it.text }
        if (all.isEmpty()) return null
        return all[(dayOfYear - 1).mod(all.size)]
    }
}
