# Seerat un-Nabi ﷺ (Android, Kotlin)

Offline Seerah learning app with Urdu (RTL) and English (LTR) UI.

## Status

**Part 1 of 8: foundation** (this commit)

- Kotlin + Jetpack Compose + Material 3
- Green and gold theme (light and dark), system/light/dark switch
- Urdu / English language switch (per-app locale, layout direction follows)
- Splash screen, welcome screen with note, home screen, settings
- Navigation with placeholder screens for the content sections
- Settings saved with DataStore

## Roadmap

1. Foundation (done)
2. Data: JSON from the Seerah document, offline storage
3. Splash / welcome polish
4. Content screens: timeline, ghazwat, family tree, ummahat, aulad, awwaleen
5. Quiz
6. Self test, hifz, match, order events, statistics
7. Book view, bookmarks, notes, search
8. PDF download, font size, feedback, release

## Build

Open the folder in Android Studio (Koala or newer, JDK 17) and let Gradle sync.
Android Studio creates the Gradle wrapper files on first sync, or run `gradle wrapper`.

Requirements: minSdk 24, compileSdk 34.

## Project layout

```
app/src/main/java/com/seerat/app/
  MainActivity.kt        entry point, theme, navigation
  MainViewModel.kt       settings state
  data/                  SettingsRepository (DataStore), LanguageManager
  navigation/            Routes, Section list, AppNav
  ui/theme/              Color, Type, Theme
  ui/screens/            Splash, Welcome, Home, Settings, Placeholder
app/src/main/res/
  values/strings.xml     English
  values-ur/strings.xml  Urdu
```

## Notes

- Add a Nastaliq font in `res/font` and set it in `ui/theme/Type.kt` (planned for Part 8).
- Content errors found in the source document are listed in `docs/data-notes.md` (to be added with Part 2).
