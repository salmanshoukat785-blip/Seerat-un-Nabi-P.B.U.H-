package com.seerat.app.navigation

import androidx.annotation.StringRes
import com.seerat.app.R

object Routes {
    const val SPLASH = "splash"
    const val WELCOME = "welcome"
    const val HOME = "home"
    const val SETTINGS = "settings"
    const val SECTION = "section/{id}"
    const val UMMAHAT_DETAIL = "ummahat/{id}"
    const val QUIZ_PLAY = "quiz/play/{category}/{difficulty}/{timed}"
    const val QUIZ_HISTORY = "quiz/history"

    // Learn and practice
    const val LEARN_SELFTEST = "learn/selftest"
    const val LEARN_HIFZ = "learn/hifz"
    const val LEARN_MATCH = "learn/match"
    const val LEARN_ORDER = "learn/order"
    const val LEARN_STATS = "learn/stats"
    const val LEARN_CARDS = "learn/cards/{mode}/{key}"
    const val LEARN_MATCH_PLAY = "learn/match/{type}"
    const val LEARN_ORDER_PLAY = "learn/order/{type}"

    fun section(id: String) = "section/$id"
    fun ummahatDetail(id: String) = "ummahat/$id"
    fun quizPlay(category: String, difficulty: String, timed: Boolean) =
        "quiz/play/$category/$difficulty/$timed"
    fun cards(mode: String, key: String) = "learn/cards/$mode/$key"
    fun matchPlay(type: String) = "learn/match/$type"
    fun orderPlay(type: String) = "learn/order/$type"
}

/** Home screen sections. Real screens replace the placeholders in later parts. */
enum class Section(val id: String, @StringRes val titleRes: Int) {
    TIMELINE("timeline", R.string.section_timeline),
    GHAZWAT("ghazwat", R.string.section_ghazwat),
    FAMILY("family", R.string.section_family),
    UMMAHAT("ummahat", R.string.section_ummahat),
    AULAD("aulad", R.string.section_aulad),
    AWWALEEN("awwaleen", R.string.section_awwaleen),
    QUIZ("quiz", R.string.section_quiz),
    LEARN("learn", R.string.section_learn);

    companion object {
        fun fromId(id: String?): Section? = entries.firstOrNull { it.id == id }
    }
}
