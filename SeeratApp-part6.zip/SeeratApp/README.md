# Seerat un-Nabi ﷺ (Android, Kotlin)

Offline Seerah learning app with Urdu (RTL) and English (LTR) UI.

## Status

**Part 6 of 8: learn and practice** (Parts 1 to 5 are included)

Part 6 adds: self test, hifz mode, match the following, order the events, wrong-answers revision, statistics.

- Kotlin + Jetpack Compose + Material 3
- Green and gold theme (light and dark), system/light/dark switch
- Urdu / English language switch (per-app locale, layout direction follows)
- Splash screen, welcome screen with note, home screen, settings
- Navigation with placeholder screens for the content sections
- Settings saved with DataStore
- Seerat data as JSON in `app/src/main/assets/data/` (timeline, ghazwat, family, ummahat, aulad, awwaleen), read offline
- New logo (crescent and open book), used as app icon, splash and welcome
- Splash: fade in with zoom, fade out, no white flash at start
- Content screens: Timeline (Nabuwat / Hijrat tabs), Ghazwat (year filter), Family, Ummahat ul Momineen (list + own profile), Children of the Prophet, Firsts in Islam
- Entries where the source document disagrees with itself show a "Please verify" note
- Quiz: questions are generated from the data (6 categories, easy / medium / hard / mixed, 10 questions), optional 20 s timer per question, score, explanation after each answer, list of wrong answers, history and best score per category (saved on the phone)
- Facts that are marked "please verify" are never used as quiz questions
- "Today's event" on the home screen comes from the timeline data

## Roadmap

1. Foundation (done)
2. Data: JSON from the Seerah document, offline storage (done)
3. Splash / welcome polish (done)
4. Content screens: timeline, ghazwat, family, ummahat, aulad, awwaleen (done)
5. Quiz (done)
6. Self test, hifz, match, order events, statistics
7. Book view, bookmarks, notes, search
8. PDF download, font size, feedback, release

## Build

Open the folder in Android Studio (Koala or newer, JDK 17) and let Gradle sync.
Android Studio creates the Gradle wrapper files on first sync, or run `gradle wrapper`.

Requirements: minSdk 24, compileSdk 34.

## Project layout

```
app/src/main/java/com/seerat/app/
  MainActivity.kt        entry point, theme, navigation
  MainViewModel.kt       settings state
  data/                  SettingsRepository (DataStore), LanguageManager,
                         SeeratRepository + DataParser, model/Models.kt
  navigation/            Routes, Section list, AppNav
  ui/theme/              Color, Type, Theme
  quiz/                  QuizGenerator (pure Kotlin), QuizViewModel, QuizRepository, models
  ui/components/         Common.kt (scaffold, data loader, cards, verify note)
  ui/screens/            Splash, Welcome, Home, Settings, Timeline, Ghazwat, Family,
                         Ummahat (+detail), Aulad, Awwaleen, Quiz (setup, play, history)
app/src/main/res/
  values/strings.xml     English
  values-ur/strings.xml  Urdu
```

## Notes

- Add a Nastaliq font in `res/font` and set it in `ui/theme/Type.kt` (planned for Part 8).
- Content conflicts found in the source document are listed in `docs/data-notes.md`.
- `python3 tools/validate_data.py` checks the JSON files; `DataIntegrityTest` does the same on the JVM.
- `QuizGeneratorTest` checks every question (4 different options, unique ids, no disputed facts). Run: `gradle testDebugUnitTest`.
- `LearnTest` checks decks, match rounds and order rounds.
