package com.seerat.app.quiz

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json

/** One finished quiz. */
@Serializable
data class QuizResult(
    val timestamp: Long,
    val category: String,      // QuizCategory name
    val difficulty: String,    // Difficulty name
    val timed: Boolean,
    val correct: Int,
    val total: Int
) {
    val percent: Int get() = if (total == 0) 0 else (correct * 100) / total
}

private val Context.quizStore by preferencesDataStore(name = "quiz")

/**
 * Keeps quiz history and the ids of questions answered wrongly (offline, on the phone).
 * The wrong ids are used in the next part for "wrong answers revision".
 */
class QuizRepository(private val context: Context) {

    private object Keys {
        val HISTORY = stringPreferencesKey("history")
        val WRONG_IDS = stringSetPreferencesKey("wrong_ids")
    }

    private val json = Json { ignoreUnknownKeys = true }
    private val historySerializer = ListSerializer(QuizResult.serializer())

    /** Newest first. */
    val history: Flow<List<QuizResult>> = context.quizStore.data.map { prefs ->
        decode(prefs[Keys.HISTORY])
    }

    val wrongIds: Flow<Set<String>> = context.quizStore.data.map { prefs ->
        prefs[Keys.WRONG_IDS] ?: emptySet()
    }

    suspend fun addResult(result: QuizResult, wrongIds: Set<String>, correctIds: Set<String>) {
        context.quizStore.edit { prefs ->
            val updated = (listOf(result) + decode(prefs[Keys.HISTORY])).take(MAX_HISTORY)
            prefs[Keys.HISTORY] = json.encodeToString(historySerializer, updated)
            // a question answered correctly now is no longer "weak"
            prefs[Keys.WRONG_IDS] = ((prefs[Keys.WRONG_IDS] ?: emptySet()) - correctIds) + wrongIds
        }
    }

    suspend fun clearHistory() {
        context.quizStore.edit { it.remove(Keys.HISTORY) }
    }

    private fun decode(text: String?): List<QuizResult> =
        if (text.isNullOrBlank()) {
            emptyList()
        } else {
            try {
                json.decodeFromString(historySerializer, text)
            } catch (e: Exception) {
                emptyList()
            }
        }

    private companion object {
        const val MAX_HISTORY = 50
    }
}
