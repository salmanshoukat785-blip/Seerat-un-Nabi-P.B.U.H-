package com.seerat.app.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.seerat.app.MainViewModel
import com.seerat.app.ui.screens.AuladScreen
import com.seerat.app.ui.screens.AwwaleenScreen
import com.seerat.app.ui.screens.FamilyScreen
import com.seerat.app.ui.screens.GhazwatScreen
import com.seerat.app.ui.screens.HomeScreen
import com.seerat.app.ui.screens.PlaceholderScreen
import com.seerat.app.ui.screens.QuizHistoryScreen
import com.seerat.app.ui.screens.QuizPlayScreen
import com.seerat.app.ui.screens.QuizSetupScreen
import com.seerat.app.ui.screens.SettingsScreen
import com.seerat.app.ui.screens.SplashScreen
import com.seerat.app.ui.screens.TimelineScreen
import com.seerat.app.ui.screens.UmmahatDetailScreen
import com.seerat.app.ui.screens.UmmahatScreen
import com.seerat.app.ui.screens.WelcomeScreen

@Composable
fun AppNav(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()

    NavHost(navController = navController, startDestination = Routes.SPLASH) {

        composable(Routes.SPLASH) {
            SplashScreen(
                welcomeSeen = viewModel.welcomeSeen,
                onFinished = { seen ->
                    val next = if (seen) Routes.HOME else Routes.WELCOME
                    navController.navigate(next) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.WELCOME) {
            WelcomeScreen(
                onStart = { dontShowAgain ->
                    viewModel.setWelcomeSeen(dontShowAgain)
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.WELCOME) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.HOME) {
            HomeScreen(
                onOpenSection = { navController.navigate(Routes.section(it.id)) },
                onOpenSettings = { navController.navigate(Routes.SETTINGS) }
            )
        }

        composable(
            route = Routes.SECTION,
            arguments = listOf(navArgument("id") { type = NavType.StringType })
        ) { entry ->
            val section = Section.fromId(entry.arguments?.getString("id"))
            val back: () -> Unit = { navController.popBackStack() }
            when (section) {
                Section.TIMELINE -> TimelineScreen(onBack = back)
                Section.GHAZWAT -> GhazwatScreen(onBack = back)
                Section.FAMILY -> FamilyScreen(onBack = back)
                Section.UMMAHAT -> UmmahatScreen(
                    onBack = back,
                    onOpen = { navController.navigate(Routes.ummahatDetail(it)) }
                )
                Section.AULAD -> AuladScreen(onBack = back)
                Section.AWWALEEN -> AwwaleenScreen(onBack = back)
                Section.QUIZ -> QuizSetupScreen(
                    onBack = back,
                    onStart = { category, difficulty, timed ->
                        navController.navigate(Routes.quizPlay(category.name, difficulty.name, timed))
                    },
                    onHistory = { navController.navigate(Routes.QUIZ_HISTORY) }
                )
                else -> PlaceholderScreen(titleRes = section?.titleRes, onBack = back)
            }
        }

        composable(
            route = Routes.QUIZ_PLAY,
            arguments = listOf(
                navArgument("category") { type = NavType.StringType },
                navArgument("difficulty") { type = NavType.StringType },
                navArgument("timed") { type = NavType.BoolType }
            )
        ) {
            QuizPlayScreen(
                onExit = { navController.popBackStack() },
                onPlayAgain = { navController.popBackStack() },
                onHome = { navController.popBackStack(Routes.HOME, inclusive = false) }
            )
        }

        composable(Routes.QUIZ_HISTORY) {
            QuizHistoryScreen(onBack = { navController.popBackStack() })
        }

        composable(
            route = Routes.UMMAHAT_DETAIL,
            arguments = listOf(navArgument("id") { type = NavType.StringType })
        ) { entry ->
            UmmahatDetailScreen(
                id = entry.arguments?.getString("id"),
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(
                themeMode = themeMode,
                onThemeChange = viewModel::setThemeMode,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
