package com.seerat.app

import android.app.Application
import com.seerat.app.data.SeeratRepository
import com.seerat.app.quiz.QuizRepository

class SeeratApplication : Application() {
    val repository: SeeratRepository by lazy { SeeratRepository(this) }
    val quizRepository: QuizRepository by lazy { QuizRepository(this) }
}
