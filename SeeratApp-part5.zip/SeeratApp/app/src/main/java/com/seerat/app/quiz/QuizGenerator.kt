package com.seerat.app.quiz

import com.seerat.app.data.model.AwwaleenGroup
import com.seerat.app.data.model.EraYear
import com.seerat.app.data.model.Ghazwa
import com.seerat.app.data.model.UmmulMomineen
import com.seerat.app.data.model.YearEntry
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * Builds multiple-choice questions from the Seerat data (no Android classes, runs in plain unit tests).
 *
 * Facts that the source document disagrees with itself about (see docs/data-notes.md) are left out,
 * so the quiz never asks something that is marked "please verify" in the app.
 * Question text is Urdu because the document is Urdu.
 */
object QuizGenerator {

    const val DEFAULT_COUNT = 10

    // Facts to skip in questions (disputed in docs/data-notes.md)
    private val SKIP_NIKAH = setOf("hafsa")
    private val SKIP_WAFAT = setOf("sawda")
    private val SKIP_AHADEES = setOf("aisha")
    private val SKIP_CHILD_BIRTH = setOf("ibrahim")
    private val SKIP_CHILD_WAFAT = setOf("zaynab")

    private val FAMOUS_GHAZWAT = setOf(
        "badr", "khandaq", "hudaybiyyah", "fath-makkah", "tabuk", "khaybar", "hunayn", "mutah"
    )

    /** Well-known companions, used as wrong options. */
    private val SAHABA = listOf(
        "ابو بکر صدیق", "عمر بن خطاب", "عثمان بن عفان",
        "علی بن ابی طالب", "خالد بن ولید", "زید بن حارثہ"
    )

    // ------------------------------------------------------------------ public API

    fun generate(
        data: QuizData,
        category: QuizCategory,
        difficulty: Difficulty,
        count: Int = DEFAULT_COUNT,
        random: Random = Random.Default
    ): List<QuizQuestion> {
        val pool = questionsFor(data, category, random).shuffled(random)
        val ordered = if (difficulty == Difficulty.MIXED) {
            pool
        } else {
            // closest difficulty first; the shuffle above keeps ties random
            pool.sortedBy { abs(it.difficulty.ordinal - difficulty.ordinal) }
        }
        return ordered.take(count).shuffled(random)
    }

    /** Every possible question (new random options each call). Ids are stable. */
    fun allQuestions(data: QuizData, random: Random = Random.Default): List<QuizQuestion> =
        questionsFor(data, QuizCategory.ALL, random)

    // ------------------------------------------------------------------ helpers

    private class Builder(private val random: Random) {
        val out = mutableListOf<QuizQuestion>()

        fun add(
            id: String,
            category: QuizCategory,
            difficulty: Difficulty,
            text: String,
            correct: String,
            wrong: List<String>,
            explanation: String
        ) {
            val w = wrong.map { it.trim() }.filter { it.isNotEmpty() && it != correct }.distinct()
            if (w.size < 3) return
            val options = (w.shuffled(random).take(3) + correct).shuffled(random)
            out.add(QuizQuestion(id, category, difficulty, text, options, options.indexOf(correct), explanation))
        }
    }

    private fun questionsFor(data: QuizData, category: QuizCategory, random: Random): List<QuizQuestion> =
        when (category) {
            QuizCategory.ALL -> QuizCategory.entries
                .filter { it != QuizCategory.ALL }
                .flatMap { questionsFor(data, it, random) }
            QuizCategory.NABUWAT -> periodQuestions(data, true, random)
            QuizCategory.HIJRAT -> periodQuestions(data, false, random)
            QuizCategory.GHAZWAT -> ghazwatQuestions(data, random)
            QuizCategory.FAMILY -> familyQuestions(data, random)
            QuizCategory.UMMAHAT -> ummahatQuestions(data, random)
            QuizCategory.AWWALEEN -> awwaleenQuestions(data, random)
        }

    private fun ah(year: Int) = "$year ہجری"
    private fun nabawi(year: Int) = "$year نبوی"
    private fun ce(year: Int) = "$year ء"

    /** Numbers close to [correct], nearest first (at most 5). */
    private fun nearby(correct: Int, min: Int, max: Int, step: Int = 1): List<Int> =
        (1..6).flatMap { k -> listOf(correct - k * step, correct + k * step) }
            .filter { it in min..max && it != correct }
            .sortedBy { abs(it - correct) }
            .take(5)

    /** Removes "رضی اللہ عنہ/عنہا" and "حضرت". */
    private fun String.clean(): String =
        replace("رضی اللہ عنہا", "")
            .replace("رضی اللہ عنہ", "")
            .replace("حضرت ", "")
            .replace("  ", " ")
            .trim()

    private fun AwwaleenGroup?.item(label: String): String? =
        this?.items?.firstOrNull { it.label == label }?.name

    private fun eraText(era: EraYear): String = when (era.era) {
        "nabawi" -> nabawi(era.year)
        "hijri" -> ah(era.year)
        else -> ce(era.year)
    }

    // ------------------------------------------------------------------ Nabuwat / Hijrat

    private fun periodQuestions(data: QuizData, isNabuwat: Boolean, random: Random): List<QuizQuestion> {
        val b = Builder(random)
        val category = if (isNabuwat) QuizCategory.NABUWAT else QuizCategory.HIJRAT
        val prefix = if (isNabuwat) "nabuwat" else "hijrat"
        val periodName = if (isNabuwat) "نبوت" else "ہجرت"
        val allYears = if (isNabuwat) data.timeline.nabuwat else data.timeline.hijrat

        // events that appear exactly once in the whole timeline and are short enough to read
        val counts = (data.timeline.nabuwat + data.timeline.hijrat)
            .flatMap { it.events }
            .groupingBy { it }
            .eachCount()
        fun uniqueEvents(y: YearEntry) = y.events.filter { counts[it] == 1 && it.length <= 70 }
        fun yearLabel(y: YearEntry) = if (isNabuwat) nabawi(y.index) else ah(y.index)

        // years with a "please verify" note are not used as the correct answer
        val usable = allYears.filter { it.dataNotes.isEmpty() }

        for (y in usable) {
            val events = uniqueEvents(y).sortedBy { it.length }

            // event -> year
            events.take(2).forEachIndexed { k, event ->
                b.add(
                    id = "$prefix-ev2year-${y.index}-$k",
                    category = category,
                    difficulty = Difficulty.MEDIUM,
                    text = "«$event» $periodName کے کس سال میں پیش آیا؟",
                    correct = yearLabel(y),
                    wrong = allYears.filter { it.index != y.index }.map { yearLabel(it) },
                    explanation = "یہ واقعہ ${yearLabel(y)} (${y.ceYear}ء) میں پیش آیا۔"
                )
            }

            // year -> event
            events.firstOrNull()?.let { correctEvent ->
                b.add(
                    id = "$prefix-year2ev-${y.index}",
                    category = category,
                    difficulty = Difficulty.HARD,
                    text = "$periodName کے ${y.index} ویں سال کا واقعہ کون سا ہے؟",
                    correct = correctEvent,
                    wrong = allYears.filter { it.index != y.index }.flatMap { uniqueEvents(it) },
                    explanation = "$correctEvent ۔ ${yearLabel(y)} (${y.ceYear}ء)"
                )
            }
        }

        if (isNabuwat) {
            val s = QuizCategory.NABUWAT
            b.add("nabuwat-hira", s, Difficulty.EASY,
                "پہلی وحی کہاں نازل ہوئی؟", "غار حرا",
                listOf("غار ثور", "کوہ صفا", "مسجد قباء", "مسجد عداس"),
                "پہلی وحی (اقرا) غار حرا میں نازل ہوئی۔")
            b.add("nabuwat-age", s, Difficulty.EASY,
                "پہلی وحی کے وقت نبی ﷺ کی عمر کتنی تھی؟", "چالیس سال",
                listOf("پچیس سال", "تیس سال", "پینتالیس سال", "تریسٹھ سال"),
                "نبوت کے وقت عمر چالیس سال تھی۔")
            b.add("nabuwat-safa", s, Difficulty.MEDIUM,
                "رسالت کا اعلان کس پہاڑی پر چڑھ کر کیا گیا؟", "کوہ صفا",
                listOf("کوہ احد", "جبل رحمت", "غار حرا", "جبل ثور"),
                "چوتھے سال نبوت میں کوہ صفا پر چڑھ کر رسالت کا اظہار کیا گیا۔")
            b.add("nabuwat-mairaj-date", s, Difficulty.EASY,
                "واقعہ معراج کس تاریخ کو بیان کیا جاتا ہے؟", "27 رجب",
                listOf("12 ربیع الاول", "17 رمضان", "10 محرم", "9 ذی الحجہ"),
                "دستاویز کے مطابق واقعہ معراج 27 رجب کو پیش آیا۔")
            b.add("nabuwat-prayers", s, Difficulty.EASY,
                "پانچ نمازیں کس موقع پر فرض ہوئیں؟", "واقعہ معراج",
                listOf("ہجرت مدینہ", "فتح مکہ", "صلح حدیبیہ", "حجۃ الوداع"),
                "پانچ نمازوں کی فرضیت واقعہ معراج میں ہوئی۔")
            b.add("nabuwat-habsha-leader", s, Difficulty.MEDIUM,
                "ہجرت حبشہ کے قافلے کے رئیس کون تھے؟", "عثمان بن عفان",
                SAHABA.filter { !it.startsWith("عثمان") },
                "دونوں ہجرت حبشہ کے قافلوں کے رئیس عثمان بن عفان رضی اللہ عنہ تھے۔")
            b.add("nabuwat-musab", s, Difficulty.HARD,
                "بیعت عقبہ کے بعد مدینہ کے پہلے مبلغ کون تھے؟", "مصعب بن عمیر",
                SAHABA,
                "مدینہ کے مبلغ مصعب بن عمیر رضی اللہ عنہ تھے۔")
            b.add("nabuwat-addas", s, Difficulty.HARD,
                "طائف میں نبی ﷺ کو انگور کس غلام نے پیش کیے؟", "عداس",
                listOf("زید بن حارثہ", "سلمان فارسی", "مطعم بن عدی", "ورقہ بن نوفل"),
                "عتبہ بن ربیعہ کے غلام حضرت عداس نے انگور پیش کیے۔")
            b.add("nabuwat-hijrat-companion", s, Difficulty.EASY,
                "ہجرت مدینہ میں غار ثور میں نبی ﷺ کے ساتھ کون تھے؟", "ابو بکر صدیق",
                SAHABA.filter { !it.startsWith("ابو بکر") },
                "ہجرت مدینہ ابوبکر صدیق رضی اللہ عنہ کے ساتھ ہوئی اور غار ثور میں پناہ لی۔")
            b.add("nabuwat-amulhuzn", s, Difficulty.MEDIUM,
                "عام الحزن میں کن کی وفات ہوئی؟", "ابو طالب اور خدیجہ رضی اللہ عنہا",
                listOf("ابو طالب اور آمنہ", "حمزہ اور ابو طالب", "عبد المطلب اور خدیجہ", "ابو لہب اور خدیجہ"),
                "دسویں سال نبوت (عام الحزن) میں ابو طالب اور حضرت خدیجہ کی وفات ہوئی۔")
        } else {
            val s = QuizCategory.HIJRAT
            b.add("hijrat-jumma", s, Difficulty.EASY,
                "پہلی نماز جمعہ کہاں ادا کی گئی؟", "مسجد قباء",
                listOf("مسجد نبوی", "مسجد حرام", "مسجد عداس", "مسجد ضرار"),
                "دستاویز کے مطابق پہلی نماز جمعہ مسجد قباء میں ہوئی۔")
            b.add("hijrat-orphans", s, Difficulty.MEDIUM,
                "مسجد نبوی کی جگہ کن دو یتیم بچوں کی تھی؟", "سہل اور سہیل",
                listOf("حسن اور حسین", "قاسم اور ابراہیم", "عبداللہ اور اسامہ", "جعفر اور حمزہ"),
                "مسجد نبوی کی جگہ دو یتیم بچوں سہل اور سہیل کی تھی۔")
            b.add("hijrat-ansar", s, Difficulty.EASY,
                "ہجرت کے بعد کس کے درمیان بھائی چارہ قائم ہوا؟", "مہاجرین اور انصار",
                listOf("قریش اور یہود", "بنو ہاشم اور بنو امیہ", "اوس اور خزرج", "مسلمان اور منافق"),
                "مہاجر اور انصار کے درمیان بھائی چارہ قائم کیا گیا۔")
            b.add("hijrat-usama", s, Difficulty.MEDIUM,
                "روم کی طرف بھیجے گئے لشکر کے سپہ سالار کون تھے؟", "اسامہ بن زید",
                listOf("خالد بن ولید", "زید بن حارثہ", "علی بن ابی طالب", "عمر بن خطاب"),
                "لشکر روم کی سپہ سالاری اسامہ بن زید رضی اللہ عنہ کے سپرد ہوئی۔")
            b.add("hijrat-munafiq", s, Difficulty.MEDIUM,
                "مدینہ کے منافقین کا سردار کون تھا؟", "عبداللہ بن ابی",
                listOf("کعب بن اشرف", "ابو جہل", "ابو لہب", "عتبہ بن ربیعہ"),
                "منافق عبداللہ بن ابی اور اس کے ساتھی مسلمانوں کے ساتھ رہتے تھے۔")
            b.add("hijrat-zirar", s, Difficulty.MEDIUM,
                "غزوہ تبوک کے سال کون سی مسجد گرائی گئی؟", "مسجد ضرار",
                listOf("مسجد قباء", "مسجد نبوی", "مسجد عداس", "مسجد حرام"),
                "9 ہجری میں مسجد ضرار مسمار کی گئی۔")
        }
        return b.out
    }

    // ------------------------------------------------------------------ Ghazwat

    private fun ghazwatQuestions(data: QuizData, random: Random): List<QuizQuestion> {
        val b = Builder(random)
        val s = QuizCategory.GHAZWAT
        val items = data.ghazwat.filter { it.dataNotes.isEmpty() }

        fun label(g: Ghazwa) =
            if (g.kind == "ghazwa") "غزوہ ${g.name}" else g.name

        // one "which event happened in year N" question per year (the first entry of that year)
        val firstOfYear = items.groupBy { it.hijriYear }.mapValues { it.value.first().id }

        for (g in items) {
            val famous = g.id in FAMOUS_GHAZWAT
            val l = label(g)

            b.add(
                "ghazwat-year-${g.id}", s,
                if (famous) Difficulty.EASY else Difficulty.MEDIUM,
                "$l کس سال ہجری میں ہوا؟",
                ah(g.hijriYear),
                nearby(g.hijriYear, 1, 10).map { ah(it) },
                "$l ${g.hijriYear} ہجری (${g.ceYear}ء) میں ہوا۔"
            )
            b.add(
                "ghazwat-place-${g.id}", s,
                if (famous) Difficulty.MEDIUM else Difficulty.HARD,
                "$l کس مقام پر ہوا؟",
                g.place,
                items.map { it.place },
                "$l کا مقام: ${g.place}۔"
            )
            if (firstOfYear[g.hijriYear] == g.id) {
                b.add(
                    "ghazwat-inyear-${g.id}", s,
                    Difficulty.HARD,
                    "${g.hijriYear} ہجری میں کون سا غزوہ یا واقعہ پیش آیا؟",
                    l,
                    items.filter { it.hijriYear != g.hijriYear }.map { label(it) },
                    "$l ${g.hijriYear} ہجری میں ہوا۔"
                )
            }
        }

        b.add("ghazwat-badr-date", s, Difficulty.EASY,
            "غزوہ بدر کس تاریخ کو ہوا؟", "17 رمضان",
            listOf("12 ربیع الاول", "27 رجب", "10 محرم", "9 ذی الحجہ"),
            "غزوہ بدر 17 رمضان 2 ہجری کو ہوا۔")
        b.add("ghazwat-badr-prisoners", s, Difficulty.EASY,
            "غزوہ بدر میں کتنے قیدی بنائے گئے؟", "ستر",
            listOf("تیس", "ایک سو", "تین سو تیرہ", "دو سو"),
            "غزوہ بدر میں ستر قیدی بنائے گئے۔")
        b.add("ghazwat-badr-abujahl", s, Difficulty.EASY,
            "غزوہ بدر میں کافروں کا کون سا سردار مارا گیا؟", "ابو جہل",
            listOf("ابو لہب", "ابو طالب", "ابو سفیان", "ورقہ بن نوفل"),
            "غزوہ بدر میں ابو جہل قتل ہوا۔")
        return b.out
    }

    // ------------------------------------------------------------------ Family (incl. children)

    private fun familyQuestions(data: QuizData, random: Random): List<QuizQuestion> {
        val b = Builder(random)
        val s = QuizCategory.FAMILY
        val f = data.family

        fun group(id: String) = f.groups.firstOrNull { it.id == id }
        val uncles = group("uncles")?.members.orEmpty()
        val aunts = group("aunts")?.members.orEmpty()
        val uncleNames = uncles.map { it.name.clean().substringBefore(" بن").trim() }
        val ummahatFull = data.ummahat
            .filter { it.fatherName.startsWith("بنت") }
            .map { "${it.name} ${it.fatherName}" }
        val ummahatFirst = data.ummahat.map { it.name }

        // parents and grandfather
        group("father")?.members?.firstOrNull()?.let { father ->
            b.add("family-father", s, Difficulty.EASY,
                "نبی ﷺ کے والد کا نام کیا تھا؟", father.name.clean(),
                uncles.map { it.name.clean() },
                "نبی ﷺ کے والد عبداللہ بن عبد المطلب تھے۔")
        }
        group("mother")?.members?.firstOrNull()?.let { mother ->
            b.add("family-mother", s, Difficulty.EASY,
                "نبی ﷺ کی والدہ کا نام کیا تھا؟", mother.name.clean(),
                ummahatFull,
                "نبی ﷺ کی والدہ آمنہ بنت وہب (بنی زہرہ) تھیں۔")
        }
        group("grandfather")?.members?.firstOrNull()?.let { gf ->
            b.add("family-grandfather", s, Difficulty.EASY,
                "نبی ﷺ کے دادا کا نام کیا تھا؟", gf.name.clean(),
                uncleNames,
                "دادا عبد المطلب تھے، ان کا اصل نام شیبہ تھا۔")
        }

        // uncles and aunts
        val famousUncles = setOf("حمزہ", "عباس", "ابو طالب", "ابو لہب")
        uncles.forEachIndexed { i, u ->
            val short = u.name.clean().substringBefore(" بن").trim()
            b.add("family-uncle-$i", s,
                if (short in famousUncles) Difficulty.EASY else Difficulty.HARD,
                "درج ذیل میں سے کون نبی ﷺ کے چچا تھے؟", short,
                SAHABA.filter { !it.startsWith(short) } + ummahatFirst,
                "$short نبی ﷺ کے چچا اور عبد المطلب کے بیٹے تھے۔")
        }
        aunts.forEachIndexed { i, a ->
            val short = a.name.clean()
            b.add("family-aunt-$i", s,
                if (short == "صفیہ") Difficulty.EASY else Difficulty.HARD,
                "درج ذیل میں سے کون نبی ﷺ کی پھوپھی تھیں؟", short,
                ummahatFirst.filter { it != short } + listOf("آمنہ", "حلیمہ"),
                "$short نبی ﷺ کی پھوپھی تھیں۔")
        }

        // personal details
        b.add("family-birth-year", s, Difficulty.EASY,
            "نبی ﷺ کی ولادت کس عیسوی سال میں ہوئی؟", ce(f.birth.ceYear),
            listOf(570, 576, 578, 586, 580).map { ce(it) },
            "ولادت ${f.birth.ceYear}ء (${f.birth.event}) میں ہوئی۔")
        b.add("family-birth-date", s, Difficulty.EASY,
            "نبی ﷺ کی ولادت کس تاریخ کو ہوئی؟", f.birth.date,
            listOf("27 رجب", "17 رمضان", "10 محرم", "9 ذی الحجہ"),
            "ولادت ${f.birth.date} کو مکہ میں ہوئی۔")
        b.add("family-kunyat", s, Difficulty.EASY,
            "نبی ﷺ کی کنیت کیا تھی؟", f.kunyat,
            listOf("ابو لہب", "ابو طالب", "ابو بکر", "ابو جہل"),
            "نبی ﷺ کی کنیت ${f.kunyat} تھی۔")
        b.add("family-laqab", s, Difficulty.EASY,
            "نبوت سے پہلے نبی ﷺ کا مشہور لقب کیا تھا؟", f.laqab,
            listOf("فاروق", "صدیق", "ذو النورین", "اسد اللہ"),
            "نبی ﷺ کا لقب ${f.laqab} تھا۔")
        f.tribe.firstOrNull()?.let { tribe ->
            b.add("family-tribe", s, Difficulty.EASY,
                "نبی ﷺ کا تعلق کس خاندان سے تھا؟", tribe,
                listOf("بنو نضیر", "بنی مصطلق", "بنو ثقیف", "بنو قریظہ"),
                "نبی ﷺ بنو ہاشم (قریش) سے تھے۔")
        }
        b.add("family-foster", s, Difficulty.MEDIUM,
            "بچپن میں نبی ﷺ نے کس کے پاس رضاعت کا زمانہ گزارا؟", "حلیمہ سعدیہ",
            listOf("آمنہ", "خدیجہ", "فاطمہ", "صفیہ"),
            "رضاعی ماؤں میں ثوبیہ اور حلیمہ سعدیہ رضی اللہ عنہما شامل ہیں۔")

        // children
        val daughters = data.aulad.filter { it.id in setOf("zaynab", "ruqayya", "umm-kulthum", "fatima") }
        val sons = data.aulad.filter { it.id in setOf("qasim", "abdullah", "ibrahim") }
        daughters.forEach { d ->
            b.add("aulad-daughter-${d.id}", s, Difficulty.EASY,
                "درج ذیل میں سے کون نبی ﷺ کی صاحبزادی تھیں؟", d.name,
                listOf("عائشہ", "حفصہ", "سودہ", "میمونہ", "جویریہ", "ماریہ"),
                "${d.name} نبی ﷺ کی صاحبزادی تھیں۔")
        }
        sons.forEach { c ->
            b.add("aulad-son-${c.id}", s, Difficulty.MEDIUM,
                "درج ذیل میں سے کون نبی ﷺ کے صاحبزادے تھے؟", c.name,
                listOf("حسن", "حسین", "علی", "زید"),
                "${c.name} نبی ﷺ کے صاحبزادے تھے۔")
        }
        data.aulad.forEach { c ->
            val birth = c.birthCeYear
            if (birth != null && c.id !in SKIP_CHILD_BIRTH) {
                b.add("aulad-birth-${c.id}", s, Difficulty.HARD,
                    "${c.name} کی ولادت کس عیسوی سال میں ہوئی؟", ce(birth),
                    nearby(birth, 570, 640, 3).map { ce(it) },
                    "${c.name} کی ولادت ${birth}ء میں ہوئی۔")
            }
            val wafat = c.wafat
            if (wafat != null && wafat.era == "hijri" && c.id !in SKIP_CHILD_WAFAT) {
                b.add("aulad-wafat-${c.id}", s, Difficulty.HARD,
                    "${c.name} کی وفات کس سال ہجری میں ہوئی؟", ah(wafat.year),
                    nearby(wafat.year, 1, 11).map { ah(it) },
                    "${c.name} کی وفات ${eraText(wafat)} میں ہوئی۔")
            }
        }
        return b.out
    }

    // ------------------------------------------------------------------ Ummahat ul Momineen

    private fun ummahatQuestions(data: QuizData, random: Random): List<QuizQuestion> {
        val b = Builder(random)
        val s = QuizCategory.UMMAHAT
        val list = data.ummahat

        fun full(u: UmmulMomineen) = "${u.name} ${u.fatherName}"
        fun asked(u: UmmulMomineen) = "${full(u)} رضی اللہ عنہا"
        val fathers = list.filter { it.fatherName.startsWith("بنت") }
            .map { it.fatherName.removePrefix("بنت").trim() }

        for (u in list) {
            val famous = u.id in setOf("khadija", "aisha", "hafsa")

            // whose daughter (skipped when another wife has the same first name, e.g. the two Zaynabs)
            val sameFirstName = list.count { it.name == u.name } > 1
            if (u.fatherName.startsWith("بنت") && !sameFirstName) {
                val father = u.fatherName.removePrefix("بنت").trim()
                b.add("ummahat-father-${u.id}", s,
                    if (famous) Difficulty.EASY else Difficulty.MEDIUM,
                    "${u.name} رضی اللہ عنہا کس کی صاحبزادی تھیں؟", father,
                    fathers,
                    "${full(u)} ۔ والد: $father")
            }

            // death year
            val wafat = u.wafat
            if (wafat != null && u.id !in SKIP_WAFAT) {
                val (correct, wrong) = when (wafat.era) {
                    "hijri" -> ah(wafat.year) to nearby(wafat.year, 1, 70, 2).map { ah(it) }
                    "nabawi" -> nabawi(wafat.year) to nearby(wafat.year, 1, 13).map { nabawi(it) }
                    else -> ce(wafat.year) to nearby(wafat.year, 500, 700, 2).map { ce(it) }
                }
                b.add("ummahat-wafat-${u.id}", s,
                    if (famous) Difficulty.MEDIUM else Difficulty.HARD,
                    "${asked(u)} کی وفات کس سال میں ہوئی؟", correct, wrong,
                    "${full(u)} کی وفات ${eraText(wafat)} میں ہوئی۔")
            }

            // nikah year
            val nikah = u.nikah
            if (nikah != null && u.id !in SKIP_NIKAH) {
                when (nikah.era) {
                    "hijri" -> b.add("ummahat-nikah-${u.id}", s, Difficulty.HARD,
                        "${asked(u)} کا نکاح نبی ﷺ سے کس سال ہجری میں ہوا؟", ah(nikah.year),
                        nearby(nikah.year, 1, 10).map { ah(it) },
                        "${full(u)} کا نکاح ${eraText(nikah)} میں ہوا۔")
                    "nabawi" -> b.add("ummahat-nikah-${u.id}", s, Difficulty.HARD,
                        "${asked(u)} کا نکاح نبی ﷺ سے کس سال نبوی میں ہوا؟", nabawi(nikah.year),
                        nearby(nikah.year, 1, 13).map { nabawi(it) },
                        "${full(u)} کا نکاح ${eraText(nikah)} میں ہوا۔")
                    "qabl_nabuwat" -> b.add("ummahat-nikah-${u.id}", s, Difficulty.MEDIUM,
                        "${asked(u)} کا نکاح نبوت سے کتنے سال پہلے ہوا؟", "${nikah.year} سال پہلے",
                        nearby(nikah.year, 1, 40, 3).map { "$it سال پہلے" },
                        "${full(u)} کا نکاح نبوت سے ${nikah.year} سال پہلے ہوا۔")
                }
            }

            // number of hadith
            val ahadees = u.ahadees
            if (ahadees != null && u.id !in SKIP_AHADEES) {
                val candidates = listOf(0.5, 0.7, 1.4, 1.8)
                    .map { (ahadees * it).roundToInt() } + listOf(ahadees + 3, ahadees + 6)
                b.add("ummahat-ahadees-${u.id}", s, Difficulty.HARD,
                    "${asked(u)} سے کتنی احادیث مروی ہیں؟", "$ahadees",
                    candidates.filter { it > 0 }.map { "$it" },
                    "${full(u)} سے $ahadees احادیث مروی ہیں۔")
            }

            // kunyat -> who
            val kunyat = u.kunyat
            if (kunyat != null) {
                b.add("ummahat-kunyat-${u.id}", s, Difficulty.MEDIUM,
                    "کنیت «$kunyat» کس ام المومنین کی تھی؟", full(u),
                    list.filter { it.id != u.id }.map { full(it) },
                    "$kunyat ۔ ${full(u)} کی کنیت تھی۔")
            }
        }

        // tribe (only where the answer is clearly different from Quraysh sub-clans)
        for (id in listOf("safiyya", "juwayriyya")) {
            val u = list.firstOrNull { it.id == id } ?: continue
            val tribe = u.tribe ?: continue
            b.add("ummahat-tribe-$id", s, Difficulty.MEDIUM,
                "${u.name} رضی اللہ عنہا کا تعلق کس قبیلے سے تھا؟", tribe,
                listOf("بنو ہاشم", "بنو ثقیف", "بنو قریظہ", "بنی قینقاع", "بنی زہرہ"),
                "${full(u)} کا قبیلہ: $tribe")
        }
        return b.out
    }

    // ------------------------------------------------------------------ Awwaleen

    private fun awwaleenQuestions(data: QuizData, random: Random): List<QuizQuestion> {
        val b = Builder(random)
        val s = QuizCategory.AWWALEEN
        fun group(id: String) = data.awwaleen.firstOrNull { it.id == id }
        val ummahatFirst = data.ummahat.map { it.name }
        val uncleNames = data.family.groups.firstOrNull { it.id == "uncles" }?.members.orEmpty()
            .map { it.name.clean().substringBefore(" بن").trim() }

        group("first-martyrs").item("مرد")?.clean()?.let { man ->
            b.add("awwaleen-martyr-man", s, Difficulty.EASY,
                "اسلام کے پہلے شہید (مرد) کون تھے؟", man, SAHABA,
                "اسلام کے پہلے شہید $man تھے۔")
        }
        group("first-martyrs").item("خاتون")?.clean()?.let { woman ->
            b.add("awwaleen-martyr-woman", s, Difficulty.EASY,
                "اسلام کی پہلی شہیدہ کون تھیں؟", woman,
                data.ummahat.filter { it.fatherName.startsWith("بنت") }.map { "${it.name} ${it.fatherName}" },
                "اسلام کی پہلی شہیدہ $woman تھیں۔")
        }
        group("first-muslims").item("خواتین")?.clean()?.let { woman ->
            b.add("awwaleen-muslim-woman", s, Difficulty.EASY,
                "خواتین میں سب سے پہلے اسلام کس نے قبول کیا؟", woman,
                ummahatFirst.filter { it != woman },
                "خواتین میں سب سے پہلے $woman رضی اللہ عنہا نے اسلام قبول کیا۔")
        }
        group("first-muslims").item("مردوں")?.clean()?.let { man ->
            b.add("awwaleen-muslim-man", s, Difficulty.EASY,
                "مردوں میں سب سے پہلے اسلام کس نے قبول کیا؟", man,
                SAHABA.filter { it != man },
                "مردوں میں سب سے پہلے $man رضی اللہ عنہ نے اسلام قبول کیا۔")
        }
        group("first-muslims").item("بچوں")?.clean()?.let { child ->
            b.add("awwaleen-muslim-child", s, Difficulty.MEDIUM,
                "بچوں میں سب سے پہلے اسلام کس نے قبول کیا؟", child,
                listOf("عثمان", "عمر", "حسن", "حسین"),
                "بچوں میں سب سے پہلے $child رضی اللہ عنہ نے اسلام قبول کیا۔")
        }
        b.add("awwaleen-sham-who", s, Difficulty.MEDIUM,
            "12 سال کی عمر میں نبی ﷺ نے کس کے ساتھ شام کا سفر کیا؟", "ابو طالب",
            uncleNames.filter { it != "ابو طالب" },
            "586ء میں 12 سال کی عمر میں نبی ﷺ نے ابو طالب کے ساتھ شام کا سفر کیا۔")
        b.add("awwaleen-sham-year", s, Difficulty.HARD,
            "نبی ﷺ کا پہلا سفر شام کس عیسوی سال میں ہوا؟", ce(586),
            nearby(586, 570, 600, 3).map { ce(it) },
            "سفر شام 586ء میں ہوا۔")
        b.add("awwaleen-waraqa", s, Difficulty.MEDIUM,
            "ابتدائی دور میں نبوت کی تصدیق کس نے کی؟", "ورقہ بن نوفل",
            listOf("ابو لہب", "ابو جہل", "ابو طالب", "مطعم بن عدی"),
            "ورقہ بن نوفل نے نبوت کی تصدیق کی۔")
        return b.out
    }
}
