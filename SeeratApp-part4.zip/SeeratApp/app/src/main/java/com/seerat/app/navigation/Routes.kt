package com.seerat.app.navigation

import androidx.annotation.StringRes
import com.seerat.app.R

object Routes {
    const val SPLASH = "splash"
    const val WELCOME = "welcome"
    const val HOME = "home"
    const val SETTINGS = "settings"
    const val SECTION = "section/{id}"
    const val UMMAHAT_DETAIL = "ummahat/{id}"

    fun section(id: String) = "section/$id"
    fun ummahatDetail(id: String) = "ummahat/$id"
}

/** Home screen sections. Real screens replace the placeholders in later parts. */
enum class Section(val id: String, @StringRes val titleRes: Int) {
    TIMELINE("timeline", R.string.section_timeline),
    GHAZWAT("ghazwat", R.string.section_ghazwat),
    FAMILY("family", R.string.section_family),
    UMMAHAT("ummahat", R.string.section_ummahat),
    AULAD("aulad", R.string.section_aulad),
    AWWALEEN("awwaleen", R.string.section_awwaleen),
    QUIZ("quiz", R.string.section_quiz);

    companion object {
        fun fromId(id: String?): Section? = entries.firstOrNull { it.id == id }
    }
}
