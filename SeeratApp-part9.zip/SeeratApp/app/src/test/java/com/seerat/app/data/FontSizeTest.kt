package com.seerat.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FontSizeTest {

    @Test
    fun unknownOrMissingNameGivesNormal() {
        assertEquals(FontSize.NORMAL, FontSize.fromName(null))
        assertEquals(FontSize.NORMAL, FontSize.fromName("HUGE"))
        assertEquals(FontSize.LARGE, FontSize.fromName("LARGE"))
    }

    @Test
    fun scalesGrowInOrder() {
        val scales = FontSize.entries.map { it.scale }
        assertEquals(scales.sorted(), scales)
        assertTrue(FontSize.NORMAL.scale == 1.0f)
    }
}
