package com.seerat.app.data

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Checks that all JSON files parse and agree with each other. Runs on the JVM, no device needed. */
class DataIntegrityTest {

    private fun read(name: String): String =
        File("src/main/assets/data/$name").readText(Charsets.UTF_8)

    @Test
    fun timelineHasAllYears() {
        val t = DataParser.timeline(read("timeline.json"))
        assertEquals((1..13).toList(), t.nabuwat.map { it.index })
        assertEquals((1..10).toList(), t.hijrat.map { it.index })
        assertTrue(t.nabuwat.all { it.events.isNotEmpty() })
        assertTrue(t.hijrat.all { it.events.isNotEmpty() })
        // 1 Nabuwat = 610 CE, 1 Hijrat = 623 CE in the source document
        assertEquals(610, t.nabuwat.first().ceYear)
        assertEquals(623, t.hijrat.first().ceYear)
    }

    @Test
    fun ghazwatMatchTimelineYears() {
        val t = DataParser.timeline(read("timeline.json"))
        val years = t.hijrat.associate { it.index to it.ceYear }
        val items = DataParser.ghazwat(read("ghazwat.json")).items
        assertTrue(items.isNotEmpty())
        for (g in items) {
            assertEquals("CE year of ${g.id}", years[g.hijriYear], g.ceYear)
            val events = t.hijrat.first { it.index == g.hijriYear }.events.joinToString(" ")
            assertTrue("${g.id} missing from timeline", events.contains(g.name))
        }
        assertEquals(items.size, items.map { it.id }.toSet().size)
    }

    @Test
    fun ummahatAndAulad() {
        val u = DataParser.ummahat(read("ummahat.json")).items
        assertEquals(12, u.size)
        assertEquals(u.size, u.map { it.id }.toSet().size)
        val aulad = DataParser.aulad(read("aulad.json")).items
        assertEquals(7, aulad.size)
    }

    @Test
    fun familyAndAwwaleen() {
        val f = DataParser.family(read("family.json"))
        assertEquals(571, f.birth.ceYear)
        assertEquals(6, f.groups.size)
        assertEquals(11, f.groups.first { it.id == "uncles" }.members.size)
        assertTrue(DataParser.awwaleen(read("awwaleen.json")).groups.isNotEmpty())
    }
}
