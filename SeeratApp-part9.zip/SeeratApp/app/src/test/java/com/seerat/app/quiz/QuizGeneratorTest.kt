package com.seerat.app.quiz

import com.seerat.app.data.DataParser
import java.io.File
import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class QuizGeneratorTest {

    private fun read(name: String): String =
        File("src/main/assets/data/$name").readText(Charsets.UTF_8)

    private fun data() = QuizData(
        timeline = DataParser.timeline(read("timeline.json")),
        ghazwat = DataParser.ghazwat(read("ghazwat.json")).items,
        family = DataParser.family(read("family.json")),
        ummahat = DataParser.ummahat(read("ummahat.json")).items,
        aulad = DataParser.aulad(read("aulad.json")).items,
        awwaleen = DataParser.awwaleen(read("awwaleen.json")).groups
    )

    private fun check(q: QuizQuestion) {
        assertEquals("options of ${q.id}", 4, q.options.size)
        assertEquals("distinct options of ${q.id}", 4, q.options.toSet().size)
        assertTrue("correctIndex of ${q.id}", q.correctIndex in 0..3)
        assertTrue("text of ${q.id}", q.text.isNotBlank())
        assertTrue("explanation of ${q.id}", q.explanation.isNotBlank())
        assertTrue("difficulty of ${q.id}", q.difficulty != Difficulty.MIXED)
    }

    @Test
    fun allQuestionsAreValidAndIdsUnique() {
        val all = QuizGenerator.allQuestions(data(), Random(1))
        assertTrue(all.size > 100)
        all.forEach { check(it) }
        assertEquals("duplicate ids", all.size, all.map { it.id }.toSet().size)
    }

    @Test
    fun everyCategoryAndDifficultyGivesQuestions() {
        val d = data()
        for (category in QuizCategory.entries) {
            for (difficulty in Difficulty.entries) {
                val list = QuizGenerator.generate(d, category, difficulty, 10, Random(7))
                assertTrue("$category/$difficulty gave ${list.size}", list.size >= 8)
                list.forEach { check(it) }
                assertEquals(list.size, list.map { it.id }.toSet().size)
                if (category != QuizCategory.ALL) {
                    assertTrue(list.all { it.category == category })
                }
            }
        }
    }

    @Test
    fun disputedFactsAreNotAsked() {
        val ids = QuizGenerator.allQuestions(data(), Random(3)).map { it.id }.toSet()
        // see docs/data-notes.md
        assertTrue("aulad-birth-ibrahim" !in ids)
        assertTrue("aulad-wafat-zaynab" !in ids)
        assertTrue("ummahat-nikah-hafsa" !in ids)
        assertTrue("ummahat-wafat-sawda" !in ids)
        assertTrue("ummahat-ahadees-aisha" !in ids)
        assertTrue(ids.none { it.contains("rajee") || it.contains("bir-maona") })
    }
}
