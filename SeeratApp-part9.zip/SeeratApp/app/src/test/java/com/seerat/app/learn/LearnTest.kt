package com.seerat.app.learn

import com.seerat.app.data.DataParser
import com.seerat.app.quiz.QuizCategory
import com.seerat.app.quiz.QuizData
import java.io.File
import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LearnTest {

    private fun read(name: String): String =
        File("src/main/assets/data/$name").readText(Charsets.UTF_8)

    private fun data() = QuizData(
        timeline = DataParser.timeline(read("timeline.json")),
        ghazwat = DataParser.ghazwat(read("ghazwat.json")).items,
        family = DataParser.family(read("family.json")),
        ummahat = DataParser.ummahat(read("ummahat.json")).items,
        aulad = DataParser.aulad(read("aulad.json")).items,
        awwaleen = DataParser.awwaleen(read("awwaleen.json")).groups
    )

    @Test
    fun selfTestDecksAreNotEmptyAndIdsUnique() {
        val d = data()
        for (category in QuizCategory.entries) {
            val deck = DeckBuilder.deck(d, DeckBuilder.MODE_SELF, category.name, random = Random(1))
            assertTrue("$category deck is empty", deck.isNotEmpty())
            assertEquals(deck.size, deck.map { it.id }.toSet().size)
            assertTrue(deck.all { it.front.isNotBlank() && it.back.isNotBlank() })
        }
    }

    @Test
    fun hifzDecksCoverAllData() {
        val d = data()
        assertEquals(13, DeckBuilder.deck(d, DeckBuilder.MODE_HIFZ, HifzTopic.NABUWAT.name).size)
        assertEquals(10, DeckBuilder.deck(d, DeckBuilder.MODE_HIFZ, HifzTopic.HIJRAT.name).size)
        assertEquals(d.ghazwat.size, DeckBuilder.deck(d, DeckBuilder.MODE_HIFZ, HifzTopic.GHAZWAT.name).size)
        assertEquals(d.ummahat.size, DeckBuilder.deck(d, DeckBuilder.MODE_HIFZ, HifzTopic.UMMAHAT.name).size)
    }

    @Test
    fun wrongDeckContainsOnlyWrongIds() {
        val d = data()
        val deck = DeckBuilder.deck(
            d, DeckBuilder.MODE_WRONG, "ALL",
            wrongIds = setOf("ghazwat-badr-date", "family-father", "does-not-exist"),
            random = Random(2)
        )
        assertEquals(setOf("ghazwat-badr-date", "family-father"), deck.map { it.id }.toSet())
    }

    @Test
    fun sessionPutsUnknownCardsFirst() {
        val deck = (1..20).map { StudyCard("c$it", "q$it", "a$it") }
        val known = (1..15).map { "c$it" }.toSet()
        val session = DeckBuilder.session(deck, known, Random(3))
        assertEquals(DeckBuilder.SESSION_SIZE, session.size)
        // the 5 unknown cards come first
        assertTrue(session.take(5).all { it.id !in known })
    }

    @Test
    fun matchRoundsHaveDistinctPairs() {
        val d = data()
        for (type in MatchType.entries) {
            repeat(20) { seed ->
                val round = MatchGenerator.round(d, type, Random(seed))
                assertEquals("$type size", MatchGenerator.ROUND_SIZE, round.size)
                assertEquals(round.size, round.map { it.left }.toSet().size)
                assertEquals(round.size, round.map { it.right }.toSet().size)
            }
        }
    }

    @Test
    fun orderRoundsAreChronologicalWithDistinctYears() {
        val d = data()
        for (type in OrderType.entries) {
            repeat(20) { seed ->
                val round = OrderGenerator.round(d, type, Random(seed))
                assertEquals("$type size", OrderGenerator.ROUND_SIZE, round.size)
                val keys = round.map { it.sortKey }
                assertEquals(keys.sorted(), keys)
                assertEquals(keys.size, keys.toSet().size)
            }
        }
    }
}
