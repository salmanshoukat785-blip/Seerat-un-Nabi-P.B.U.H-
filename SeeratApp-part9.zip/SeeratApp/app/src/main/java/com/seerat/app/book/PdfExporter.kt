package com.seerat.app.book

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.io.OutputStream

/** One piece of text in the PDF: a heading, a small line under it, and the body. */
data class PdfBlock(
    val chapter: String,
    val heading: String,
    val sub: String,
    val body: String
)

/**
 * Writes the book as an A4 PDF with Android's PdfDocument.
 * Text is laid out with StaticLayout so Urdu letters join correctly and read right to left.
 */
object PdfExporter {

    private const val PAGE_W = 595
    private const val PAGE_H = 842
    private const val MARGIN = 40
    private const val TEXT_W = PAGE_W - 2 * MARGIN

    private fun paint(size: Float, color: Int, bold: Boolean = false) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = size
        this.color = color
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private class Writer(private val doc: PdfDocument) {
        private var pageNumber = 0
        private var page: PdfDocument.Page? = null
        private var canvas: Canvas? = null
        private var y = MARGIN.toFloat()

        private fun newPage() {
            finish()
            pageNumber++
            val info = PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNumber).create()
            val p = doc.startPage(info)
            page = p
            canvas = p.canvas
            y = MARGIN.toFloat()
        }

        /** Starts a new page when less than [needed] points are left. */
        fun keepTogether(needed: Float) {
            if (page == null || y + needed > PAGE_H - MARGIN) newPage()
        }

        fun draw(text: String, paint: TextPaint, gapAfter: Float) {
            if (text.isBlank()) return
            val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, TEXT_W)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(0f, 1.3f)
                .build()
            for (i in 0 until layout.lineCount) {
                val top = layout.getLineTop(i)
                val bottom = layout.getLineBottom(i)
                keepTogether((bottom - top).toFloat())
                val c = canvas ?: return
                c.save()
                c.translate(MARGIN.toFloat(), y - top)
                c.clipRect(0f, top.toFloat(), TEXT_W.toFloat(), bottom.toFloat())
                layout.draw(c)
                c.restore()
                y += (bottom - top)
            }
            y += gapAfter
        }

        fun finish() {
            page?.let { doc.finishPage(it) }
            page = null
            canvas = null
        }
    }

    fun write(out: OutputStream, docTitle: String, blocks: List<PdfBlock>) {
        val green = Color.rgb(27, 94, 58)
        val gold = Color.rgb(150, 112, 20)
        val ink = Color.rgb(30, 30, 30)
        val grey = Color.rgb(90, 90, 90)

        val titlePaint = paint(26f, green, bold = true)
        val chapterPaint = paint(20f, gold, bold = true)
        val headingPaint = paint(16f, green, bold = true)
        val subPaint = paint(12f, grey)
        val bodyPaint = paint(13f, ink)

        val doc = PdfDocument()
        try {
            val w = Writer(doc)
            w.keepTogether(0f)
            w.draw(docTitle, titlePaint, 18f)
            var lastChapter: String? = null
            for (b in blocks) {
                if (b.chapter != lastChapter) {
                    w.keepTogether(120f)
                    w.draw(b.chapter, chapterPaint, 10f)
                    lastChapter = b.chapter
                }
                w.keepTogether(70f)
                w.draw(b.heading, headingPaint, 2f)
                w.draw(b.sub, subPaint, 4f)
                w.draw(b.body, bodyPaint, 14f)
            }
            w.finish()
            doc.writeTo(out)
        } finally {
            doc.close()
        }
    }
}
