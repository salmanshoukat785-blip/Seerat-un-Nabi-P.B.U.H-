package com.seerat.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.seerat.app.R
import com.seerat.app.quiz.ANSWER_TIMEOUT
import com.seerat.app.quiz.QuizUiState
import com.seerat.app.quiz.QuizViewModel
import com.seerat.app.ui.components.ContentCard
import com.seerat.app.ui.components.SeeratScaffold
import com.seerat.app.ui.theme.CorrectGreen
import com.seerat.app.ui.theme.WrongRed

@Composable
fun QuizPlayScreen(
    onExit: () -> Unit,
    onPlayAgain: () -> Unit,
    onHome: () -> Unit,
    viewModel: QuizViewModel = viewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    SeeratScaffold(
        title = stringResource(R.string.section_quiz),
        onBack = onExit
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when {
                state.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                state.failed -> Text(
                    text = stringResource(R.string.load_error),
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp)
                )
                state.finished -> ResultContent(
                    state = state,
                    onPlayAgain = onPlayAgain,
                    onHome = onHome
                )
                else -> QuestionContent(
                    state = state,
                    onSelect = viewModel::select,
                    onNext = viewModel::next
                )
            }
        }
    }
}

// ---------------------------------------------------------------------- question

@Composable
private fun QuestionContent(
    state: QuizUiState,
    onSelect: (Int) -> Unit,
    onNext: () -> Unit
) {
    val question = state.current ?: return
    val selected = state.selected
    val answered = selected != null

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        LinearProgressIndicator(
            progress = { (state.index + 1) / state.questions.size.toFloat() },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stringResource(R.string.quiz_question_of, state.index + 1, state.questions.size),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (state.timed) {
                Text(
                    text = stringResource(R.string.quiz_seconds, state.secondsLeft),
                    style = MaterialTheme.typography.titleMedium,
                    color = if (state.secondsLeft <= 5 && !answered) WrongRed
                    else MaterialTheme.colorScheme.primary
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        ContentCard {
            Text(
                text = question.text,
                style = MaterialTheme.typography.titleLarge
            )
        }

        Spacer(Modifier.height(12.dp))
        question.options.forEachIndexed { index, option ->
            OptionCard(
                text = option,
                isCorrect = index == question.correctIndex,
                isSelected = index == selected,
                answered = answered,
                onClick = { onSelect(index) }
            )
            Spacer(Modifier.height(8.dp))
        }

        if (answered) {
            Spacer(Modifier.height(4.dp))
            Feedback(
                correct = selected == question.correctIndex,
                timedOut = selected == ANSWER_TIMEOUT,
                correctAnswer = question.correctAnswer,
                explanation = question.explanation
            )
            Spacer(Modifier.height(16.dp))
            val last = state.index + 1 == state.questions.size
            Button(
                onClick = onNext,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Text(
                    text = stringResource(if (last) R.string.quiz_finish else R.string.quiz_next),
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }
    }
}

@Composable
private fun OptionCard(
    text: String,
    isCorrect: Boolean,
    isSelected: Boolean,
    answered: Boolean,
    onClick: () -> Unit
) {
    // Colour is always paired with an icon, so it is clear without relying on colour alone.
    val tint: Color? = when {
        answered && isCorrect -> CorrectGreen
        answered && isSelected -> WrongRed
        else -> null
    }
    val container = tint?.copy(alpha = 0.16f) ?: MaterialTheme.colorScheme.surface
    val border = tint ?: MaterialTheme.colorScheme.surfaceVariant

    Card(
        onClick = onClick,
        enabled = !answered,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = container,
            contentColor = MaterialTheme.colorScheme.onSurface,
            disabledContainerColor = container,
            disabledContentColor = MaterialTheme.colorScheme.onSurface
        ),
        border = BorderStroke(if (tint != null) 2.dp else 1.dp, border)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.weight(1f)
            )
            if (answered && isCorrect) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = stringResource(R.string.cd_correct),
                    tint = CorrectGreen
                )
            } else if (answered && isSelected) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = stringResource(R.string.cd_wrong),
                    tint = WrongRed
                )
            }
        }
    }
}

@Composable
private fun Feedback(
    correct: Boolean,
    timedOut: Boolean,
    correctAnswer: String,
    explanation: String
) {
    val title = when {
        correct -> stringResource(R.string.quiz_correct)
        timedOut -> stringResource(R.string.quiz_timeout)
        else -> stringResource(R.string.quiz_wrong)
    }
    val color = if (correct) CorrectGreen else WrongRed
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (correct) Icons.Default.Check else Icons.Default.Close,
                contentDescription = null,
                tint = color
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = color
            )
        }
        if (!correct) {
            Text(
                text = stringResource(R.string.quiz_correct_answer, correctAnswer),
                style = MaterialTheme.typography.bodyLarge
            )
        }
        Text(
            text = explanation,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// ---------------------------------------------------------------------- result

@Composable
private fun ResultContent(
    state: QuizUiState,
    onPlayAgain: () -> Unit,
    onHome: () -> Unit
) {
    val total = state.questions.size
    val score = state.score
    val percent = if (total == 0) 0 else score * 100 / total
    val message = when {
        percent >= 80 -> R.string.quiz_msg_great
        percent >= 50 -> R.string.quiz_msg_good
        else -> R.string.quiz_msg_try
    }
    val wrongIndexes = state.questions.indices.filter {
        state.answers.getOrNull(it) != state.questions[it].correctIndex
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = stringResource(R.string.quiz_result_title),
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.quiz_score, score, total),
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.secondary
        )
        Text(
            text = stringResource(R.string.quiz_percent, percent),
            style = MaterialTheme.typography.titleMedium
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = stringResource(message),
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center
        )

        Spacer(Modifier.height(20.dp))
        Text(
            text = if (wrongIndexes.isEmpty()) {
                stringResource(R.string.quiz_all_right)
            } else {
                stringResource(R.string.quiz_review_title)
            },
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        wrongIndexes.forEach { i ->
            val q = state.questions[i]
            val chosen = state.answers.getOrNull(i)
            val yourAnswer = if (chosen == null || chosen == ANSWER_TIMEOUT) {
                stringResource(R.string.quiz_no_answer)
            } else {
                q.options[chosen]
            }
            ContentCard(modifier = Modifier.padding(bottom = 8.dp)) {
                Text(text = q.text, style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(6.dp))
                Text(
                    text = stringResource(R.string.quiz_your_answer, yourAnswer),
                    style = MaterialTheme.typography.bodyMedium,
                    color = WrongRed
                )
                Text(
                    text = stringResource(R.string.quiz_correct_answer, q.correctAnswer),
                    style = MaterialTheme.typography.bodyMedium,
                    color = CorrectGreen
                )
                Text(
                    text = q.explanation,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        Button(
            onClick = onPlayAgain,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text(
                text = stringResource(R.string.quiz_play_again),
                style = MaterialTheme.typography.titleMedium
            )
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = onHome,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(stringResource(R.string.quiz_go_home))
        }
        Spacer(Modifier.size(8.dp))
    }
}
