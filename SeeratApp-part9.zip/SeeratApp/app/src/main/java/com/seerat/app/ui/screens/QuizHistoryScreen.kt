package com.seerat.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.seerat.app.R
import com.seerat.app.SeeratApplication
import com.seerat.app.quiz.Difficulty
import com.seerat.app.quiz.QuizCategory
import com.seerat.app.quiz.QuizResult
import com.seerat.app.ui.components.ContentCard
import com.seerat.app.ui.components.SeeratScaffold
import java.text.DateFormat
import java.util.Date
import kotlinx.coroutines.launch

@Composable
fun QuizHistoryScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val repository = (context.applicationContext as SeeratApplication).quizRepository
    val history by repository.history.collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()

    SeeratScaffold(
        title = stringResource(R.string.quiz_history_title),
        onBack = onBack
    ) { padding ->
        if (history.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                Text(
                    text = stringResource(R.string.quiz_history_empty),
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp),
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(history) { result -> HistoryCard(result) }
                }
                OutlinedButton(
                    onClick = { scope.launch { repository.clearHistory() } },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(stringResource(R.string.quiz_clear_history))
                }
            }
        }
    }
}

@Composable
private fun HistoryCard(result: QuizResult) {
    val category = QuizCategory.entries.firstOrNull { it.name == result.category }
    val difficulty = Difficulty.entries.firstOrNull { it.name == result.difficulty }
    val date = DateFormat
        .getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
        .format(Date(result.timestamp))

    ContentCard {
        Text(
            text = if (category != null) stringResource(category.labelRes()) else result.category,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = stringResource(R.string.quiz_score, result.correct, result.total) +
                "  (" + stringResource(R.string.quiz_percent, result.percent) + ")",
            style = MaterialTheme.typography.titleLarge
        )
        val tags = buildList {
            if (difficulty != null) add(stringResource(difficulty.labelRes()))
            if (result.timed) add(stringResource(R.string.quiz_timed_tag))
            add(date)
        }
        Text(
            text = tags.joinToString(" · "),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
