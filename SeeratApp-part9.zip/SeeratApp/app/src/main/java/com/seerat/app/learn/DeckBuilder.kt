package com.seerat.app.learn

import com.seerat.app.data.model.EraYear
import com.seerat.app.data.model.Ghazwa
import com.seerat.app.data.model.UmmulMomineen
import com.seerat.app.quiz.QuizCategory
import com.seerat.app.quiz.QuizData
import com.seerat.app.quiz.QuizGenerator
import com.seerat.app.quiz.QuizQuestion
import kotlin.random.Random

enum class HifzTopic { NABUWAT, HIJRAT, GHAZWAT, UMMAHAT }

/**
 * One flashcard. [note] is extra explanation; [verify] holds "please verify" notes
 * from the source document (shown in the same hint box as elsewhere in the app).
 */
data class StudyCard(
    val id: String,
    val front: String,
    val back: String,
    val note: String? = null,
    val verify: List<String> = emptyList()
)

/** Builds flashcard decks from the data (pure Kotlin, no Android classes). */
object DeckBuilder {

    const val MODE_SELF = "self"      // cards made from quiz questions of one category
    const val MODE_HIFZ = "hifz"      // memorise years, events, profiles
    const val MODE_WRONG = "wrong"    // questions answered wrongly in quizzes

    const val SESSION_SIZE = 10

    fun deck(
        data: QuizData,
        mode: String,
        key: String,
        wrongIds: Set<String> = emptySet(),
        random: Random = Random.Default
    ): List<StudyCard> = when (mode) {
        MODE_SELF -> {
            val category = QuizCategory.entries.firstOrNull { it.name == key } ?: QuizCategory.ALL
            QuizGenerator.allQuestions(data, random)
                .filter { category == QuizCategory.ALL || it.category == category }
                .map { it.toCard() }
        }
        MODE_HIFZ -> hifzDeck(data, HifzTopic.entries.firstOrNull { it.name == key } ?: HifzTopic.NABUWAT)
        MODE_WRONG -> QuizGenerator.allQuestions(data, random)
            .filter { it.id in wrongIds }
            .map { it.toCard() }
        else -> emptyList()
    }

    /** Unknown cards first (random order), then known ones; at most [SESSION_SIZE]. */
    fun session(deck: List<StudyCard>, knownIds: Set<String>, random: Random = Random.Default): List<StudyCard> {
        val (known, unknown) = deck.partition { it.id in knownIds }
        return (unknown.shuffled(random) + known.shuffled(random)).take(SESSION_SIZE)
    }

    private fun QuizQuestion.toCard() = StudyCard(
        id = id,
        front = text,
        back = correctAnswer,
        note = explanation
    )

    // ------------------------------------------------------------------ hifz decks

    private fun hifzDeck(data: QuizData, topic: HifzTopic): List<StudyCard> = when (topic) {
        HifzTopic.NABUWAT -> data.timeline.nabuwat.map { y ->
            StudyCard(
                id = "hifz-nabuwat-${y.index}",
                front = "نبوت کا ${y.index} نبوی (${y.ceYear} ء)",
                back = y.events.joinToString("\n") { "• $it" },
                verify = y.dataNotes
            )
        }
        HifzTopic.HIJRAT -> data.timeline.hijrat.map { y ->
            StudyCard(
                id = "hifz-hijrat-${y.index}",
                front = "ہجرت کا ${y.index} ہجری (${y.ceYear} ء)",
                back = y.events.joinToString("\n") { "• $it" },
                verify = y.dataNotes
            )
        }
        HifzTopic.GHAZWAT -> data.ghazwat.map { g ->
            StudyCard(
                id = "hifz-ghazwat-${g.id}",
                front = ghazwaLabel(g),
                back = "${g.hijriYear} ہجری (${g.ceYear} ء)\nمقام: ${g.place}" +
                    g.notes.joinToString("") { "\n• $it" },
                verify = g.dataNotes
            )
        }
        HifzTopic.UMMAHAT -> data.ummahat.map { u ->
            StudyCard(
                id = "hifz-ummahat-${u.id}",
                front = "${u.name} ${u.fatherName} رضی اللہ عنہا",
                back = ummahatBack(u),
                verify = u.dataNotes
            )
        }
    }

    private fun ghazwaLabel(g: Ghazwa) = if (g.kind == "ghazwa") "غزوہ ${g.name}" else g.name

    private fun ummahatBack(u: UmmulMomineen): String = listOfNotNull(
        u.kunyat?.let { "کنیت: $it" },
        u.tribe?.let { "قبیلہ: $it" },
        u.nikah?.let { "نکاح: ${eraText(it)}" },
        u.wafat?.let { "وفات: ${eraText(it)}" },
        u.ahadees?.let { a ->
            "احادیث: $a" + (u.mutafaq?.let { " (متفق علیہ: $it)" } ?: "")
        }
    ).plus(u.notes).joinToString("\n")

    private fun eraText(e: EraYear): String {
        val base = when (e.era) {
            "qabl_nabuwat" -> "${e.year} سال قبل نبوت"
            "nabawi" -> "${e.year} نبوی"
            "hijri" -> "${e.year} ہجری"
            else -> "${e.year} ء"
        }
        return if (e.month != null) "$base · ${e.month}" else base
    }
}
