package com.seerat.app.learn

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.seerat.app.SeeratApplication
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MatchUiState(
    val loading: Boolean = true,
    val failed: Boolean = false,
    val pairs: List<MatchPair> = emptyList(),
    /** Display order of the left column: indexes into [pairs]. */
    val leftOrder: List<Int> = emptyList(),
    /** Display order of the right column: indexes into [pairs]. */
    val rightOrder: List<Int> = emptyList(),
    val selectedLeft: Int? = null,
    val matched: Set<Int> = emptySet(),
    val mistakes: Int = 0,
    /** Right item (pair index) that was tapped wrongly; shown red for a moment. */
    val flashRight: Int? = null
) {
    val finished: Boolean get() = pairs.isNotEmpty() && matched.size == pairs.size
}

class MatchViewModel(
    application: Application,
    savedStateHandle: SavedStateHandle
) : AndroidViewModel(application) {

    private val app = application as SeeratApplication
    private val type = MatchType.entries.firstOrNull { it.name == savedStateHandle.get<String>("type") }
        ?: MatchType.GHAZWA_YEAR

    private val _state = MutableStateFlow(MatchUiState())
    val state: StateFlow<MatchUiState> = _state.asStateFlow()

    init {
        newRound()
    }

    fun newRound() {
        _state.update { MatchUiState() }
        viewModelScope.launch {
            try {
                val data = app.repository.quizData()
                val pairs = MatchGenerator.round(data, type)
                if (pairs.size < 2) {
                    _state.update { it.copy(loading = false, failed = true) }
                } else {
                    _state.update {
                        it.copy(
                            loading = false,
                            pairs = pairs,
                            leftOrder = pairs.indices.shuffled(),
                            rightOrder = pairs.indices.shuffled()
                        )
                    }
                }
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, failed = true) }
            }
        }
    }

    fun tapLeft(pairIndex: Int) {
        _state.update { s ->
            if (pairIndex in s.matched) s
            else s.copy(selectedLeft = if (s.selectedLeft == pairIndex) null else pairIndex)
        }
    }

    fun tapRight(pairIndex: Int) {
        val s = _state.value
        val left = s.selectedLeft ?: return
        if (pairIndex in s.matched) return

        if (left == pairIndex) {
            _state.update { it.copy(matched = it.matched + pairIndex, selectedLeft = null) }
        } else {
            _state.update {
                it.copy(mistakes = it.mistakes + 1, selectedLeft = null, flashRight = pairIndex)
            }
            viewModelScope.launch {
                delay(600)
                _state.update { if (it.flashRight == pairIndex) it.copy(flashRight = null) else it }
            }
        }
    }
}
