package com.seerat.app.book

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.personalStore by preferencesDataStore(name = "personal")

/** Bookmarks and personal notes, saved on the phone only. Keys are BookEntry ids. */
class PersonalRepository(private val context: Context) {

    private object Keys {
        val BOOKMARKS = stringSetPreferencesKey("bookmarks")
        val NOTES = stringPreferencesKey("notes_json")
    }

    val bookmarks: Flow<Set<String>> =
        context.personalStore.data.map { it[Keys.BOOKMARKS] ?: emptySet() }

    val notes: Flow<Map<String, String>> =
        context.personalStore.data.map { decode(it[Keys.NOTES]) }

    suspend fun toggleBookmark(id: String) {
        context.personalStore.edit { prefs ->
            val current = prefs[Keys.BOOKMARKS] ?: emptySet()
            prefs[Keys.BOOKMARKS] = if (id in current) current - id else current + id
        }
    }

    /** A blank [text] removes the note. */
    suspend fun setNote(id: String, text: String) {
        context.personalStore.edit { prefs ->
            val map = decode(prefs[Keys.NOTES]).toMutableMap()
            if (text.isBlank()) map.remove(id) else map[id] = text.trim()
            prefs[Keys.NOTES] = Json.encodeToString(map.toMap())
        }
    }

    private fun decode(raw: String?): Map<String, String> {
        if (raw.isNullOrBlank()) return emptyMap()
        return try {
            Json.decodeFromString<Map<String, String>>(raw)
        } catch (e: Exception) {
            emptyMap()
        }
    }
}
