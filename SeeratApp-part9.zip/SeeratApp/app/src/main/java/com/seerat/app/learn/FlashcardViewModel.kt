package com.seerat.app.learn

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.seerat.app.SeeratApplication
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class FlashcardUiState(
    val loading: Boolean = true,
    val failed: Boolean = false,
    val isWrongMode: Boolean = false,
    val cards: List<StudyCard> = emptyList(),
    val index: Int = 0,
    val revealed: Boolean = false,
    val known: Int = 0,
    val review: Int = 0,
    val finished: Boolean = false
) {
    val current: StudyCard? get() = cards.getOrNull(index)
}

/**
 * One study session of up to 10 flashcards.
 * Arguments from the route: mode (self | hifz | wrong) and key (category or topic name).
 */
class FlashcardViewModel(
    application: Application,
    savedStateHandle: SavedStateHandle
) : AndroidViewModel(application) {

    private val app = application as SeeratApplication
    private val mode = savedStateHandle.get<String>("mode") ?: DeckBuilder.MODE_SELF
    private val key = savedStateHandle.get<String>("key") ?: "ALL"

    private val _state = MutableStateFlow(FlashcardUiState(isWrongMode = mode == DeckBuilder.MODE_WRONG))
    val state: StateFlow<FlashcardUiState> = _state.asStateFlow()

    init {
        load()
    }

    /** Starts a new session (also used by "Study again"). */
    fun load() {
        _state.update { FlashcardUiState(isWrongMode = mode == DeckBuilder.MODE_WRONG) }
        viewModelScope.launch {
            try {
                val data = app.repository.quizData()
                val known = app.learnRepository.knownIds.first()
                val wrong = app.quizRepository.wrongIds.first()
                val deck = DeckBuilder.deck(data, mode, key, wrong)
                val cards = DeckBuilder.session(deck, known)
                _state.update { it.copy(loading = false, cards = cards, finished = cards.isEmpty()) }
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, failed = true) }
            }
        }
    }

    fun reveal() {
        _state.update { if (it.current != null) it.copy(revealed = true) else it }
    }

    fun answer(known: Boolean) {
        val s = _state.value
        val card = s.current ?: return
        if (!s.revealed) return

        viewModelScope.launch {
            try {
                app.learnRepository.mark(card.id, known)
                if (known && mode == DeckBuilder.MODE_WRONG) {
                    app.quizRepository.removeWrong(card.id)
                }
            } catch (e: Exception) {
                // progress saving is best effort
            }
        }

        val last = s.index + 1 >= s.cards.size
        _state.update {
            it.copy(
                known = it.known + if (known) 1 else 0,
                review = it.review + if (known) 0 else 1,
                index = if (last) it.index else it.index + 1,
                revealed = false,
                finished = last
            )
        }
    }
}
