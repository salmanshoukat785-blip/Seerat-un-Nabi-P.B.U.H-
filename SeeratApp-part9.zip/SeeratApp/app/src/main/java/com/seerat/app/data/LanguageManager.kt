package com.seerat.app.data

import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

/**
 * Per-app language. AppCompat saves the choice and recreates the activity,
 * so layout direction (RTL for Urdu, LTR for English) switches automatically.
 */
object LanguageManager {
    const val URDU = "ur"
    const val ENGLISH = "en"

    fun current(): String {
        val locales = AppCompatDelegate.getApplicationLocales()
        return if (locales.isEmpty) URDU else locales[0]?.language ?: URDU
    }

    fun set(languageTag: String) {
        if (current() == languageTag && !AppCompatDelegate.getApplicationLocales().isEmpty) return
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(languageTag))
    }

    /** Urdu is the default on first launch. */
    fun ensureDefault() {
        if (AppCompatDelegate.getApplicationLocales().isEmpty) {
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(URDU))
        }
    }
}
