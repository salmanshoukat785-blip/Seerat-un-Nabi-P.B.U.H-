package com.seerat.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.seerat.app.R
import com.seerat.app.data.model.Family
import com.seerat.app.data.model.FamilyGroup
import com.seerat.app.ui.components.ContentCard
import com.seerat.app.ui.components.LabelValue
import com.seerat.app.ui.components.LoadedContent
import com.seerat.app.ui.components.SeeratScaffold

@Composable
fun FamilyScreen(onBack: () -> Unit) {
    SeeratScaffold(
        title = stringResource(R.string.section_family),
        onBack = onBack
    ) { padding ->
        LoadedContent(
            modifier = Modifier.padding(padding),
            loader = { it.family() }
        ) { family ->
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item { HeaderCard(family) }
                items(family.groups, key = { it.id }) { GroupCard(it) }
            }
        }
    }
}

@Composable
private fun HeaderCard(family: Family) {
    ContentCard {
        Text(
            text = family.title,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(8.dp))
        val b = family.birth
        LabelValue(
            label = stringResource(R.string.label_birth),
            value = listOf(
                stringResource(R.string.era_ce, b.ceYear),
                b.date,
                b.event,
                b.place
            ).joinToString(" · ")
        )
        LabelValue(
            label = stringResource(R.string.label_names),
            value = family.names.joinToString("، ") {
                if (it.note != null) "${it.name} (${it.note})" else it.name
            }
        )
        LabelValue(label = stringResource(R.string.label_kunyat), value = family.kunyat)
        LabelValue(label = stringResource(R.string.label_laqab), value = family.laqab)
        LabelValue(
            label = stringResource(R.string.label_tribe),
            value = family.tribe.joinToString(" ۔ ")
        )
    }
}

@Composable
private fun GroupCard(group: FamilyGroup) {
    ContentCard {
        Text(
            text = group.title,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(6.dp))
        group.members.forEach { person ->
            Text(text = person.name, style = MaterialTheme.typography.bodyLarge)
            person.tribe?.let {
                Text(
                    text = it,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.tertiary
                )
            }
            person.notes.forEach {
                Text(
                    text = "•  $it",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(6.dp))
        }
    }
}
