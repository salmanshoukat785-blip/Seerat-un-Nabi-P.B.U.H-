package com.seerat.app.quiz

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.seerat.app.SeeratApplication
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Chosen answer value meaning "time ran out". */
const val ANSWER_TIMEOUT = -1

data class QuizUiState(
    val loading: Boolean = true,
    val failed: Boolean = false,
    val timed: Boolean = false,
    val questions: List<QuizQuestion> = emptyList(),
    val index: Int = 0,
    /** One entry per question: chosen option, ANSWER_TIMEOUT, or null if not answered yet. */
    val answers: List<Int?> = emptyList(),
    val secondsLeft: Int = QuizViewModel.SECONDS_PER_QUESTION,
    val finished: Boolean = false
) {
    val current: QuizQuestion? get() = questions.getOrNull(index)
    val selected: Int? get() = answers.getOrNull(index)
    val answered: Boolean get() = selected != null
    val score: Int get() = questions.indices.count { answers.getOrNull(it) == questions[it].correctIndex }
}

/**
 * Runs one quiz. The arguments (category, difficulty, timed) come from the navigation route.
 * Questions are generated once, so rotating the phone or switching language does not change them.
 */
class QuizViewModel(
    application: Application,
    savedStateHandle: SavedStateHandle
) : AndroidViewModel(application) {

    companion object {
        const val SECONDS_PER_QUESTION = 20
    }

    private val app = application as SeeratApplication
    private val category = enumOrDefault(savedStateHandle.get<String>("category"), QuizCategory.ALL)
    private val difficulty = enumOrDefault(savedStateHandle.get<String>("difficulty"), Difficulty.MIXED)
    private val timed: Boolean = savedStateHandle.get<Boolean>("timed") ?: false

    private val _state = MutableStateFlow(QuizUiState(timed = timed))
    val state: StateFlow<QuizUiState> = _state.asStateFlow()

    private var timerJob: Job? = null
    private var saved = false

    init {
        viewModelScope.launch {
            try {
                val data = app.repository.quizData()
                val questions = QuizGenerator.generate(data, category, difficulty)
                if (questions.isEmpty()) {
                    _state.update { it.copy(loading = false, failed = true) }
                } else {
                    _state.update {
                        it.copy(
                            loading = false,
                            questions = questions,
                            answers = List(questions.size) { null }
                        )
                    }
                    startTimer()
                }
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, failed = true) }
            }
        }
    }

    fun select(option: Int) {
        val s = _state.value
        if (s.finished || s.answered || s.current == null) return
        recordAnswer(option)
    }

    fun next() {
        val s = _state.value
        if (!s.answered) return
        if (s.index + 1 < s.questions.size) {
            _state.update { it.copy(index = it.index + 1, secondsLeft = SECONDS_PER_QUESTION) }
            startTimer()
        } else {
            finish()
        }
    }

    private fun recordAnswer(value: Int) {
        timerJob?.cancel()
        _state.update { s ->
            s.copy(answers = s.answers.toMutableList().also { it[s.index] = value })
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        if (!timed) return
        val questionIndex = _state.value.index
        timerJob = viewModelScope.launch {
            _state.update { it.copy(secondsLeft = SECONDS_PER_QUESTION) }
            var left = SECONDS_PER_QUESTION
            while (left > 0) {
                delay(1000)
                left--
                _state.update { it.copy(secondsLeft = left) }
            }
            val s = _state.value
            if (s.index == questionIndex && !s.answered && !s.finished) {
                recordAnswer(ANSWER_TIMEOUT)
            }
        }
    }

    private fun finish() {
        timerJob?.cancel()
        _state.update { it.copy(finished = true) }
        if (saved) return
        saved = true
        val s = _state.value
        val wrong = mutableSetOf<String>()
        val right = mutableSetOf<String>()
        s.questions.forEachIndexed { i, q ->
            if (s.answers.getOrNull(i) == q.correctIndex) right.add(q.id) else wrong.add(q.id)
        }
        val result = QuizResult(
            timestamp = System.currentTimeMillis(),
            category = category.name,
            difficulty = difficulty.name,
            timed = timed,
            correct = s.score,
            total = s.questions.size
        )
        viewModelScope.launch {
            try {
                app.quizRepository.addResult(result, wrong, right)
            } catch (e: Exception) {
                // saving history is best effort; the quiz result is still shown
            }
        }
    }

    private inline fun <reified E : Enum<E>> enumOrDefault(name: String?, default: E): E =
        enumValues<E>().firstOrNull { it.name == name } ?: default
}
