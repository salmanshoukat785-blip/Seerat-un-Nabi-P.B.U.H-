package com.seerat.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.seerat.app.R
import com.seerat.app.learn.FlashcardUiState
import com.seerat.app.learn.FlashcardViewModel
import com.seerat.app.ui.components.ContentCard
import com.seerat.app.ui.components.DataNotes
import com.seerat.app.ui.components.SeeratScaffold

/** Flashcards for the self test, hifz mode and wrong-answers revision. */
@Composable
fun FlashcardScreen(
    title: String,
    onBack: () -> Unit,
    viewModel: FlashcardViewModel = viewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    SeeratScaffold(title = title, onBack = onBack) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when {
                state.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                state.failed -> Text(
                    text = stringResource(R.string.load_error),
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp)
                )
                state.cards.isEmpty() -> Text(
                    text = stringResource(
                        if (state.isWrongMode) R.string.cards_wrong_empty else R.string.cards_empty
                    ),
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyLarge
                )
                state.finished -> Summary(
                    state = state,
                    onAgain = viewModel::load,
                    onBack = onBack
                )
                else -> CardContent(
                    state = state,
                    onReveal = viewModel::reveal,
                    onAnswer = viewModel::answer
                )
            }
        }
    }
}

@Composable
private fun CardContent(
    state: FlashcardUiState,
    onReveal: () -> Unit,
    onAnswer: (Boolean) -> Unit
) {
    val card = state.current ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        LinearProgressIndicator(
            progress = { (state.index + 1) / state.cards.size.toFloat() },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = stringResource(R.string.card_progress, state.index + 1, state.cards.size),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(12.dp))

        ContentCard {
            Text(text = card.front, style = MaterialTheme.typography.titleLarge)
            if (state.revealed) {
                Spacer(Modifier.height(12.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.secondary)
                Spacer(Modifier.height(12.dp))
                Text(
                    text = card.back,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                card.note?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = it,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                DataNotes(card.verify)
            }
        }

        Spacer(Modifier.height(16.dp))
        if (!state.revealed) {
            Button(
                onClick = onReveal,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Text(
                    text = stringResource(R.string.card_show_answer),
                    style = MaterialTheme.typography.titleMedium
                )
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = { onAnswer(false) },
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                ) {
                    Text(stringResource(R.string.card_again), textAlign = TextAlign.Center)
                }
                Button(
                    onClick = { onAnswer(true) },
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                ) {
                    Text(stringResource(R.string.card_know), textAlign = TextAlign.Center)
                }
            }
        }
    }
}

@Composable
private fun Summary(
    state: FlashcardUiState,
    onAgain: () -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = stringResource(R.string.cards_done_title),
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = stringResource(R.string.cards_done_summary, state.known, state.review),
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = onAgain,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text(stringResource(R.string.cards_again_btn), style = MaterialTheme.typography.titleMedium)
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.quiz_go_home))
        }
    }
}
