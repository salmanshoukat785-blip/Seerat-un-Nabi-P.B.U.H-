package com.seerat.app.quiz

import com.seerat.app.data.model.AwwaleenGroup
import com.seerat.app.data.model.Child
import com.seerat.app.data.model.Family
import com.seerat.app.data.model.Ghazwa
import com.seerat.app.data.model.Timeline
import com.seerat.app.data.model.UmmulMomineen

enum class QuizCategory { ALL, NABUWAT, HIJRAT, GHAZWAT, FAMILY, UMMAHAT, AWWALEEN }

/** MIXED is only used when choosing a quiz; a question itself is EASY, MEDIUM or HARD. */
enum class Difficulty { EASY, MEDIUM, HARD, MIXED }

/** Everything the generator needs, parsed from assets/data. */
data class QuizData(
    val timeline: Timeline,
    val ghazwat: List<Ghazwa>,
    val family: Family,
    val ummahat: List<UmmulMomineen>,
    val aulad: List<Child>,
    val awwaleen: List<AwwaleenGroup>
)

data class QuizQuestion(
    /** Stable id, e.g. "ghazwat-year-badr". Used later to repeat wrongly answered questions. */
    val id: String,
    val category: QuizCategory,
    val difficulty: Difficulty,
    val text: String,
    /** Always 4 different options in random order. */
    val options: List<String>,
    val correctIndex: Int,
    /** Shown after answering. */
    val explanation: String
) {
    val correctAnswer: String get() = options[correctIndex]
}
