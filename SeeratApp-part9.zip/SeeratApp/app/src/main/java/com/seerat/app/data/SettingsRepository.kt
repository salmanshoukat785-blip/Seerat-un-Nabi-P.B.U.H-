package com.seerat.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Text size chosen by the user; multiplies all text in the app. */
enum class FontSize(val scale: Float) {
    SMALL(0.9f), NORMAL(1.0f), LARGE(1.2f), XLARGE(1.4f);

    companion object {
        fun fromName(name: String?): FontSize = entries.firstOrNull { it.name == name } ?: NORMAL
    }
}

private val Context.dataStore by preferencesDataStore(name = "settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val WELCOME_SEEN = booleanPreferencesKey("welcome_seen")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val FONT_SIZE = stringPreferencesKey("font_size")
    }

    val welcomeSeen: Flow<Boolean> =
        context.dataStore.data.map { it[Keys.WELCOME_SEEN] ?: false }

    val themeMode: Flow<ThemeMode> =
        context.dataStore.data.map { prefs ->
            prefs[Keys.THEME_MODE]
                ?.let { name -> ThemeMode.entries.firstOrNull { it.name == name } }
                ?: ThemeMode.SYSTEM
        }

    val fontSize: Flow<FontSize> =
        context.dataStore.data.map { FontSize.fromName(it[Keys.FONT_SIZE]) }

    suspend fun setFontSize(size: FontSize) {
        context.dataStore.edit { it[Keys.FONT_SIZE] = size.name }
    }

    suspend fun setWelcomeSeen(seen: Boolean) {
        context.dataStore.edit { it[Keys.WELCOME_SEEN] = seen }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }
}
