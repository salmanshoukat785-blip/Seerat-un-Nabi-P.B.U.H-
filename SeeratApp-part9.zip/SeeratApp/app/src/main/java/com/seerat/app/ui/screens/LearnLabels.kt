package com.seerat.app.ui.screens

import androidx.annotation.StringRes
import com.seerat.app.R
import com.seerat.app.learn.HifzTopic
import com.seerat.app.learn.MatchType
import com.seerat.app.learn.OrderType

@StringRes
fun HifzTopic.labelRes(): Int = when (this) {
    HifzTopic.NABUWAT -> R.string.hifz_nabuwat
    HifzTopic.HIJRAT -> R.string.hifz_hijrat
    HifzTopic.GHAZWAT -> R.string.hifz_ghazwat
    HifzTopic.UMMAHAT -> R.string.hifz_ummahat
}

@StringRes
fun MatchType.labelRes(): Int = when (this) {
    MatchType.GHAZWA_YEAR -> R.string.match_ghazwa_year
    MatchType.GHAZWA_PLACE -> R.string.match_ghazwa_place
    MatchType.UMMAHAT_WAFAT -> R.string.match_ummahat_wafat
}

@StringRes
fun OrderType.labelRes(): Int = when (this) {
    OrderType.NABUWAT -> R.string.order_nabuwat
    OrderType.HIJRAT -> R.string.order_hijrat
    OrderType.GHAZWAT -> R.string.order_ghazwat
}
