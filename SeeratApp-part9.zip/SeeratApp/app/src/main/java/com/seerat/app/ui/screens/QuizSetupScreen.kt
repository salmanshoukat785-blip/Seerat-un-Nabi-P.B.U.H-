package com.seerat.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.seerat.app.R
import com.seerat.app.SeeratApplication
import com.seerat.app.quiz.Difficulty
import com.seerat.app.quiz.QuizCategory
import com.seerat.app.quiz.QuizGenerator
import com.seerat.app.quiz.QuizViewModel
import com.seerat.app.ui.components.SeeratScaffold

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun QuizSetupScreen(
    onBack: () -> Unit,
    onStart: (QuizCategory, Difficulty, Boolean) -> Unit,
    onHistory: () -> Unit
) {
    var categoryIndex by rememberSaveable { mutableIntStateOf(0) }
    var difficultyIndex by rememberSaveable { mutableIntStateOf(0) }
    var timed by rememberSaveable { mutableStateOf(false) }

    val category = QuizCategory.entries[categoryIndex]
    val difficulty = QuizDifficultyChoices[difficultyIndex]

    val context = LocalContext.current
    val repository = (context.applicationContext as SeeratApplication).quizRepository
    val history by repository.history.collectAsStateWithLifecycle(initialValue = emptyList())
    val best = history.filter { it.category == category.name }.maxOfOrNull { it.percent }

    SeeratScaffold(
        title = stringResource(R.string.section_quiz),
        onBack = onBack
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text(
                text = stringResource(R.string.quiz_choose_category),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                QuizCategory.entries.forEachIndexed { index, c ->
                    FilterChip(
                        selected = index == categoryIndex,
                        onClick = { categoryIndex = index },
                        label = { Text(stringResource(c.labelRes())) }
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text = if (best != null) {
                    stringResource(R.string.quiz_best, best)
                } else {
                    stringResource(R.string.quiz_no_best)
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(20.dp))
            Text(
                text = stringResource(R.string.quiz_choose_difficulty),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                QuizDifficultyChoices.forEachIndexed { index, d ->
                    FilterChip(
                        selected = index == difficultyIndex,
                        onClick = { difficultyIndex = index },
                        label = { Text(stringResource(d.labelRes())) }
                    )
                }
            }

            Spacer(Modifier.height(20.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = stringResource(R.string.quiz_timer, QuizViewModel.SECONDS_PER_QUESTION),
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.weight(1f)
                )
                Switch(checked = timed, onCheckedChange = { timed = it })
            }

            Spacer(Modifier.height(8.dp))
            Text(
                text = stringResource(R.string.quiz_count_note, QuizGenerator.DEFAULT_COUNT),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(24.dp))
            Button(
                onClick = { onStart(category, difficulty, timed) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Text(
                    text = stringResource(R.string.quiz_start),
                    style = MaterialTheme.typography.titleMedium
                )
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(
                onClick = onHistory,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(stringResource(R.string.quiz_history))
            }
        }
    }
}
