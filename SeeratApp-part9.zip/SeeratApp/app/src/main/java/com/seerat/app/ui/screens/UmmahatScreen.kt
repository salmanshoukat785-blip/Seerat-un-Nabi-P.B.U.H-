package com.seerat.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.seerat.app.R
import com.seerat.app.data.model.UmmulMomineen
import com.seerat.app.ui.components.ContentCard
import com.seerat.app.ui.components.DataNotes
import com.seerat.app.ui.components.LabelValue
import com.seerat.app.ui.components.LoadedContent
import com.seerat.app.ui.components.SeeratScaffold
import com.seerat.app.ui.components.display

private fun UmmulMomineen.fullName() = "$name $fatherName"

/** List of the Ummahat ul Momineen. Tapping one opens her own profile. */
@Composable
fun UmmahatScreen(onBack: () -> Unit, onOpen: (String) -> Unit) {
    SeeratScaffold(
        title = stringResource(R.string.section_ummahat),
        onBack = onBack
    ) { padding ->
        LoadedContent(
            modifier = Modifier.padding(padding),
            loader = { it.ummahat() }
        ) { list ->
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(list, key = { it.id }) { item ->
                    ContentCard(modifier = Modifier.clickable { onOpen(item.id) }) {
                        Text(
                            text = item.fullName(),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        item.kunyat?.let {
                            Text(
                                text = it,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                        }
                        item.nikah?.let {
                            LabelValue(stringResource(R.string.label_nikah), it.display())
                        }
                        item.wafat?.let {
                            LabelValue(stringResource(R.string.label_wafat), it.display())
                        }
                    }
                }
            }
        }
    }
}

/** Full profile of one Umm ul Momineen. */
@Composable
fun UmmahatDetailScreen(id: String?, onBack: () -> Unit) {
    SeeratScaffold(
        title = stringResource(R.string.section_ummahat),
        onBack = onBack
    ) { padding ->
        LoadedContent(
            modifier = Modifier.padding(padding),
            loader = { repo -> repo.ummahat().firstOrNull { it.id == id } }
        ) { ummul ->
            if (ummul == null) {
                Text(
                    text = stringResource(R.string.load_error),
                    modifier = Modifier.padding(24.dp)
                )
            } else {
                LazyColumn(contentPadding = PaddingValues(16.dp)) {
                    item { Profile(ummul) }
                }
            }
        }
    }
}

@Composable
private fun Profile(item: UmmulMomineen) {
    ContentCard {
        Text(
            text = item.fullName(),
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(12.dp))
        item.kunyat?.let { LabelValue(stringResource(R.string.label_kunyat), it) }
        LabelValue(stringResource(R.string.label_father), item.fatherName)
        item.tribe?.let { LabelValue(stringResource(R.string.label_tribe), it) }
        item.nikah?.let { LabelValue(stringResource(R.string.label_nikah), it.display()) }
        item.wafat?.let { LabelValue(stringResource(R.string.label_wafat), it.display()) }
        item.ahadees?.let { LabelValue(stringResource(R.string.label_ahadees), it.toString()) }
        item.mutafaq?.let { LabelValue(stringResource(R.string.label_mutafaq), it.toString()) }
        item.notes.forEach {
            Text(text = "•  $it", style = MaterialTheme.typography.bodyLarge)
        }
        DataNotes(item.dataNotes)
    }
}
