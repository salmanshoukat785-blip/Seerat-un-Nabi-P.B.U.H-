package com.seerat.app.ui.screens

import androidx.annotation.StringRes
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.seerat.app.R
import com.seerat.app.SeeratApplication
import com.seerat.app.learn.DeckBuilder
import com.seerat.app.learn.HifzTopic
import com.seerat.app.learn.MatchType
import com.seerat.app.learn.OrderType
import com.seerat.app.quiz.QuizCategory
import com.seerat.app.ui.components.ContentCard
import com.seerat.app.ui.components.LoadedContent
import com.seerat.app.ui.components.SeeratScaffold

/**
 * Lists decks (quiz categories for the self test, topics for hifz mode) with how many cards
 * are already known. Tapping one starts a study session.
 */
@Composable
fun DeckPickerScreen(
    mode: String,
    onBack: () -> Unit,
    onPick: (String) -> Unit
) {
    val isSelf = mode == DeckBuilder.MODE_SELF
    val title = if (isSelf) R.string.learn_selftest else R.string.learn_hifz
    val keys: List<String> = if (isSelf) {
        QuizCategory.entries.map { it.name }
    } else {
        HifzTopic.entries.map { it.name }
    }

    val context = LocalContext.current
    val learn = (context.applicationContext as SeeratApplication).learnRepository
    val known by learn.knownIds.collectAsStateWithLifecycle(initialValue = emptySet())

    SeeratScaffold(
        title = stringResource(title),
        onBack = onBack
    ) { padding ->
        LoadedContent(
            modifier = Modifier.padding(padding),
            loader = { repo ->
                val data = repo.quizData()
                keys.associateWith { key -> DeckBuilder.deck(data, mode, key).map { it.id } }
            }
        ) { decks ->
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(keys) { key ->
                    val ids = decks[key].orEmpty()
                    val knownCount = ids.count { it in known }
                    val labelRes = if (isSelf) {
                        QuizCategory.valueOf(key).labelRes()
                    } else {
                        HifzTopic.valueOf(key).labelRes()
                    }
                    ContentCard(modifier = Modifier.clickable { onPick(key) }) {
                        Text(
                            text = stringResource(labelRes),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { if (ids.isEmpty()) 0f else knownCount / ids.size.toFloat() },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            text = stringResource(R.string.pick_known, knownCount, ids.size),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

/** A short list of choices (game types). */
@Composable
fun GameTypePickerScreen(
    @StringRes title: Int,
    choices: List<Pair<String, Int>>,   // key to label resource
    onBack: () -> Unit,
    onPick: (String) -> Unit
) {
    SeeratScaffold(
        title = stringResource(title),
        onBack = onBack
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(choices) { (key, label) ->
                ContentCard(modifier = Modifier.clickable { onPick(key) }) {
                    Text(
                        text = stringResource(label),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

val MatchChoices: List<Pair<String, Int>> = MatchType.entries.map { it.name to it.labelRes() }
val OrderChoices: List<Pair<String, Int>> = OrderType.entries.map { it.name to it.labelRes() }
