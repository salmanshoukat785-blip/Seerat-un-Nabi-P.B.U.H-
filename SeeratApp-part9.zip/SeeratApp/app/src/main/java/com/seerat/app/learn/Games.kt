package com.seerat.app.learn

import com.seerat.app.data.model.Ghazwa
import com.seerat.app.quiz.QuizData
import kotlin.random.Random

// ====================================================================== Match the following

enum class MatchType { GHAZWA_YEAR, GHAZWA_PLACE, UMMAHAT_WAFAT }

data class MatchPair(val left: String, val right: String)

/**
 * Pairs for one "match the following" round. Every right-hand item is different,
 * so each left item has exactly one correct partner.
 * Items marked "please verify" in the data are not used.
 */
object MatchGenerator {

    const val ROUND_SIZE = 5

    private class Candidate(val key: String, val pair: MatchPair)

    fun round(
        data: QuizData,
        type: MatchType,
        random: Random = Random.Default,
        size: Int = ROUND_SIZE
    ): List<MatchPair> {
        val candidates: List<Candidate> = when (type) {
            MatchType.GHAZWA_YEAR -> data.ghazwat.filter { it.dataNotes.isEmpty() }.map {
                Candidate("${it.hijriYear}", MatchPair(label(it), "${it.hijriYear} ہجری"))
            }
            MatchType.GHAZWA_PLACE -> data.ghazwat.filter { it.dataNotes.isEmpty() }.map {
                Candidate(it.place, MatchPair(label(it), it.place))
            }
            MatchType.UMMAHAT_WAFAT -> data.ummahat
                .filter { it.wafat?.era == "hijri" && it.id != "sawda" }
                .map {
                    val year = it.wafat?.year ?: 0
                    Candidate("$year", MatchPair("${it.name} ${it.fatherName}", "$year ہجری"))
                }
        }
        // one random candidate per key (year or place), then 'size' keys
        return candidates
            .groupBy { it.key }
            .values
            .map { it.random(random).pair }
            .shuffled(random)
            .take(size)
    }

    private fun label(g: Ghazwa) = if (g.kind == "ghazwa") "غزوہ ${g.name}" else g.name
}

// ====================================================================== Order the events

enum class OrderType { NABUWAT, HIJRAT, GHAZWAT }

data class OrderItem(val text: String, val sortKey: Int, val yearLabel: String)

object OrderGenerator {

    const val ROUND_SIZE = 5

    /** Returns the items in the CORRECT (chronological) order. Each item is from a different year. */
    fun round(
        data: QuizData,
        type: OrderType,
        random: Random = Random.Default,
        size: Int = ROUND_SIZE
    ): List<OrderItem> {
        val items: List<OrderItem> = when (type) {
            OrderType.NABUWAT -> fromTimeline(data, nabuwat = true, random = random)
            OrderType.HIJRAT -> fromTimeline(data, nabuwat = false, random = random)
            OrderType.GHAZWAT -> data.ghazwat
                .filter { it.dataNotes.isEmpty() }
                .groupBy { it.hijriYear }
                .values
                .map { it.random(random) }
                .map {
                    val name = if (it.kind == "ghazwa") "غزوہ ${it.name}" else it.name
                    OrderItem(name, it.hijriYear, "${it.hijriYear} ہجری (${it.ceYear} ء)")
                }
        }
        return items.shuffled(random).take(size).sortedBy { it.sortKey }
    }

    private fun fromTimeline(data: QuizData, nabuwat: Boolean, random: Random): List<OrderItem> {
        val counts = (data.timeline.nabuwat + data.timeline.hijrat)
            .flatMap { it.events }
            .groupingBy { it }
            .eachCount()
        val years = if (nabuwat) data.timeline.nabuwat else data.timeline.hijrat
        return years
            .filter { it.dataNotes.isEmpty() }
            .mapNotNull { y ->
                val unique = y.events.filter { counts[it] == 1 && it.length <= 70 }
                if (unique.isEmpty()) {
                    null
                } else {
                    val label = if (nabuwat) {
                        "${y.index} نبوی (${y.ceYear} ء)"
                    } else {
                        "${y.index} ہجری (${y.ceYear} ء)"
                    }
                    OrderItem(unique.random(random), y.index, label)
                }
            }
    }
}
