package com.seerat.app.ui.screens

import android.content.Context
import androidx.annotation.StringRes
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.seerat.app.R
import com.seerat.app.SeeratApplication
import com.seerat.app.book.BookChapter
import com.seerat.app.book.BookEntry
import com.seerat.app.book.BookLabels
import com.seerat.app.ui.components.ContentCard
import com.seerat.app.ui.components.DataNotes
import kotlinx.coroutines.launch

@StringRes
fun BookChapter.chapterRes(): Int = when (this) {
    BookChapter.NABUWAT -> R.string.book_ch_nabuwat
    BookChapter.HIJRAT -> R.string.book_ch_hijrat
    BookChapter.GHAZWAT -> R.string.section_ghazwat
    BookChapter.FAMILY -> R.string.section_family
    BookChapter.UMMAHAT -> R.string.section_ummahat
    BookChapter.AULAD -> R.string.section_aulad
    BookChapter.AWWALEEN -> R.string.section_awwaleen
}

@Composable
fun bookLabels(): BookLabels = BookLabels(
    father = stringResource(R.string.book_lbl_father),
    nikah = stringResource(R.string.book_lbl_nikah),
    wafat = stringResource(R.string.book_lbl_wafat),
    ahadees = stringResource(R.string.book_lbl_ahadees),
    mutafaq = stringResource(R.string.book_lbl_mutafaq),
    hijri = stringResource(R.string.book_lbl_hijri),
    ce = stringResource(R.string.book_lbl_ce),
    nabawi = stringResource(R.string.book_lbl_nabawi),
    preNabuwat = stringResource(R.string.book_lbl_pre_nabuwat)
)

/** Bookmarks and notes as the screens see them. */
class PersonalState(
    val bookmarks: Set<String>,
    val notes: Map<String, String>,
    val toggleBookmark: (String) -> Unit,
    val saveNote: (String, String) -> Unit
)

@Composable
fun rememberPersonal(): PersonalState {
    val app = LocalContext.current.applicationContext as SeeratApplication
    val repo = app.personalRepository
    val bookmarks by repo.bookmarks.collectAsStateWithLifecycle(initialValue = emptySet())
    val notes by repo.notes.collectAsStateWithLifecycle(initialValue = emptyMap())
    val scope = rememberCoroutineScope()
    return PersonalState(
        bookmarks = bookmarks,
        notes = notes,
        toggleBookmark = { id -> scope.launch { repo.toggleBookmark(id) } },
        saveNote = { id, text -> scope.launch { repo.setNote(id, text) } }
    )
}

@Composable
fun entryTitle(entry: BookEntry): String = when {
    entry.title.isNotBlank() -> entry.title
    entry.chapter == BookChapter.NABUWAT ->
        stringResource(R.string.book_year_nabuwat, entry.number, entry.ceYear)
    else -> stringResource(R.string.book_year_hijrat, entry.number, entry.ceYear)
}

/** Same as [entryTitle] for non-composable code (PDF export). */
fun plainTitle(context: Context, entry: BookEntry): String = when {
    entry.title.isNotBlank() -> entry.title
    entry.chapter == BookChapter.NABUWAT ->
        context.getString(R.string.book_year_nabuwat, entry.number, entry.ceYear)
    else -> context.getString(R.string.book_year_hijrat, entry.number, entry.ceYear)
}

/** One entry with its bookmark and note buttons. */
@Composable
fun EntryItem(
    entry: BookEntry,
    personal: PersonalState,
    showChapter: Boolean,
    modifier: Modifier = Modifier
) {
    val bookmarked = entry.id in personal.bookmarks
    val note = personal.notes[entry.id]
    var editing by remember { mutableStateOf(false) }

    ContentCard(modifier = modifier) {
        if (showChapter) {
            Text(
                text = stringResource(entry.chapter.chapterRes()),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.tertiary
            )
        }
        Text(
            text = entryTitle(entry),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary
        )
        if (entry.subtitle.isNotBlank()) {
            Text(
                text = entry.subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (entry.body.isNotBlank()) {
            Text(
                text = entry.body,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
        DataNotes(entry.verify)

        if (note != null) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp)
                    .background(
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.10f),
                        shape = RoundedCornerShape(8.dp)
                    )
                    .padding(10.dp)
            ) {
                Text(
                    text = stringResource(R.string.note_label),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(text = note, style = MaterialTheme.typography.bodyMedium)
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TextButton(
                onClick = { personal.toggleBookmark(entry.id) },
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = null,
                    tint = if (bookmarked) MaterialTheme.colorScheme.secondary
                    else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    stringResource(if (bookmarked) R.string.bm_remove else R.string.bm_add)
                )
            }
            TextButton(onClick = { editing = true }, modifier = Modifier.weight(1f)) {
                Icon(imageVector = Icons.Default.Edit, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text(stringResource(if (note == null) R.string.note_add else R.string.note_edit))
            }
        }
    }

    if (editing) {
        NoteDialog(
            initial = note.orEmpty(),
            onSave = { text ->
                personal.saveNote(entry.id, text)
                editing = false
            },
            onDismiss = { editing = false }
        )
    }
}

@Composable
private fun NoteDialog(initial: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.note_title)) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                placeholder = { Text(stringResource(R.string.note_hint)) }
            )
        },
        confirmButton = {
            TextButton(onClick = { onSave(text) }) { Text(stringResource(R.string.note_save)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.note_cancel)) }
        }
    )
}
