package com.seerat.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.seerat.app.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow

private const val FADE_IN_MS = 900
private const val HOLD_MS = 1400L
private const val FADE_OUT_MS = 350

/**
 * Splash: logo fades in with a small zoom, holds, fades out, then moves on.
 * It waits until the saved "welcome seen" value has been read, so the next screen is correct.
 */
@Composable
fun SplashScreen(
    welcomeSeen: StateFlow<Boolean?>,
    onFinished: (Boolean) -> Unit
) {
    val seen by welcomeSeen.collectAsStateWithLifecycle()
    val currentOnFinished by rememberUpdatedState(onFinished)
    val alpha = remember { Animatable(0f) }
    val zoom = remember { Animatable(0.85f) }

    LaunchedEffect(Unit) {
        alpha.animateTo(1f, tween(FADE_IN_MS))
    }
    LaunchedEffect(Unit) {
        zoom.animateTo(1f, tween(FADE_IN_MS + 300))
    }

    LaunchedEffect(seen) {
        val value = seen
        if (value != null) {
            delay(FADE_IN_MS + HOLD_MS)
            alpha.animateTo(0f, tween(FADE_OUT_MS))
            currentOnFinished(value)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.primary)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .alpha(alpha.value),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(R.drawable.ic_logo),
                contentDescription = null,
                modifier = Modifier
                    .size(140.dp)
                    .scale(zoom.value)
            )
            Spacer(Modifier.height(28.dp))
            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onPrimary,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = stringResource(R.string.splash_tagline),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.secondary,
                textAlign = TextAlign.Center
            )
        }

        Text(
            text = stringResource(R.string.splash_footer),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.75f),
            textAlign = TextAlign.Center,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(bottom = 32.dp)
                .alpha(alpha.value)
        )
    }
}
