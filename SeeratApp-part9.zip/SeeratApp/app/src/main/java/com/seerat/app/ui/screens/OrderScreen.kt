package com.seerat.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.seerat.app.R
import com.seerat.app.learn.OrderUiState
import com.seerat.app.learn.OrderViewModel
import com.seerat.app.ui.components.ContentCard
import com.seerat.app.ui.components.SeeratScaffold
import com.seerat.app.ui.theme.CorrectGreen
import com.seerat.app.ui.theme.WrongRed

@Composable
fun OrderScreen(onBack: () -> Unit, viewModel: OrderViewModel = viewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    SeeratScaffold(
        title = stringResource(R.string.learn_order),
        onBack = onBack
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (state.loading) {
                CircularProgressIndicator(Modifier.align(Alignment.Center))
            } else if (state.failed) {
                Text(
                    text = stringResource(R.string.load_error),
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp)
                )
            } else if (state.checked) {
                OrderResult(state = state, onNewRound = viewModel::newRound, onBack = onBack)
            } else {
                Playing(
                    state = state,
                    onTap = viewModel::tap,
                    onUndo = viewModel::undo,
                    onReset = viewModel::reset
                )
            }
        }
    }
}

@Composable
private fun Playing(
    state: OrderUiState,
    onTap: (Int) -> Unit,
    onUndo: () -> Unit,
    onReset: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = stringResource(R.string.order_hint),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(12.dp))

        state.display.forEach { itemIndex ->
            val position = state.picked.indexOf(itemIndex)   // -1 when not picked yet
            val picked = position >= 0
            val tint = if (picked) MaterialTheme.colorScheme.secondary else null
            val container = tint?.copy(alpha = 0.16f) ?: MaterialTheme.colorScheme.surface

            Card(
                onClick = { onTap(itemIndex) },
                enabled = !picked,
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = container,
                    contentColor = MaterialTheme.colorScheme.onSurface,
                    disabledContainerColor = container,
                    disabledContentColor = MaterialTheme.colorScheme.onSurface
                ),
                border = BorderStroke(
                    if (picked) 2.dp else 1.dp,
                    tint ?: MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = state.items[itemIndex].text,
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.weight(1f)
                    )
                    if (picked) {
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "${position + 1}",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(
                onClick = onUndo,
                enabled = state.picked.isNotEmpty(),
                modifier = Modifier.weight(1f)
            ) { Text(stringResource(R.string.order_undo)) }
            OutlinedButton(
                onClick = onReset,
                enabled = state.picked.isNotEmpty(),
                modifier = Modifier.weight(1f)
            ) { Text(stringResource(R.string.order_reset)) }
        }
    }
}

@Composable
private fun OrderResult(
    state: OrderUiState,
    onNewRound: () -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = stringResource(R.string.quiz_score, state.score, state.items.size),
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.secondary
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = stringResource(R.string.order_correct_order),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(12.dp))

        state.items.forEachIndexed { index, item ->
            val right = state.picked.getOrNull(index) == index
            ContentCard(modifier = Modifier.padding(bottom = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${index + 1}",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = item.text, style = MaterialTheme.typography.bodyLarge)
                        Text(
                            text = item.yearLabel,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Icon(
                        imageVector = if (right) Icons.Default.Check else Icons.Default.Close,
                        contentDescription = stringResource(if (right) R.string.cd_correct else R.string.cd_wrong),
                        tint = if (right) CorrectGreen else WrongRed
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Button(
            onClick = onNewRound,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text(
                text = stringResource(R.string.game_new_round),
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center
            )
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.quiz_go_home))
        }
    }
}
