package com.seerat.app.ui.screens

import androidx.annotation.StringRes
import com.seerat.app.R
import com.seerat.app.quiz.Difficulty
import com.seerat.app.quiz.QuizCategory

@StringRes
fun QuizCategory.labelRes(): Int = when (this) {
    QuizCategory.ALL -> R.string.quiz_cat_all
    QuizCategory.NABUWAT -> R.string.quiz_cat_nabuwat
    QuizCategory.HIJRAT -> R.string.quiz_cat_hijrat
    QuizCategory.GHAZWAT -> R.string.quiz_cat_ghazwat
    QuizCategory.FAMILY -> R.string.quiz_cat_family
    QuizCategory.UMMAHAT -> R.string.quiz_cat_ummahat
    QuizCategory.AWWALEEN -> R.string.quiz_cat_awwaleen
}

@StringRes
fun Difficulty.labelRes(): Int = when (this) {
    Difficulty.MIXED -> R.string.quiz_diff_mixed
    Difficulty.EASY -> R.string.quiz_diff_easy
    Difficulty.MEDIUM -> R.string.quiz_diff_medium
    Difficulty.HARD -> R.string.quiz_diff_hard
}

/** Order shown to the user. */
val QuizDifficultyChoices = listOf(Difficulty.MIXED, Difficulty.EASY, Difficulty.MEDIUM, Difficulty.HARD)
