package com.seerat.app.learn

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.seerat.app.SeeratApplication
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class OrderUiState(
    val loading: Boolean = true,
    val failed: Boolean = false,
    /** Items in the correct (chronological) order. */
    val items: List<OrderItem> = emptyList(),
    /** Display order: indexes into [items]. */
    val display: List<Int> = emptyList(),
    /** Items the user tapped, in tapping order (indexes into [items]). */
    val picked: List<Int> = emptyList()
) {
    val checked: Boolean get() = items.isNotEmpty() && picked.size == items.size
    /** Position i is right when the user's i-th pick is the i-th correct item. */
    val score: Int get() = picked.indices.count { picked[it] == it }
}

class OrderViewModel(
    application: Application,
    savedStateHandle: SavedStateHandle
) : AndroidViewModel(application) {

    private val app = application as SeeratApplication
    private val type = OrderType.entries.firstOrNull { it.name == savedStateHandle.get<String>("type") }
        ?: OrderType.NABUWAT

    private val _state = MutableStateFlow(OrderUiState())
    val state: StateFlow<OrderUiState> = _state.asStateFlow()

    init {
        newRound()
    }

    fun newRound() {
        _state.update { OrderUiState() }
        viewModelScope.launch {
            try {
                val data = app.repository.quizData()
                val items = OrderGenerator.round(data, type)
                if (items.size < 3) {
                    _state.update { it.copy(loading = false, failed = true) }
                } else {
                    var display = items.indices.shuffled()
                    // do not show the items already in the right order
                    if (display == items.indices.toList()) display = display.reversed()
                    _state.update { it.copy(loading = false, items = items, display = display) }
                }
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, failed = true) }
            }
        }
    }

    fun tap(itemIndex: Int) {
        _state.update { s ->
            if (s.checked || itemIndex in s.picked) s else s.copy(picked = s.picked + itemIndex)
        }
    }

    fun undo() {
        _state.update { s -> if (s.checked || s.picked.isEmpty()) s else s.copy(picked = s.picked.dropLast(1)) }
    }

    fun reset() {
        _state.update { s -> if (s.checked) s else s.copy(picked = emptyList()) }
    }
}
