package com.seerat.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.seerat.app.R
import com.seerat.app.data.model.YearEntry
import com.seerat.app.ui.components.ContentCard
import com.seerat.app.ui.components.DataNotes
import com.seerat.app.ui.components.LoadedContent
import com.seerat.app.ui.components.SeeratScaffold

@Composable
fun TimelineScreen(onBack: () -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }

    SeeratScaffold(
        title = stringResource(R.string.section_timeline),
        onBack = onBack
    ) { padding ->
        LoadedContent(
            modifier = Modifier.padding(padding),
            loader = { it.timeline() }
        ) { timeline ->
            Column {
                TabRow(selectedTabIndex = tab) {
                    Tab(
                        selected = tab == 0,
                        onClick = { tab = 0 },
                        text = { Text(stringResource(R.string.tab_nabuwat)) }
                    )
                    Tab(
                        selected = tab == 1,
                        onClick = { tab = 1 },
                        text = { Text(stringResource(R.string.tab_hijrat)) }
                    )
                }
                val years = if (tab == 0) timeline.nabuwat else timeline.hijrat
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(years, key = { it.index }) { entry ->
                        YearCard(entry = entry, isNabuwat = tab == 0)
                    }
                }
            }
        }
    }
}

@Composable
private fun YearCard(entry: YearEntry, isNabuwat: Boolean) {
    ContentCard {
        val title = if (isNabuwat) {
            stringResource(R.string.today_label_nabuwat, entry.index, entry.ceYear)
        } else {
            stringResource(R.string.today_label_hijrat, entry.index, entry.ceYear)
        }
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(8.dp))
        entry.events.forEach { event ->
            Text(
                text = "•  $event",
                style = MaterialTheme.typography.bodyLarge
            )
        }
        DataNotes(entry.dataNotes)
    }
}
