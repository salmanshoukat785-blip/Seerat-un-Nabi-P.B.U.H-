package com.seerat.app.ui.theme

import androidx.compose.ui.graphics.Color

// Light: green and gold on cream
val GreenDeep = Color(0xFF0B5D3B)
val GoldSoft = Color(0xFFC9A227)
val CreamBg = Color(0xFFFAF6EA)
val OliveAccent = Color(0xFF6B8E23)
val InkText = Color(0xFF1B1B1B)

// Dark
val GreenBright = Color(0xFF2E9E6B)
val GoldBright = Color(0xFFD4AF37)
val CharcoalBg = Color(0xFF121A17)
val MintAccent = Color(0xFF8FD0B0)
val SoftWhite = Color(0xFFEDEDED)

// Quiz feedback (use together with an icon, never colour alone)
val CorrectGreen = Color(0xFF2E7D32)
val WrongRed = Color(0xFFC0392B)
