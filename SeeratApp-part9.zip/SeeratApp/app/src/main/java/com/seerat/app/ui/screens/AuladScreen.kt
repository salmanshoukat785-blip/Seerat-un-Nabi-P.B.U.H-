package com.seerat.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.seerat.app.R
import com.seerat.app.ui.components.ContentCard
import com.seerat.app.ui.components.DataNotes
import com.seerat.app.ui.components.LabelValue
import com.seerat.app.ui.components.LoadedContent
import com.seerat.app.ui.components.SeeratScaffold
import com.seerat.app.ui.components.display

@Composable
fun AuladScreen(onBack: () -> Unit) {
    SeeratScaffold(
        title = stringResource(R.string.section_aulad),
        onBack = onBack
    ) { padding ->
        LoadedContent(
            modifier = Modifier.padding(padding),
            loader = { it.aulad() }
        ) { list ->
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(list, key = { it.id }) { child ->
                    ContentCard {
                        Text(
                            text = child.name,
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        child.birthCeYear?.let {
                            LabelValue(
                                stringResource(R.string.label_birth),
                                stringResource(R.string.era_ce, it)
                            )
                        }
                        child.wafat?.let {
                            LabelValue(stringResource(R.string.label_wafat), it.display())
                        }
                        child.notes.forEach {
                            Text(text = "•  $it", style = MaterialTheme.typography.bodyMedium)
                        }
                        DataNotes(child.dataNotes)
                    }
                }
            }
        }
    }
}
