package com.seerat.app

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.seerat.app.data.LanguageManager
import com.seerat.app.navigation.AppNav
import com.seerat.app.ui.theme.SeeratTheme

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LanguageManager.ensureDefault()

        setContent {
            val viewModel: MainViewModel = viewModel()
            val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
            val fontSize by viewModel.fontSize.collectAsStateWithLifecycle()

            SeeratTheme(themeMode = themeMode, fontSize = fontSize) {
                Surface(color = MaterialTheme.colorScheme.background) {
                    AppNav(viewModel)
                }
            }
        }
    }
}
