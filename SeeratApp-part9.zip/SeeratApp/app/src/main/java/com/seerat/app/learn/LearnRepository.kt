package com.seerat.app.learn

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.learnStore by preferencesDataStore(name = "learn")

/** Remembers which flashcards the user knows and which need another look (on the phone, offline). */
class LearnRepository(private val context: Context) {

    private object Keys {
        val KNOWN = stringSetPreferencesKey("known_ids")
        val REVIEW = stringSetPreferencesKey("review_ids")
    }

    val knownIds: Flow<Set<String>> = context.learnStore.data.map { it[Keys.KNOWN] ?: emptySet() }
    val reviewIds: Flow<Set<String>> = context.learnStore.data.map { it[Keys.REVIEW] ?: emptySet() }

    suspend fun mark(id: String, known: Boolean) {
        context.learnStore.edit { prefs ->
            val knownSet = prefs[Keys.KNOWN] ?: emptySet()
            val reviewSet = prefs[Keys.REVIEW] ?: emptySet()
            if (known) {
                prefs[Keys.KNOWN] = knownSet + id
                prefs[Keys.REVIEW] = reviewSet - id
            } else {
                prefs[Keys.KNOWN] = knownSet - id
                prefs[Keys.REVIEW] = reviewSet + id
            }
        }
    }
}
