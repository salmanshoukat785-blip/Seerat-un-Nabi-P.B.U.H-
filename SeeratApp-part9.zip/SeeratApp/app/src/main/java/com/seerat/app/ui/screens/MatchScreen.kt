package com.seerat.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.seerat.app.R
import com.seerat.app.learn.MatchViewModel
import com.seerat.app.ui.components.SeeratScaffold
import com.seerat.app.ui.theme.CorrectGreen
import com.seerat.app.ui.theme.WrongRed

@Composable
fun MatchScreen(onBack: () -> Unit, viewModel: MatchViewModel = viewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    SeeratScaffold(
        title = stringResource(R.string.learn_match),
        onBack = onBack
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (state.loading) {
                CircularProgressIndicator(Modifier.align(Alignment.Center))
            } else if (state.failed) {
                Text(
                    text = stringResource(R.string.load_error),
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(24.dp)
                )
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {
                    if (state.finished) {
                        Text(
                            text = stringResource(R.string.match_done),
                            style = MaterialTheme.typography.titleLarge,
                            color = CorrectGreen,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center
                        )
                    } else {
                        Text(
                            text = stringResource(R.string.match_hint),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.match_mistakes, state.mistakes),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            state.leftOrder.forEach { pairIndex ->
                                MatchCard(
                                    text = state.pairs[pairIndex].left,
                                    matched = pairIndex in state.matched,
                                    selected = state.selectedLeft == pairIndex,
                                    wrong = false,
                                    onClick = { viewModel.tapLeft(pairIndex) }
                                )
                            }
                        }
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            state.rightOrder.forEach { pairIndex ->
                                MatchCard(
                                    text = state.pairs[pairIndex].right,
                                    matched = pairIndex in state.matched,
                                    selected = false,
                                    wrong = state.flashRight == pairIndex,
                                    onClick = { viewModel.tapRight(pairIndex) }
                                )
                            }
                        }
                    }

                    if (state.finished) {
                        Spacer(Modifier.height(20.dp))
                        Button(
                            onClick = viewModel::newRound,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.game_new_round),
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
                            Text(stringResource(R.string.quiz_go_home))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MatchCard(
    text: String,
    matched: Boolean,
    selected: Boolean,
    wrong: Boolean,
    onClick: () -> Unit
) {
    // colour is paired with a tick (matched) or a thick border (selected / wrong)
    val tint: Color? = when {
        matched -> CorrectGreen
        wrong -> WrongRed
        selected -> MaterialTheme.colorScheme.secondary
        else -> null
    }
    val container = tint?.copy(alpha = 0.16f) ?: MaterialTheme.colorScheme.surface
    val border = tint ?: MaterialTheme.colorScheme.surfaceVariant

    Card(
        onClick = onClick,
        enabled = !matched,
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp),
        colors = CardDefaults.cardColors(
            containerColor = container,
            contentColor = MaterialTheme.colorScheme.onSurface,
            disabledContainerColor = container,
            disabledContentColor = MaterialTheme.colorScheme.onSurface
        ),
        border = BorderStroke(if (tint != null) 2.dp else 1.dp, border)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.weight(1f)
            )
            if (matched) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = stringResource(R.string.cd_correct),
                    tint = CorrectGreen
                )
            }
        }
    }
}
