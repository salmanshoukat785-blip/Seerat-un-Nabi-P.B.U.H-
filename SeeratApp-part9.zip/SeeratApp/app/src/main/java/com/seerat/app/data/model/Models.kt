package com.seerat.app.data.model

import kotlinx.serialization.Serializable

/**
 * Data models for the JSON files in assets/data.
 * The content comes from the Seerat document. Entries that conflict with other
 * parts of the document carry a non-empty `dataNotes` list (shown later as "source / check" hints).
 */

/** A year with an era, e.g. era = "hijri", year = 2, month = "شعبان". */
@Serializable
data class EraYear(
    val era: String,          // qabl_nabuwat | nabawi | hijri | ce
    val year: Int,
    val month: String? = null
)

// ---------------------------------------------------------------- timeline

@Serializable
data class Timeline(
    val nabuwat: List<YearEntry>,
    val hijrat: List<YearEntry>
)

@Serializable
data class YearEntry(
    val index: Int,            // year of Nabuwat (1-13) or Hijrat (1-10)
    val ceYear: Int,
    val events: List<String>,
    val dataNotes: List<String> = emptyList()
)

// ---------------------------------------------------------------- ghazwat

@Serializable
data class GhazwatFile(val items: List<Ghazwa>)

@Serializable
data class Ghazwa(
    val id: String,
    val name: String,
    val kind: String,          // ghazwa | waqia
    val hijriYear: Int,
    val ceYear: Int,
    val place: String,
    val notes: List<String> = emptyList(),
    val dataNotes: List<String> = emptyList()
)

// ---------------------------------------------------------------- family

@Serializable
data class Family(
    val title: String,
    val birth: Birth,
    val names: List<NameEntry>,
    val kunyat: String,
    val laqab: String,
    val tribe: List<String>,
    val groups: List<FamilyGroup>
)

@Serializable
data class Birth(
    val ceYear: Int,
    val date: String,
    val event: String,
    val place: String
)

@Serializable
data class NameEntry(val name: String, val note: String? = null)

@Serializable
data class FamilyGroup(
    val id: String,
    val title: String,
    val members: List<Person>
)

@Serializable
data class Person(
    val name: String,
    val tribe: String? = null,
    val notes: List<String> = emptyList()
)

// ---------------------------------------------------------------- ummahat

@Serializable
data class UmmahatFile(val items: List<UmmulMomineen>)

@Serializable
data class UmmulMomineen(
    val id: String,
    val name: String,
    val fatherName: String,
    val tribe: String? = null,
    val kunyat: String? = null,
    val nikah: EraYear? = null,
    val wafat: EraYear? = null,
    val ahadees: Int? = null,
    val mutafaq: Int? = null,
    val notes: List<String> = emptyList(),
    val dataNotes: List<String> = emptyList()
)

// ---------------------------------------------------------------- aulad

@Serializable
data class AuladFile(val items: List<Child>)

@Serializable
data class Child(
    val id: String,
    val name: String,
    val birthCeYear: Int? = null,
    val wafat: EraYear? = null,
    val notes: List<String> = emptyList(),
    val dataNotes: List<String> = emptyList()
)

// ---------------------------------------------------------------- details

/** Extra text for the "view details" page (details.json, keyed by book entry id). */
@Serializable
data class Detail(
    val summary: String,
    val details: List<String> = emptyList(),
    val lesson: String = ""
)

// ---------------------------------------------------------------- awwaleen

@Serializable
data class AwwaleenFile(val groups: List<AwwaleenGroup>)

@Serializable
data class AwwaleenGroup(
    val id: String,
    val title: String,
    val items: List<AwwaleenItem>
)

@Serializable
data class AwwaleenItem(
    val label: String,
    val name: String,
    val note: String? = null
)
