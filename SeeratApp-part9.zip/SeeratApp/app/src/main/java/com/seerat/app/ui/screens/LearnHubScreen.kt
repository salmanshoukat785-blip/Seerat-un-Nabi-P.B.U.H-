package com.seerat.app.ui.screens

import androidx.annotation.StringRes
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.seerat.app.R
import com.seerat.app.learn.DeckBuilder
import com.seerat.app.navigation.Routes
import com.seerat.app.ui.components.ContentCard
import com.seerat.app.ui.components.SeeratScaffold

private class LearnEntry(
    val route: String,
    @StringRes val title: Int,
    @StringRes val description: Int
)

private val entries = listOf(
    LearnEntry(Routes.LEARN_SELFTEST, R.string.learn_selftest, R.string.learn_selftest_desc),
    LearnEntry(Routes.LEARN_HIFZ, R.string.learn_hifz, R.string.learn_hifz_desc),
    LearnEntry(Routes.LEARN_MATCH, R.string.learn_match, R.string.learn_match_desc),
    LearnEntry(Routes.LEARN_ORDER, R.string.learn_order, R.string.learn_order_desc),
    LearnEntry(Routes.cards(DeckBuilder.MODE_WRONG, "ALL"), R.string.learn_wrong, R.string.learn_wrong_desc),
    LearnEntry(Routes.LEARN_STATS, R.string.learn_stats, R.string.learn_stats_desc)
)

@Composable
fun LearnHubScreen(onBack: () -> Unit, onOpen: (String) -> Unit) {
    SeeratScaffold(
        title = stringResource(R.string.section_learn),
        onBack = onBack
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(entries) { entry ->
                ContentCard(modifier = Modifier.clickable { onOpen(entry.route) }) {
                    Text(
                        text = stringResource(entry.title),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = stringResource(entry.description),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
