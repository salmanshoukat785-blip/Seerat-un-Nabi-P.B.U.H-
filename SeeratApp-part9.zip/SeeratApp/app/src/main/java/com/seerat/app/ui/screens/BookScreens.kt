package com.seerat.app.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.seerat.app.R
import com.seerat.app.book.BookBuilder
import com.seerat.app.book.BookChapter
import com.seerat.app.book.BookEntry
import com.seerat.app.book.BookSearch
import com.seerat.app.book.PdfBlock
import com.seerat.app.book.PdfExporter
import com.seerat.app.ui.components.LoadedContent
import com.seerat.app.ui.components.SeeratScaffold
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** The whole content as one book, with a chapter filter. */
@Composable
fun BookScreen(onBack: () -> Unit) {
    val labels = bookLabels()
    val personal = rememberPersonal()
    var chapter by rememberSaveable { mutableStateOf<BookChapter?>(null) }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val docTitle = stringResource(R.string.pdf_doc_title)
    val noteLabel = stringResource(R.string.note_label)
    val verifyLabel = stringResource(R.string.data_note_label)
    val savedMsg = stringResource(R.string.pdf_saved)
    val failedMsg = stringResource(R.string.pdf_failed)
    var pending by remember { mutableStateOf<List<PdfBlock>>(emptyList()) }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val blocks = pending
                val ok = withContext(Dispatchers.IO) {
                    runCatching {
                        val out = requireNotNull(context.contentResolver.openOutputStream(uri))
                        out.use { PdfExporter.write(it, docTitle, blocks) }
                    }.isSuccess
                }
                Toast.makeText(context, if (ok) savedMsg else failedMsg, Toast.LENGTH_LONG).show()
            }
        }
    }

    SeeratScaffold(title = stringResource(R.string.section_book), onBack = onBack) { padding ->
        LoadedContent(
            modifier = Modifier.padding(padding),
            loader = { repo -> BookBuilder.build(repo.quizData(), labels) }
        ) { entries ->
            val selected = chapter
            val shown = if (selected == null) entries else entries.filter { it.chapter == selected }
            Column {
                Row(
                    modifier = Modifier
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selected == null,
                        onClick = { chapter = null },
                        label = { Text(stringResource(R.string.book_all)) }
                    )
                    BookChapter.entries.forEach { c ->
                        FilterChip(
                            selected = selected == c,
                            onClick = { chapter = c },
                            label = { Text(stringResource(c.chapterRes())) }
                        )
                    }
                }
                OutlinedButton(
                    onClick = {
                        pending = entries.map { e ->
                            val note = personal.notes[e.id]
                            val extra = buildList {
                                if (e.verify.isNotEmpty()) add("[$verifyLabel] " + e.verify.joinToString(" "))
                                if (!note.isNullOrBlank()) add("$noteLabel: $note")
                            }
                            PdfBlock(
                                chapter = context.getString(e.chapter.chapterRes()),
                                heading = plainTitle(context, e),
                                sub = e.subtitle,
                                body = (listOf(e.body) + extra).filter { it.isNotBlank() }.joinToString("\n")
                            )
                        }
                        launcher.launch("Seerat-un-Nabi.pdf")
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Text(stringResource(R.string.pdf_button))
                }
                EntryList(
                    entries = shown,
                    personal = personal,
                    showChapter = selected == null,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun EntryList(
    entries: List<BookEntry>,
    personal: PersonalState,
    showChapter: Boolean,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier,
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(entries, key = { it.id }) { entry ->
            EntryItem(entry = entry, personal = personal, showChapter = showChapter)
        }
    }
}

/** Search over the whole book. */
@Composable
fun SearchScreen(onBack: () -> Unit) {
    val labels = bookLabels()
    val personal = rememberPersonal()
    var query by rememberSaveable { mutableStateOf("") }

    SeeratScaffold(title = stringResource(R.string.section_search), onBack = onBack) { padding ->
        LoadedContent(
            modifier = Modifier.padding(padding),
            loader = { repo -> BookBuilder.build(repo.quizData(), labels) }
        ) { entries ->
            val results = remember(query, entries) { BookSearch.filter(entries, query) }
            Column {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    singleLine = true,
                    placeholder = { Text(stringResource(R.string.search_hint)) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = stringResource(R.string.cd_clear)
                                )
                            }
                        }
                    }
                )
                when {
                    query.isBlank() -> Hint(stringResource(R.string.search_start))
                    results.isEmpty() -> Hint(stringResource(R.string.search_empty))
                    else -> {
                        Text(
                            text = stringResource(R.string.search_count, results.size),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                        EntryList(
                            entries = results,
                            personal = personal,
                            showChapter = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

/** Saved entries (tab 1) and entries with a personal note (tab 2). */
@Composable
fun BookmarksScreen(onBack: () -> Unit) {
    val labels = bookLabels()
    val personal = rememberPersonal()
    var tab by rememberSaveable { mutableStateOf(0) }

    SeeratScaffold(title = stringResource(R.string.section_bookmarks), onBack = onBack) { padding ->
        LoadedContent(
            modifier = Modifier.padding(padding),
            loader = { repo -> BookBuilder.build(repo.quizData(), labels) }
        ) { entries ->
            val shown = if (tab == 0) {
                entries.filter { it.id in personal.bookmarks }
            } else {
                entries.filter { personal.notes.containsKey(it.id) }
            }
            Column {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = tab == 0,
                        onClick = { tab = 0 },
                        label = { Text(stringResource(R.string.bm_tab_saved, personal.bookmarks.size)) }
                    )
                    FilterChip(
                        selected = tab == 1,
                        onClick = { tab = 1 },
                        label = { Text(stringResource(R.string.bm_tab_notes, personal.notes.size)) }
                    )
                }
                if (shown.isEmpty()) {
                    Hint(stringResource(if (tab == 0) R.string.bm_empty_saved else R.string.bm_empty_notes))
                } else {
                    EntryList(
                        entries = shown,
                        personal = personal,
                        showChapter = true,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun Hint(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp)
    )
}
