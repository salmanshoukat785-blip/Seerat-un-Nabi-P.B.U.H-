package com.seerat.app.ui.screens

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.seerat.app.R
import com.seerat.app.data.FontSize
import com.seerat.app.data.LanguageManager
import com.seerat.app.data.ThemeMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    themeMode: ThemeMode,
    onThemeChange: (ThemeMode) -> Unit,
    fontSize: FontSize,
    onFontSizeChange: (FontSize) -> Unit,
    onBack: () -> Unit
) {
    val currentLanguage = LanguageManager.current()
    val context = LocalContext.current
    val version = remember {
        try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName.orEmpty()
        } catch (e: Exception) {
            ""
        }
    }
    val feedbackSubject = stringResource(R.string.feedback_subject)
    val feedbackBody = stringResource(R.string.feedback_body, version, Build.VERSION.RELEASE)
    val feedbackChooser = stringResource(R.string.feedback_chooser)
    val feedbackNone = stringResource(R.string.feedback_none)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            SectionTitle(R.string.settings_language)
            OptionRow(
                label = stringResource(R.string.language_urdu),
                selected = currentLanguage == LanguageManager.URDU,
                onSelect = { LanguageManager.set(LanguageManager.URDU) }
            )
            OptionRow(
                label = stringResource(R.string.language_english),
                selected = currentLanguage == LanguageManager.ENGLISH,
                onSelect = { LanguageManager.set(LanguageManager.ENGLISH) }
            )

            Spacer(Modifier.height(24.dp))

            SectionTitle(R.string.settings_theme)
            OptionRow(
                label = stringResource(R.string.theme_system),
                selected = themeMode == ThemeMode.SYSTEM,
                onSelect = { onThemeChange(ThemeMode.SYSTEM) }
            )
            OptionRow(
                label = stringResource(R.string.theme_light),
                selected = themeMode == ThemeMode.LIGHT,
                onSelect = { onThemeChange(ThemeMode.LIGHT) }
            )
            OptionRow(
                label = stringResource(R.string.theme_dark),
                selected = themeMode == ThemeMode.DARK,
                onSelect = { onThemeChange(ThemeMode.DARK) }
            )

            Spacer(Modifier.height(24.dp))

            SectionTitle(R.string.settings_font)
            FontSize.entries.forEach { size ->
                OptionRow(
                    label = stringResource(size.labelRes()),
                    selected = fontSize == size,
                    onSelect = { onFontSizeChange(size) }
                )
            }
            Text(
                text = stringResource(R.string.font_preview),
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.padding(top = 8.dp)
            )

            Spacer(Modifier.height(24.dp))

            SectionTitle(R.string.settings_about)
            Text(
                text = stringResource(R.string.settings_version, version),
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(12.dp))
            OutlinedButton(
                onClick = {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, feedbackSubject)
                        putExtra(Intent.EXTRA_TEXT, feedbackBody)
                    }
                    try {
                        context.startActivity(Intent.createChooser(intent, feedbackChooser))
                    } catch (e: ActivityNotFoundException) {
                        Toast.makeText(context, feedbackNone, Toast.LENGTH_LONG).show()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(stringResource(R.string.feedback_button))
            }
        }
    }
}

@Composable
private fun SectionTitle(titleRes: Int) {
    Text(
        text = stringResource(titleRes),
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(bottom = 4.dp)
    )
}

@Composable
private fun OptionRow(label: String, selected: Boolean, onSelect: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .selectable(selected = selected, onClick = onSelect, role = Role.RadioButton)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.padding(horizontal = 8.dp))
        Text(text = label, style = MaterialTheme.typography.bodyLarge)
    }
}

private fun FontSize.labelRes(): Int = when (this) {
    FontSize.SMALL -> R.string.font_small
    FontSize.NORMAL -> R.string.font_normal
    FontSize.LARGE -> R.string.font_large
    FontSize.XLARGE -> R.string.font_xlarge
}
