package com.seerat.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.seerat.app.R
import com.seerat.app.data.model.Ghazwa
import com.seerat.app.ui.components.ContentCard
import com.seerat.app.ui.components.DataNotes
import com.seerat.app.ui.components.LabelValue
import com.seerat.app.ui.components.LoadedContent
import com.seerat.app.ui.components.SeeratScaffold

@Composable
fun GhazwatScreen(onBack: () -> Unit) {
    // 0 = all years
    var selectedYear by rememberSaveable { mutableIntStateOf(0) }

    SeeratScaffold(
        title = stringResource(R.string.section_ghazwat),
        onBack = onBack
    ) { padding ->
        LoadedContent(
            modifier = Modifier.padding(padding),
            loader = { it.ghazwat() }
        ) { all ->
            val years = all.map { it.hijriYear }.distinct().sorted()
            val shown = if (selectedYear == 0) all else all.filter { it.hijriYear == selectedYear }

            Column {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        FilterChip(
                            selected = selectedYear == 0,
                            onClick = { selectedYear = 0 },
                            label = { Text(stringResource(R.string.filter_all)) }
                        )
                    }
                    items(years) { year ->
                        FilterChip(
                            selected = selectedYear == year,
                            onClick = { selectedYear = year },
                            label = { Text(stringResource(R.string.era_hijri, year)) }
                        )
                    }
                }
                Text(
                    text = stringResource(R.string.count_items, shown.size),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(shown, key = { it.id }) { GhazwaCard(it) }
                }
            }
        }
    }
}

@Composable
private fun GhazwaCard(item: Ghazwa) {
    val kind = if (item.kind == "ghazwa") {
        stringResource(R.string.kind_ghazwa)
    } else {
        stringResource(R.string.kind_waqia)
    }
    ContentCard {
        Text(
            text = item.name,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = kind,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.tertiary
        )
        Spacer(Modifier.height(8.dp))
        LabelValue(
            label = stringResource(R.string.label_year),
            value = stringResource(R.string.year_ah_ce, item.hijriYear, item.ceYear)
        )
        LabelValue(label = stringResource(R.string.label_place), value = item.place)
        item.notes.forEach {
            Text(text = "•  $it", style = MaterialTheme.typography.bodyMedium)
        }
        DataNotes(item.dataNotes)
    }
}
