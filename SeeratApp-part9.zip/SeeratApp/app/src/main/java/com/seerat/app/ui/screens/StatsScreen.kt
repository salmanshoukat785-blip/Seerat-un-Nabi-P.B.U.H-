package com.seerat.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.seerat.app.R
import com.seerat.app.SeeratApplication
import com.seerat.app.quiz.QuizCategory
import com.seerat.app.quiz.QuizGenerator
import com.seerat.app.ui.components.ContentCard
import com.seerat.app.ui.components.LoadedContent
import com.seerat.app.ui.components.SeeratScaffold

/** Question ids of one category (the self-test deck). */
private class CategoryPool(val category: QuizCategory, val ids: List<String>)

@Composable
fun StatsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val app = context.applicationContext as SeeratApplication
    val history by app.quizRepository.history.collectAsStateWithLifecycle(initialValue = emptyList())
    val wrongIds by app.quizRepository.wrongIds.collectAsStateWithLifecycle(initialValue = emptySet())
    val knownIds by app.learnRepository.knownIds.collectAsStateWithLifecycle(initialValue = emptySet())

    SeeratScaffold(
        title = stringResource(R.string.learn_stats),
        onBack = onBack
    ) { padding ->
        LoadedContent(
            modifier = Modifier.padding(padding),
            loader = { repo ->
                val data = repo.quizData()
                val all = QuizGenerator.allQuestions(data)
                QuizCategory.entries
                    .filter { it != QuizCategory.ALL }
                    .map { c -> CategoryPool(c, all.filter { it.category == c }.map { it.id }) }
            }
        ) { pools ->
            val average = if (history.isEmpty()) null else history.sumOf { it.percent } / history.size
            val best = history.maxOfOrNull { it.percent }

            // categories with wrong answers still to study, most first
            val weak = pools
                .map { it to it.ids.count { id -> id in wrongIds } }
                .filter { it.second > 0 }
                .sortedByDescending { it.second }
                .take(3)

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    ContentCard {
                        StatRow(
                            label = stringResource(R.string.stats_quizzes),
                            value = history.size.toString()
                        )
                        StatRow(
                            label = stringResource(R.string.stats_average),
                            value = if (average != null) stringResource(R.string.quiz_percent, average)
                            else stringResource(R.string.stats_none)
                        )
                        StatRow(
                            label = stringResource(R.string.stats_best),
                            value = if (best != null) stringResource(R.string.quiz_percent, best)
                            else stringResource(R.string.stats_none)
                        )
                    }
                }

                item {
                    ContentCard {
                        Text(
                            text = stringResource(R.string.stats_weak),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.height(6.dp))
                        if (weak.isEmpty()) {
                            Text(
                                text = stringResource(R.string.stats_no_weak),
                                style = MaterialTheme.typography.bodyLarge
                            )
                        } else {
                            weak.forEach { (pool, count) ->
                                StatRow(
                                    label = stringResource(pool.category.labelRes()),
                                    value = stringResource(R.string.stats_wrong_count, count)
                                )
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = stringResource(R.string.stats_progress),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                pools.forEach { pool ->
                    item {
                        val known = pool.ids.count { it in knownIds }
                        ContentCard {
                            Text(
                                text = stringResource(pool.category.labelRes()),
                                style = MaterialTheme.typography.titleMedium
                            )
                            Spacer(Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { if (pool.ids.isEmpty()) 0f else known / pool.ids.size.toFloat() },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text(
                                text = stringResource(R.string.pick_known, known, pool.ids.size),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary
        )
    }
}
