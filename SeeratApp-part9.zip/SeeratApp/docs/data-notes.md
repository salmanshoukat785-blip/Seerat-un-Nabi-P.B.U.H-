# Data notes

Source: the user's document "Seerat N-Update.docx". Entries that the document disagreed with itself
about were checked against published sources (Wikipedia, Wikishia, Bukhari-based accounts) and fixed.
No entry asks the user to "verify" any more.

## Fixed after checking

| Entry | Document | Now | Source |
|-------|----------|-----|--------|
| Hafsa, nikah | 2 AH (list) / 4 AH (timeline) | Sha'ban 3 AH (timeline moved to year 3) | Wikipedia: Hafsa bint Umar |
| Aisha, agreed-upon hadith | 7 | 174 (of 2210) | mahajjah.com biography |
| Ibrahim, birth | 640 CE | Dhul Hijjah 8 AH (630 CE) | Wikipedia: Ibrahim ibn Muhammad |
| Zaynab, death | 7 AH (timeline) / 8 AH | 8 AH (timeline moved to year 8) | Wikishia: Zaynab bt. Muhammad |
| Rajee | 3 AH | Safar 4 AH | Wikipedia: Expedition of Al Raji |
| Bir Maona | 3 AH, 80 companions | Safar 4 AH, 70 companions (Bukhari; Ibn Ishaq says 40) | Wikipedia: Expedition of Bir Maona |
| Uhad | missing | added: 7 Shawwal 3 AH, ghazwat list + timeline year 3 | Wikishia: Battle of Uhud |
| Prophet's death | under 10 AH | text now says 12 Rabi ul Awwal 11 AH, 632 CE (the 10th year after Hijrat) | common account |
| Hasan, "fifth khalifa" | stated as fact | "according to some scholars"; birth moved to 3 AH (Ramadan) | common account |
| Abdullah | wafat 10 AH, no birth | wafat removed; notes: born after Bi'that in Makkah, died as a child | common account |

## Still differs between books (shown as a note, not as a "verify" box)

- Sawda, death: 22 AH (end of Umar's time) in most books, 54 AH according to Ibn Sa'd. The app shows 22 AH
  and lists the other view in her notes. The quiz does not ask about it.
- Muraysi (Banu Mustaliq): 5 or 6 AH. Dhat al-Riqa: 4 or 7 AH. Dhu Qarad: 6 or 7 AH. The detail texts say so.

## Year numbering

"Hijrat year N" counts years from the Hijra itself (so the Prophet's death, 12 Rabi ul Awwal 11 AH,
falls in the 10th year of Hijrat). CE years use 622 + N.

## Spelling fixes made while converting (facts unchanged)

معصب → مصعب, حلیمہ بنت بی زؤیب → حلیمہ بنت ابی ذؤیب, ابرہیم → ابراہیم, بیت عقبہ → بیعت عقبہ,
سبل اور سبیل → سہل اور سہیل, "ا حمراء الاسد" → "احمراء الاسد".

## Counts

13 years of Nabuwat + 10 years of Hijrat. 29 entries in `ghazwat.json` (26 ghazwat + Rajee, Bir Maona,
Fath Makkah). 12 Ummahat, 7 children. `details.json` has a summary, more details and a lesson for every
ghazwa, Umm ul Momineen and child. Run `python3 tools/validate_data.py` to check the files.
