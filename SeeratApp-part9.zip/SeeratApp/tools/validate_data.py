#!/usr/bin/env python3
"""Quick check of app/src/main/assets/data/*.json without Android Studio.

Usage: python3 tools/validate_data.py
"""
import json
import pathlib
import sys

root = pathlib.Path(__file__).resolve().parent.parent / "app/src/main/assets/data"


def load(name):
    return json.loads((root / name).read_text(encoding="utf-8"))


errors = []

timeline = load("timeline.json")
ghazwat = load("ghazwat.json")["items"]
ummahat = load("ummahat.json")["items"]
aulad = load("aulad.json")["items"]
family = load("family.json")
awwaleen = load("awwaleen.json")["groups"]

if [e["index"] for e in timeline["nabuwat"]] != list(range(1, 14)):
    errors.append("nabuwat years must be 1..13")
if [e["index"] for e in timeline["hijrat"]] != list(range(1, 11)):
    errors.append("hijrat years must be 1..10")

years = {e["index"]: e for e in timeline["hijrat"]}
for g in ghazwat:
    y = years.get(g["hijriYear"])
    if not y:
        errors.append(f"{g['id']}: unknown hijri year")
        continue
    if y["ceYear"] != g["ceYear"]:
        errors.append(f"{g['id']}: CE year differs from timeline")
    if g["name"] not in " ".join(y["events"]):
        errors.append(f"{g['id']}: name not found in timeline events")

for label, items in (("ghazwat", ghazwat), ("ummahat", ummahat), ("aulad", aulad)):
    ids = [i["id"] for i in items]
    if len(ids) != len(set(ids)):
        errors.append(f"{label}: duplicate ids")

print(f"timeline: {len(timeline['nabuwat'])} nabuwat + {len(timeline['hijrat'])} hijrat years")
print(f"ghazwat: {len(ghazwat)}, ummahat: {len(ummahat)}, aulad: {len(aulad)}")
print(f"family groups: {len(family['groups'])}, awwaleen groups: {len(awwaleen)}")

flagged = []
for label, items in (("ghazwat", ghazwat), ("ummahat", ummahat), ("aulad", aulad)):
    flagged += [f"{label}/{i['id']}" for i in items if i.get("dataNotes")]
flagged += [f"timeline/{k}-{e['index']}" for k in ("nabuwat", "hijrat")
            for e in timeline[k] if e.get("dataNotes")]
print(f"entries marked 'check': {len(flagged)}")
for f in flagged:
    print("  -", f)

if errors:
    print("\nERRORS:")
    for e in errors:
        print("  *", e)
    sys.exit(1)
print("\nAll good.")
