package com.seerat.app.book

import com.seerat.app.data.DataParser
import com.seerat.app.quiz.QuizData
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BookTest {

    private fun read(name: String): String =
        File("src/main/assets/data/$name").readText(Charsets.UTF_8)

    private fun entries(): List<BookEntry> = BookBuilder.build(
        QuizData(
            timeline = DataParser.timeline(read("timeline.json")),
            ghazwat = DataParser.ghazwat(read("ghazwat.json")).items,
            family = DataParser.family(read("family.json")),
            ummahat = DataParser.ummahat(read("ummahat.json")).items,
            aulad = DataParser.aulad(read("aulad.json")).items,
            awwaleen = DataParser.awwaleen(read("awwaleen.json")).groups
        )
    )

    @Test
    fun idsAreUniqueAndAllChaptersExist() {
        val list = entries()
        assertEquals(list.size, list.map { it.id }.toSet().size)
        assertEquals(BookChapter.entries.toSet(), list.map { it.chapter }.toSet())
        assertEquals(13, list.count { it.chapter == BookChapter.NABUWAT })
        assertEquals(10, list.count { it.chapter == BookChapter.HIJRAT })
    }

    @Test
    fun everyEntryHasText() {
        for (e in entries()) {
            assertTrue("${e.id} is empty", e.body.isNotBlank() || e.subtitle.isNotBlank())
        }
    }

    @Test
    fun searchFindsGhazwaByName() {
        val list = entries()
        val first = list.first { it.chapter == BookChapter.GHAZWAT }
        val found = BookSearch.filter(list, first.title)
        assertTrue(found.any { it.id == first.id })
    }

    @Test
    fun searchIgnoresMarksAndBlankQueryGivesNothing() {
        val withMarks = BookSearch.normalize("ہِجْرت")
        val plain = BookSearch.normalize("ہجرت")
        assertEquals(plain, withMarks)
        assertTrue(BookSearch.filter(entries(), "   ").isEmpty())
    }

    @Test
    fun everyGhazwaUmmulAndChildHasDetails() {
        val details = DataParser.details(read("details.json"))
        val list = entries()
        val needed = list.filter {
            it.chapter == BookChapter.GHAZWAT || it.chapter == BookChapter.UMMAHAT ||
                it.chapter == BookChapter.AULAD
        }
        for (e in needed) {
            assertTrue("no details for ${e.id}", details[e.id]?.summary?.isNotBlank() == true)
        }
        assertTrue(details.keys.all { key -> list.any { it.id == key } })
    }

    @Test
    fun noEntryAsksForVerification() {
        assertTrue(entries().all { it.verify.isEmpty() })
    }

    @Test
    fun extraTopicsBecomeBookEntries() {
        val extra = DataParser.extra(read("extra.json")).sections
        assertTrue(extra.size >= 10)
        val all = BookBuilder.build(
            QuizData(
                timeline = DataParser.timeline(read("timeline.json")),
                ghazwat = DataParser.ghazwat(read("ghazwat.json")).items,
                family = DataParser.family(read("family.json")),
                ummahat = DataParser.ummahat(read("ummahat.json")).items,
                aulad = DataParser.aulad(read("aulad.json")).items,
                awwaleen = DataParser.awwaleen(read("awwaleen.json")).groups
            ),
            extra = extra
        )
        val more = all.filter { it.chapter == BookChapter.EXTRA }
        assertEquals(extra.sumOf { it.items.size }, more.size)
        assertEquals(all.size, all.map { it.id }.toSet().size)
        assertTrue(more.all { it.group != null && it.body.isNotBlank() })
    }
}
