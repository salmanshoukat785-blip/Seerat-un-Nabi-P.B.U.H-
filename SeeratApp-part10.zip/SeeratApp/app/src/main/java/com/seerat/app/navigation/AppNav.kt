package com.seerat.app.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.seerat.app.MainViewModel
import com.seerat.app.R
import com.seerat.app.learn.DeckBuilder
import com.seerat.app.book.BookChapter
import com.seerat.app.ui.screens.BookScreen
import com.seerat.app.ui.screens.ChapterScreen
import com.seerat.app.ui.screens.DetailScreen
import com.seerat.app.ui.screens.BookmarksScreen
import com.seerat.app.ui.screens.DeckPickerScreen
import com.seerat.app.ui.screens.FlashcardScreen
import com.seerat.app.ui.screens.GameTypePickerScreen
import com.seerat.app.ui.screens.HomeScreen
import com.seerat.app.ui.screens.MoreTopicsScreen
import com.seerat.app.ui.screens.LearnHubScreen
import com.seerat.app.ui.screens.MatchChoices
import com.seerat.app.ui.screens.MatchScreen
import com.seerat.app.ui.screens.OrderChoices
import com.seerat.app.ui.screens.OrderScreen
import com.seerat.app.ui.screens.PlaceholderScreen
import com.seerat.app.ui.screens.QuizHistoryScreen
import com.seerat.app.ui.screens.QuizPlayScreen
import com.seerat.app.ui.screens.QuizSetupScreen
import com.seerat.app.ui.screens.SearchScreen
import com.seerat.app.ui.screens.SettingsScreen
import com.seerat.app.ui.screens.SplashScreen
import com.seerat.app.ui.screens.StatsScreen
import com.seerat.app.ui.screens.UmmahatDetailScreen
import com.seerat.app.ui.screens.WelcomeScreen

@Composable
fun AppNav(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val fontSize by viewModel.fontSize.collectAsStateWithLifecycle()

    NavHost(navController = navController, startDestination = Routes.SPLASH) {

        composable(Routes.SPLASH) {
            SplashScreen(
                welcomeSeen = viewModel.welcomeSeen,
                onFinished = { seen ->
                    val next = if (seen) Routes.HOME else Routes.WELCOME
                    navController.navigate(next) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.WELCOME) {
            WelcomeScreen(
                onStart = { dontShowAgain ->
                    viewModel.setWelcomeSeen(dontShowAgain)
                    navController.navigate(Routes.HOME) {
                        popUpTo(Routes.WELCOME) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.HOME) {
            HomeScreen(
                onOpenSection = { navController.navigate(Routes.section(it.id)) },
                onOpenRoute = { navController.navigate(it) },
                onOpenSettings = { navController.navigate(Routes.SETTINGS) }
            )
        }

        composable(
            route = Routes.SECTION,
            arguments = listOf(navArgument("id") { type = NavType.StringType })
        ) { entry ->
            val section = Section.fromId(entry.arguments?.getString("id"))
            val back: () -> Unit = { navController.popBackStack() }
            val open: (String) -> Unit = { navController.navigate(Routes.detail(it)) }
            val favourites: () -> Unit = { navController.navigate(Routes.section(Section.BOOKMARKS.id)) }
            when (section) {
                Section.TIMELINE -> ChapterScreen(
                    chapters = listOf(BookChapter.NABUWAT, BookChapter.HIJRAT),
                    titleRes = R.string.section_timeline, subtitleRes = R.string.hub_sub_timeline,
                    emoji = "🗓️", onBack = back, onOpen = open, onFavourites = favourites
                )
                Section.GHAZWAT -> ChapterScreen(
                    chapters = listOf(BookChapter.GHAZWAT),
                    titleRes = R.string.section_ghazwat, subtitleRes = R.string.hub_sub_ghazwat,
                    emoji = "⚔️", onBack = back, onOpen = open, onFavourites = favourites
                )
                Section.FAMILY -> ChapterScreen(
                    chapters = listOf(BookChapter.FAMILY),
                    titleRes = R.string.section_family, subtitleRes = R.string.hub_sub_family,
                    emoji = "", onBack = back, onOpen = open, onFavourites = favourites
                )
                Section.UMMAHAT -> ChapterScreen(
                    chapters = listOf(BookChapter.UMMAHAT),
                    titleRes = R.string.section_ummahat, subtitleRes = R.string.hub_sub_ummahat,
                    emoji = "🌸", onBack = back, onOpen = open, onFavourites = favourites
                )
                Section.AULAD -> ChapterScreen(
                    chapters = listOf(BookChapter.AULAD),
                    titleRes = R.string.section_aulad, subtitleRes = R.string.hub_sub_aulad,
                    emoji = "", onBack = back, onOpen = open, onFavourites = favourites
                )
                Section.AWWALEEN -> ChapterScreen(
                    chapters = listOf(BookChapter.AWWALEEN),
                    titleRes = R.string.section_awwaleen, subtitleRes = R.string.hub_sub_awwaleen,
                    emoji = "🥇", onBack = back, onOpen = open, onFavourites = favourites
                )
                Section.QUIZ -> QuizSetupScreen(
                    onBack = back,
                    onStart = { category, difficulty, timed ->
                        navController.navigate(Routes.quizPlay(category.name, difficulty.name, timed))
                    },
                    onHistory = { navController.navigate(Routes.QUIZ_HISTORY) }
                )
                Section.LEARN -> LearnHubScreen(
                    onBack = back,
                    onOpen = { navController.navigate(it) }
                )
                Section.MORE -> MoreTopicsScreen(
                    onBack = back,
                    onOpenTopic = { navController.navigate(Routes.topic(it)) }
                )
                Section.BOOK -> BookScreen(onBack = back)
                Section.SEARCH -> SearchScreen(onBack = back)
                Section.BOOKMARKS -> BookmarksScreen(onBack = back)
                else -> PlaceholderScreen(titleRes = section?.titleRes, onBack = back)
            }
        }

        composable(
            route = Routes.QUIZ_PLAY,
            arguments = listOf(
                navArgument("category") { type = NavType.StringType },
                navArgument("difficulty") { type = NavType.StringType },
                navArgument("timed") { type = NavType.BoolType }
            )
        ) {
            QuizPlayScreen(
                onExit = { navController.popBackStack() },
                onPlayAgain = { navController.popBackStack() },
                onHome = { navController.popBackStack(Routes.HOME, inclusive = false) }
            )
        }

        // ---------------------------------------------------------------- learn and practice
        composable(Routes.LEARN_SELFTEST) {
            DeckPickerScreen(
                mode = DeckBuilder.MODE_SELF,
                onBack = { navController.popBackStack() },
                onPick = { navController.navigate(Routes.cards(DeckBuilder.MODE_SELF, it)) }
            )
        }
        composable(Routes.LEARN_HIFZ) {
            DeckPickerScreen(
                mode = DeckBuilder.MODE_HIFZ,
                onBack = { navController.popBackStack() },
                onPick = { navController.navigate(Routes.cards(DeckBuilder.MODE_HIFZ, it)) }
            )
        }
        composable(
            route = Routes.LEARN_CARDS,
            arguments = listOf(
                navArgument("mode") { type = NavType.StringType },
                navArgument("key") { type = NavType.StringType }
            )
        ) { entry ->
            val mode = entry.arguments?.getString("mode")
            val title = when (mode) {
                DeckBuilder.MODE_HIFZ -> R.string.learn_hifz
                DeckBuilder.MODE_WRONG -> R.string.learn_wrong
                else -> R.string.learn_selftest
            }
            FlashcardScreen(
                title = stringResource(title),
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.LEARN_MATCH) {
            GameTypePickerScreen(
                title = R.string.learn_match,
                choices = MatchChoices,
                onBack = { navController.popBackStack() },
                onPick = { navController.navigate(Routes.matchPlay(it)) }
            )
        }
        composable(
            route = Routes.LEARN_MATCH_PLAY,
            arguments = listOf(navArgument("type") { type = NavType.StringType })
        ) {
            MatchScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.LEARN_ORDER) {
            GameTypePickerScreen(
                title = R.string.learn_order,
                choices = OrderChoices,
                onBack = { navController.popBackStack() },
                onPick = { navController.navigate(Routes.orderPlay(it)) }
            )
        }
        composable(
            route = Routes.LEARN_ORDER_PLAY,
            arguments = listOf(navArgument("type") { type = NavType.StringType })
        ) {
            OrderScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.LEARN_STATS) {
            StatsScreen(onBack = { navController.popBackStack() })
        }

        composable(
            route = Routes.DETAIL,
            arguments = listOf(navArgument("id") { type = NavType.StringType })
        ) { entry ->
            DetailScreen(
                id = entry.arguments?.getString("id"),
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = Routes.TOPIC,
            arguments = listOf(navArgument("id") { type = NavType.StringType })
        ) { entry ->
            ChapterScreen(
                chapters = listOf(BookChapter.EXTRA),
                titleRes = R.string.section_more, subtitleRes = R.string.hub_sub_more,
                emoji = "📚", groupId = entry.arguments?.getString("id"),
                onBack = { navController.popBackStack() },
                onOpen = { navController.navigate(Routes.detail(it)) },
                onFavourites = { navController.navigate(Routes.section(Section.BOOKMARKS.id)) }
            )
        }

        composable(Routes.QUIZ_HISTORY) {
            QuizHistoryScreen(onBack = { navController.popBackStack() })
        }

        composable(
            route = Routes.UMMAHAT_DETAIL,
            arguments = listOf(navArgument("id") { type = NavType.StringType })
        ) { entry ->
            UmmahatDetailScreen(
                id = entry.arguments?.getString("id"),
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(
                themeMode = themeMode,
                onThemeChange = viewModel::setThemeMode,
                fontSize = fontSize,
                onFontSizeChange = viewModel::setFontSize,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
