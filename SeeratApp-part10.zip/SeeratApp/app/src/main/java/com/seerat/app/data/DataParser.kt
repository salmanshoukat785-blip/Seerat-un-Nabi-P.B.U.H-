package com.seerat.app.data

import com.seerat.app.data.model.AuladFile
import com.seerat.app.data.model.AwwaleenFile
import com.seerat.app.data.model.Detail
import com.seerat.app.data.model.ExtraFile
import com.seerat.app.data.model.Family
import com.seerat.app.data.model.GhazwatFile
import com.seerat.app.data.model.Timeline
import com.seerat.app.data.model.UmmahatFile
import kotlinx.serialization.json.Json

/** Pure JSON parsing (no Android classes), so it can also run in plain unit tests. */
object DataParser {
    private val json = Json { ignoreUnknownKeys = true }

    fun timeline(text: String): Timeline = json.decodeFromString(text)
    fun ghazwat(text: String): GhazwatFile = json.decodeFromString(text)
    fun family(text: String): Family = json.decodeFromString(text)
    fun ummahat(text: String): UmmahatFile = json.decodeFromString(text)
    fun aulad(text: String): AuladFile = json.decodeFromString(text)
    fun awwaleen(text: String): AwwaleenFile = json.decodeFromString(text)
    fun extra(text: String): ExtraFile = json.decodeFromString(text)
    fun details(text: String): Map<String, Detail> = json.decodeFromString(text)
}
