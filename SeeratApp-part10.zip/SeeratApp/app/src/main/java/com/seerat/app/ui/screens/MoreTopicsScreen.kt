package com.seerat.app.ui.screens

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.seerat.app.R
import com.seerat.app.data.LanguageManager
import com.seerat.app.ui.components.HubBanner
import com.seerat.app.ui.components.HubCard
import com.seerat.app.ui.components.LoadedContent
import com.seerat.app.ui.components.SeeratScaffold

/** List of the "more topics" sections (saraya, Isra and Miraj, Khulafa and so on). */
@Composable
fun MoreTopicsScreen(onBack: () -> Unit, onOpenTopic: (String) -> Unit) {
    val urdu = LanguageManager.current() == LanguageManager.URDU

    SeeratScaffold(title = stringResource(R.string.section_more), onBack = onBack) { padding ->
        LoadedContent(
            modifier = Modifier.padding(padding),
            loader = { repo -> repo.extra().sections }
        ) { sections ->
            LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
                item {
                    HubBanner(
                        title = stringResource(R.string.section_more),
                        subtitle = stringResource(R.string.hub_sub_more),
                        emoji = "📚"
                    )
                }
                itemsIndexed(sections, key = { _, s -> s.id }) { index, section ->
                    HubCard(
                        number = index + 1,
                        title = section.emoji + " " + section.title(urdu),
                        summary = section.sub(urdu),
                        chip = null,
                        buttonText = stringResource(R.string.more_open, section.items.size),
                        onClick = { onOpenTopic(section.id) },
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}
