package com.seerat.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.seerat.app.R
import com.seerat.app.SeeratApplication
import com.seerat.app.data.LanguageManager
import com.seerat.app.data.Period
import com.seerat.app.data.TodayEvent
import com.seerat.app.navigation.Routes
import com.seerat.app.navigation.Section
import com.seerat.app.quiz.QuizGenerator

private class HomeExtras(val today: TodayEvent?, val poolIds: Set<String>)

private class Topic(val section: Section, val emoji: String, val labelRes: Int)

private val Topics = listOf(
    Topic(Section.TIMELINE, "🗓️", R.string.t_timeline),
    Topic(Section.GHAZWAT, "⚔️", R.string.t_ghazwat),
    Topic(Section.FAMILY, "", R.string.t_family),
    Topic(Section.UMMAHAT, "🌸", R.string.t_ummahat),
    Topic(Section.AULAD, "", R.string.t_aulad),
    Topic(Section.AWWALEEN, "🥇", R.string.t_awwaleen),
    Topic(Section.BOOK, "📖", R.string.t_book),
    Topic(Section.MORE, "📚", R.string.t_more)
)

private val TileLight = listOf(
    0xFFE3F2FD, 0xFFFFE0CC, 0xFFDDF5DC, 0xFFE8D9FF,
    0xFFFFD9E6, 0xFFD3F5F2, 0xFFEEF7C9, 0xFFFFF0C2
).map { Color(it) }

private val TileDark = listOf(
    0xFF24384A, 0xFF4A3326, 0xFF24402A, 0xFF3A2F55,
    0xFF4A2A38, 0xFF1F4440, 0xFF3D4420, 0xFF4A4020
).map { Color(it) }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onOpenSection: (Section) -> Unit,
    onOpenRoute: (String) -> Unit,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current
    val app = context.applicationContext as SeeratApplication
    val knownIds by app.learnRepository.knownIds.collectAsStateWithLifecycle(initialValue = emptySet())
    val extras by produceState<HomeExtras?>(initialValue = null) {
        value = try {
            val repository = app.repository
            val dayOfYear = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR)
            HomeExtras(
                today = repository.todayEvent(dayOfYear),
                poolIds = QuizGenerator.allQuestions(repository.quizData()).map { it.id }.toSet()
            )
        } catch (e: Exception) {
            null
        }
    }
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(stringResource(R.string.home_title)) },
                actions = { LanguagePill() },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    actionIconContentColor = MaterialTheme.colorScheme.secondary
                )
            )
        },
        bottomBar = {
            HomeBottomBar(
                onStats = { onOpenRoute(Routes.LEARN_STATS) },
                onFavourites = { onOpenSection(Section.BOOKMARKS) },
                onSearch = { onOpenSection(Section.SEARCH) },
                onSettings = onOpenSettings
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                WelcomeBanner(onStart = { onOpenSection(Section.TIMELINE) })
            }

            // quick cards
            item {
                QuickCard("🏆", stringResource(R.string.qa_quiz), dark) { onOpenSection(Section.QUIZ) }
            }
            item {
                QuickCard("📝", stringResource(R.string.qa_practice), dark) { onOpenSection(Section.LEARN) }
            }
            item {
                QuickCard("📈", stringResource(R.string.qa_stats), dark) { onOpenRoute(Routes.LEARN_STATS) }
            }
            item {
                QuickCard("⭐", stringResource(R.string.qa_favs), dark) { onOpenSection(Section.BOOKMARKS) }
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
                TopicsHeader()
            }
            items(Topics) { topic ->
                val index = Topics.indexOf(topic)
                TopicTile(
                    emoji = topic.emoji,
                    label = stringResource(topic.labelRes),
                    color = if (dark) TileDark[index] else TileLight[index],
                    onClick = { onOpenSection(topic.section) }
                )
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
                val pool = extras?.poolIds.orEmpty()
                val progress = if (pool.isEmpty()) 0f else pool.count { it in knownIds } / pool.size.toFloat()
                ContinueCard(
                    progress = progress,
                    today = extras?.today,
                    onContinue = { onOpenSection(Section.LEARN) }
                )
            }
        }
    }
}

@Composable
private fun LanguagePill() {
    val current = LanguageManager.current()
    Row(
        modifier = Modifier
            .padding(end = 8.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.15f))
            .padding(2.dp)
    ) {
        listOf(LanguageManager.ENGLISH to "English", LanguageManager.URDU to "اردو").forEach { (code, label) ->
            val selected = current == code
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = if (selected) MaterialTheme.colorScheme.onSecondary else MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (selected) MaterialTheme.colorScheme.secondary else Color.Transparent)
                    .clickable { LanguageManager.set(code) }
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
private fun WelcomeBanner(onStart: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        listOf(MaterialTheme.colorScheme.surfaceVariant, primary.copy(alpha = 0.22f))
                    )
                )
                .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.home_welcome_title),
                    style = MaterialTheme.typography.headlineMedium,
                    color = primary
                )
                Text(
                    text = stringResource(R.string.home_welcome_sub),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(10.dp))
                Button(onClick = onStart, shape = RoundedCornerShape(24.dp)) {
                    Text(stringResource(R.string.home_start) + " ›")
                }
            }
            Spacer(Modifier.width(8.dp))
            Text(text = "🕌", fontSize = 64.sp)
        }
    }
}

@Composable
private fun QuickCard(emoji: String, label: String, dark: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(92.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (dark) Color(0xFF26332E) else Color(0xFFFFF7E0)
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(text = emoji, fontSize = 28.sp)
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun TopicsHeader() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(MaterialTheme.colorScheme.primary)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = "📖", fontSize = 20.sp)
        Spacer(Modifier.width(8.dp))
        Text(
            text = stringResource(R.string.home_topics),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onPrimary
        )
    }
}

@Composable
private fun TopicTile(emoji: String, label: String, color: Color, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(96.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = color)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (emoji.isNotBlank()) Text(text = emoji, fontSize = 30.sp)
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onBackground
            )
        }
    }
}

@Composable
private fun ContinueCard(progress: Float, today: TodayEvent?, onContinue: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "▶ " + stringResource(R.string.continue_title),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.size(76.dp),
                        strokeWidth = 8.dp,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                    Text(
                        text = stringResource(R.string.quiz_percent, (progress * 100).toInt()),
                        style = MaterialTheme.typography.titleMedium
                    )
                }
                Spacer(Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.home_today_title),
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                    if (today != null) {
                        val label = if (today.period == Period.NABUWAT) {
                            stringResource(R.string.today_label_nabuwat, today.yearIndex, today.ceYear)
                        } else {
                            stringResource(R.string.today_label_hijrat, today.yearIndex, today.ceYear)
                        }
                        Text(text = label, style = MaterialTheme.typography.labelMedium)
                        Text(
                            text = today.text,
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                    } else {
                        Text(
                            text = stringResource(R.string.home_today_placeholder),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Button(onClick = onContinue, shape = RoundedCornerShape(24.dp)) {
                Text(stringResource(R.string.continue_button) + " ›")
            }
        }
    }
}

@Composable
private fun HomeBottomBar(
    onStats: () -> Unit,
    onFavourites: () -> Unit,
    onSearch: () -> Unit,
    onSettings: () -> Unit
) {
    val onPrimary = MaterialTheme.colorScheme.onPrimary
    val colors = NavigationBarItemDefaults.colors(
        indicatorColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.35f),
        selectedTextColor = onPrimary,
        unselectedTextColor = onPrimary.copy(alpha = 0.85f)
    )
    NavigationBar(containerColor = MaterialTheme.colorScheme.primary) {
        listOf(
            Triple("🏠", R.string.nav_home, {}),
            Triple("📈", R.string.nav_stats, onStats),
            Triple("⭐", R.string.nav_favs, onFavourites),
            Triple("🔍", R.string.nav_search, onSearch),
            Triple("⚙️", R.string.nav_settings, onSettings)
        ).forEachIndexed { index, (emoji, label, action) ->
            NavigationBarItem(
                selected = index == 0,
                onClick = action,
                icon = { Text(text = emoji, fontSize = 22.sp) },
                label = {
                    Text(
                        text = stringResource(label),
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                colors = colors
            )
        }
    }
}
