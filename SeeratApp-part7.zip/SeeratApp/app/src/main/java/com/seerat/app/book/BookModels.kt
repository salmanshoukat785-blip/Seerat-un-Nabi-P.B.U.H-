package com.seerat.app.book

import com.seerat.app.data.model.EraYear
import com.seerat.app.quiz.QuizData

enum class BookChapter { NABUWAT, HIJRAT, GHAZWAT, FAMILY, UMMAHAT, AULAD, AWWALEEN }

/**
 * One readable piece of the book (a year, a ghazwa, a person, a group).
 * Timeline years have a blank [title]; the screen shows "Nabuwat year N" from [number] and [ceYear].
 */
data class BookEntry(
    val id: String,
    val chapter: BookChapter,
    val title: String,
    val number: Int = 0,
    val ceYear: Int = 0,
    val subtitle: String = "",
    val body: String = "",
    val verify: List<String> = emptyList()
)

/** Small words used inside the generated text; the UI passes translated versions. */
data class BookLabels(
    val father: String = "Father",
    val nikah: String = "Nikah",
    val wafat: String = "Wafat",
    val ahadees: String = "Ahadees",
    val mutafaq: String = "Mutafaq",
    val hijri: String = "AH",
    val ce: String = "CE",
    val nabawi: String = "Nabawi",
    val preNabuwat: String = "before Nabuwat"
)

/** Turns the app data into a flat list of book entries (pure Kotlin, easy to test). */
object BookBuilder {

    fun build(data: QuizData, l: BookLabels = BookLabels()): List<BookEntry> = buildList {
        data.timeline.nabuwat.forEach { y ->
            add(
                BookEntry(
                    id = "tn:${y.index}", chapter = BookChapter.NABUWAT, title = "",
                    number = y.index, ceYear = y.ceYear,
                    body = bullets(y.events), verify = y.dataNotes
                )
            )
        }
        data.timeline.hijrat.forEach { y ->
            add(
                BookEntry(
                    id = "th:${y.index}", chapter = BookChapter.HIJRAT, title = "",
                    number = y.index, ceYear = y.ceYear,
                    body = bullets(y.events), verify = y.dataNotes
                )
            )
        }
        data.ghazwat.forEach { g ->
            add(
                BookEntry(
                    id = "g:${g.id}", chapter = BookChapter.GHAZWAT, title = g.name,
                    subtitle = "${g.hijriYear} ${l.hijri} · ${g.ceYear} ${l.ce} · ${g.place}",
                    body = g.notes.joinToString("\n"), verify = g.dataNotes
                )
            )
        }

        val f = data.family
        add(
            BookEntry(
                id = "f:intro", chapter = BookChapter.FAMILY, title = f.title,
                subtitle = "${f.birth.ceYear} ${l.ce} · ${f.birth.date}",
                body = (listOf(f.birth.event, f.birth.place, f.kunyat, f.laqab) +
                    f.names.map { n -> if (n.note.isNullOrBlank()) n.name else "${n.name} (${n.note})" } +
                    f.tribe)
                    .filter { it.isNotBlank() }
                    .joinToString("\n")
            )
        )
        f.groups.forEach { g ->
            add(
                BookEntry(
                    id = "f:${g.id}", chapter = BookChapter.FAMILY, title = g.title,
                    body = g.members.joinToString("\n") { p ->
                        (listOfNotNull(p.name, p.tribe) + p.notes).joinToString(" — ")
                    }
                )
            )
        }

        data.ummahat.forEach { u ->
            val lines = buildList {
                add("${l.father}: ${u.fatherName}")
                u.kunyat?.let { add(it) }
                u.nikah?.let { add("${l.nikah}: ${era(it, l)}") }
                u.wafat?.let { add("${l.wafat}: ${era(it, l)}") }
                u.ahadees?.let { add("${l.ahadees}: $it") }
                u.mutafaq?.let { add("${l.mutafaq}: $it") }
                addAll(u.notes)
            }
            add(
                BookEntry(
                    id = "u:${u.id}", chapter = BookChapter.UMMAHAT, title = u.name,
                    subtitle = u.tribe.orEmpty(), body = lines.joinToString("\n"), verify = u.dataNotes
                )
            )
        }

        data.aulad.forEach { c ->
            val lines = buildList {
                c.wafat?.let { add("${l.wafat}: ${era(it, l)}") }
                addAll(c.notes)
            }
            add(
                BookEntry(
                    id = "a:${c.id}", chapter = BookChapter.AULAD, title = c.name,
                    subtitle = c.birthCeYear?.let { "$it ${l.ce}" }.orEmpty(),
                    body = lines.joinToString("\n"), verify = c.dataNotes
                )
            )
        }

        data.awwaleen.forEach { g ->
            add(
                BookEntry(
                    id = "w:${g.id}", chapter = BookChapter.AWWALEEN, title = g.title,
                    body = g.items.joinToString("\n") { i ->
                        val base = "${i.label}: ${i.name}"
                        if (i.note.isNullOrBlank()) base else "$base (${i.note})"
                    }
                )
            )
        }
    }

    private fun bullets(lines: List<String>) = lines.joinToString("\n") { "• $it" }

    private fun era(e: EraYear, l: BookLabels): String {
        val suffix = when (e.era) {
            "hijri" -> l.hijri
            "nabawi" -> l.nabawi
            "qabl_nabuwat" -> l.preNabuwat
            else -> l.ce
        }
        return buildString {
            append(e.year).append(' ').append(suffix)
            if (e.month != null) append(" · ").append(e.month)
        }
    }
}

/** Simple offline search over book entries; ignores Urdu/Arabic marks and letter variants. */
object BookSearch {

    fun normalize(s: String): String = buildString {
        for (c in s.lowercase()) {
            when {
                c in 'ً'..'ٟ' || c == 'ٰ' || c == 'ـ' -> Unit
                c == 'ي' || c == 'ى' -> append('ی')
                c == 'ك' -> append('ک')
                c == 'ة' || c == 'ۃ' || c == 'ه' -> append('ہ')
                c == 'أ' || c == 'إ' || c == 'آ' -> append('ا')
                else -> append(c)
            }
        }
    }

    /** Entries that contain every word of [query]; empty list for a blank query. */
    fun filter(entries: List<BookEntry>, query: String): List<BookEntry> {
        val words = normalize(query).split(' ', '\n', '\t').filter { it.isNotBlank() }
        if (words.isEmpty()) return emptyList()
        return entries.filter { e ->
            val text = normalize(listOf(e.title, e.subtitle, e.body, e.ceYear.toString()).joinToString(" "))
            words.all { text.contains(it) }
        }
    }
}
