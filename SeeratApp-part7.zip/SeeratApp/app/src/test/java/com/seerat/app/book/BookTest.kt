package com.seerat.app.book

import com.seerat.app.data.DataParser
import com.seerat.app.quiz.QuizData
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BookTest {

    private fun read(name: String): String =
        File("src/main/assets/data/$name").readText(Charsets.UTF_8)

    private fun entries(): List<BookEntry> = BookBuilder.build(
        QuizData(
            timeline = DataParser.timeline(read("timeline.json")),
            ghazwat = DataParser.ghazwat(read("ghazwat.json")).items,
            family = DataParser.family(read("family.json")),
            ummahat = DataParser.ummahat(read("ummahat.json")).items,
            aulad = DataParser.aulad(read("aulad.json")).items,
            awwaleen = DataParser.awwaleen(read("awwaleen.json")).groups
        )
    )

    @Test
    fun idsAreUniqueAndAllChaptersExist() {
        val list = entries()
        assertEquals(list.size, list.map { it.id }.toSet().size)
        assertEquals(BookChapter.entries.toSet(), list.map { it.chapter }.toSet())
        assertEquals(13, list.count { it.chapter == BookChapter.NABUWAT })
        assertEquals(10, list.count { it.chapter == BookChapter.HIJRAT })
    }

    @Test
    fun everyEntryHasText() {
        for (e in entries()) {
            assertTrue("${e.id} is empty", e.body.isNotBlank() || e.subtitle.isNotBlank())
        }
    }

    @Test
    fun searchFindsGhazwaByName() {
        val list = entries()
        val first = list.first { it.chapter == BookChapter.GHAZWAT }
        val found = BookSearch.filter(list, first.title)
        assertTrue(found.any { it.id == first.id })
    }

    @Test
    fun searchIgnoresMarksAndBlankQueryGivesNothing() {
        val withMarks = BookSearch.normalize("ہِجْرت")
        val plain = BookSearch.normalize("ہجرت")
        assertEquals(plain, withMarks)
        assertTrue(BookSearch.filter(entries(), "   ").isEmpty())
    }
}
